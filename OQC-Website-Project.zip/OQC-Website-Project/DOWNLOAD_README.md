# OQC downloadable project

The website application is in oqc/. Read oqc/README.md and oqc/docs/WEBSITE_HANDOVER.md first. This archive includes source, pinned dependencies, migrations, tests, original branding, CI configuration and verification reports. Dependencies, generated Prisma client, builds, Git history, running services and real environment credentials are excluded.

## Run locally

Use Node 24, pnpm 10.34.6 and a running Docker daemon. Commands below use Bash (Linux, macOS or Windows WSL). Install the pinned pnpm if needed with your usual package-manager setup; alternatively prefix pnpm commands with `npm exec --yes --package=pnpm@10.34.6 --`.

From the extracted project directory:

```bash
cd oqc
pnpm install --frozen-lockfile
node infra/scripts/init-local.mjs
docker compose up -d --wait postgres redis
docker compose exec -T postgres psql -U oqc -d postgres -v ON_ERROR_STOP=1 <<'SQL'
SELECT 'CREATE DATABASE oqc_dev' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='oqc_dev')\gexec
SQL
pnpm db:generate
pnpm db:migrate
pnpm dev
```

In a separate terminal from oqc/, run `pnpm worker` for internal notifications and scheduled publication. Local initialization creates random development secrets, preserves existing .env files, and seeds no business data. Create the first real administrator interactively using the application README; no default login is shipped.

The cloud-specific setup-webkit-local.sh and setup-cloud.sh helpers use /workspace paths. Use the portable commands above on your own machine. Browser tests additionally need Chromium, WebKit dependencies and Poppler; see the handover and QA evidence.

Approved courses, fees, teacher details, policies and contact content are still owner supplied. Live hosting/storage bindings and manual launch review remain pending. The repository's deployment-guide_1.md describes an older unrelated Laravel application; follow oqc/docs/VERCEL_STAGING.md for this website.

MANIFEST.json records SHA-256 hashes of all packaged source files. It is an integrity inventory, not a cryptographic signature.
