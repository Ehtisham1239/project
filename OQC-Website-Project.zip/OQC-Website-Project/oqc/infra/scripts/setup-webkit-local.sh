#!/usr/bin/env bash
# Root-free, signed Debian 13 dependencies for the pinned Playwright WebKit.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
. /etc/os-release
[[ "$ID" == debian && "$VERSION_ID" == 13 ]] || { echo 'This helper requires Debian 13'; exit 1; }
export PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright
export PNPM_HOME=/workspace/.pnpm-home
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm --filter @oqc/web exec playwright install webkit
task_apt=/workspace/.webkit-apt
mkdir -p "$task_apt"/{etc/apt.conf.d,etc/sources.list.d,state/lists/partial,cache/archives/partial,log} /workspace/.webkit-runtime
cat > "$task_apt/etc/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://security.debian.org/debian-security trixie-security main
EOF
cat > "$task_apt/apt.conf" <<'EOF'
Dir::Etc "/workspace/.webkit-apt/etc";
Dir::Etc::main "/dev/null";
Dir::Etc::parts "/workspace/.webkit-apt/etc/apt.conf.d";
Dir::Etc::sourceparts "/workspace/.webkit-apt/etc/sources.list.d";
Dir::State "/workspace/.webkit-apt/state";
Dir::State::status "/var/lib/dpkg/status";
Dir::Cache "/workspace/.webkit-apt/cache";
Dir::Log "/workspace/.webkit-apt/log";
Debug::NoLocking "true";
Acquire::AllowInsecureRepositories "false";
APT::Get::AllowUnauthenticated "false";
EOF
export APT_CONFIG="$task_apt/apt.conf"
apt-get update
apt-get --download-only --yes install libgtk-4-1 libharfbuzz-icu0 libhyphen0 libmanette-0.2-0 libwoff1 libgles2
# Some stripped cloud images retain dpkg metadata for this absent library.
(cd "$task_apt/cache/archives" && apt-get download libgles2)
python3 - <<'PY'
import hashlib, pathlib, subprocess, shutil
archives = pathlib.Path('/workspace/.webkit-apt/cache/archives')
runtime = pathlib.Path('/workspace/.webkit-runtime')
for deb in sorted(archives.glob('*.deb')):
    package = subprocess.check_output(['dpkg-deb', '-f', str(deb), 'Package'], text=True).strip()
    version = subprocess.check_output(['dpkg-deb', '-f', str(deb), 'Version'], text=True).strip()
    metadata = subprocess.check_output(['apt-cache', 'show', f'{package}={version}'], text=True)
    checksums = {line.split(': ', 1)[1] for line in metadata.splitlines() if line.startswith('SHA256: ')}
    if hashlib.sha256(deb.read_bytes()).hexdigest() not in checksums:
        raise SystemExit(f'Package integrity check failed: {package}')
    subprocess.run(['dpkg-deb', '-x', str(deb), str(runtime)], check=True)
    print(f'Verified {package} {version}')
browser = pathlib.Path('/workspace/.cache/ms-playwright/webkit-2370')
if not (browser / 'pw_run.sh').is_file():
    raise SystemExit('Pinned WebKit 2370 not found; update this helper after reviewing the Playwright pin')
for engine in ['minibrowser-wpe', 'minibrowser-gtk']:
    target = browser / engine / 'sys/lib'
    target.mkdir(parents=True, exist_ok=True)
    for source in (runtime / 'usr/lib/x86_64-linux-gnu').glob('*.so*'):
        destination = target / source.name
        if not destination.exists() and not destination.is_symlink():
            shutil.copy2(source, destination, follow_symlinks=False)
PY
WEBKIT_EXECUTABLE_PATH="$PLAYWRIGHT_BROWSERS_PATH/webkit-2370/pw_run.sh" node --input-type=module <<'JS'
import { createRequire } from 'node:module';
const require = createRequire(process.cwd() + '/apps/web/package.json');
const { webkit } = require('@playwright/test');
const browser = await webkit.launch({ executablePath: process.env.WEBKIT_EXECUTABLE_PATH });
try {
  const page = await browser.newPage();
  await page.setContent('<title>WebKit native readiness</title><h1>Ready</h1>');
  if (await page.title() !== 'WebKit native readiness') throw new Error('WebKit rendering failed');
  console.log('Verified native WebKit rendering');
} finally { await browser.close(); }
JS
