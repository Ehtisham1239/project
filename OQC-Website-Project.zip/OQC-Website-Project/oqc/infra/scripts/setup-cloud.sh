#!/usr/bin/env bash
set -euo pipefail
export PNPM_HOME=/workspace/.pnpm-home
mkdir -p "$PNPM_HOME"
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
node -e 'if(Number(process.versions.node.split(".")[0])!==24)throw new Error("Node 24 required")'
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm install --frozen-lockfile --store-dir /workspace/.pnpm-store
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm check:glob
node infra/scripts/init-local.mjs
docker compose up -d --wait postgres redis
docker compose exec -T postgres psql -U oqc -d postgres -v ON_ERROR_STOP=1 <<'SQL'
SELECT 'CREATE DATABASE oqc_dev' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='oqc_dev')\gexec
SQL
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm db:generate
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm db:migrate
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm typecheck
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm check:no-seed
