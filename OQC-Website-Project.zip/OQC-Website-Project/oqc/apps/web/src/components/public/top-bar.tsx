import { publicSettings } from "@/server/services/public";
import { settingSchemas } from "@/lib/validation/content";
export async function TopBar() {
  const values = Object.fromEntries(
    (await publicSettings()).map((item) => [item.key, item.value]),
  );
  const email = settingSchemas["contact.email"].safeParse(
      values["contact.email"],
    ),
    whatsapp = settingSchemas["contact.whatsapp"].safeParse(
      values["contact.whatsapp"],
    );
  if (!email.success && !whatsapp.success) return null;
  return (
    <div className="top-bar">
      <div className="container toolbar">
        {email.success && <a href={`mailto:${email.data}`}>{email.data}</a>}
        {whatsapp.success && (
          <a
            href={`https://wa.me/${whatsapp.data.slice(1)}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp: {whatsapp.data}
          </a>
        )}
      </div>
    </div>
  );
}
