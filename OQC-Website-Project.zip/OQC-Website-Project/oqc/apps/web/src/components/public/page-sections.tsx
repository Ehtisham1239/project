import Link from "next/link";
import { sectionDataSchema } from "@/lib/validation/content";
import { RichText } from "./rich-text";
import {
  publishedCourses,
  publicTeachers,
  publicContent,
} from "@/server/services/public";
import { formatMinor } from "@/lib/platform/money";
export async function PageSections({
  sections,
}: {
  sections: { id: string; type: string; data: unknown }[];
}) {
  return (
    <>
      {await Promise.all(
        sections.map(async (section) => {
          const parsed = sectionDataSchema.safeParse({
            type: section.type,
            data: section.data,
          });
          if (!parsed.success) return null;
          const { type, data } = parsed.data;
          if (type === "RICH_TEXT")
            return (
              <section className="card" key={section.id}>
                {data.document ? (
                  <RichText document={data.document} />
                ) : (
                  <p style={{ whiteSpace: "pre-wrap" }}>{data.text}</p>
                )}
              </section>
            );
          if (type === "HERO" || type === "CTA")
            return (
              <section className="card" key={section.id}>
                <h2>{data.title}</h2>
                <p>{data.body}</p>
                {type === "HERO" ? (
                  <Link className="button button-primary" href={data.ctaHref}>
                    {data.ctaLabel}
                  </Link>
                ) : (
                  <Link className="button button-primary" href={data.href}>
                    {data.label}
                  </Link>
                )}
              </section>
            );
          if (type === "FEATURES")
            return (
              <div className="card-grid" key={section.id}>
                {data.items.map((item, index) => (
                  <article key={index} className="card">
                    <h2>{item.title}</h2>
                    <p>{item.body}</p>
                  </article>
                ))}
              </div>
            );
          if (type === "COURSES_GRID") {
            const courses = await publishedCourses();
            return courses.length ? (
              <section key={section.id}>
                <h2>{data.title}</h2>
                <div className="card-grid">
                  {courses.map((course) => (
                    <article className="card" key={course.id}>
                      <h3>{course.title}</h3>
                      <p>{course.summary}</p>
                      <Link href={"/courses/" + course.slug}>
                        Explore course
                      </Link>
                    </article>
                  ))}
                </div>
              </section>
            ) : null;
          }
          if (type === "TEACHERS") {
            const teachers = await publicTeachers();
            return teachers.length ? (
              <section key={section.id}>
                <h2>{data.title}</h2>
                <div className="card-grid">
                  {teachers.map((teacher) => (
                    <article className="card" key={teacher.id}>
                      <h3>{teacher.displayName}</h3>
                      <p>{teacher.bio}</p>
                      <Link href={"/teachers/" + teacher.slug}>
                        View profile
                      </Link>
                    </article>
                  ))}
                </div>
              </section>
            ) : null;
          }
          const items = await publicContent(
            type === "FAQ"
              ? "faq"
              : type === "TESTIMONIALS"
                ? "testimonials"
                : "pricing",
          );
          return items.length ? (
            <section key={section.id}>
              <h2>{data.title}</h2>
              <div className="card-grid">
                {items.map((item) => {
                  if ("question" in item)
                    return (
                      <details className="card" key={item.id}>
                        <summary>{item.question}</summary>
                        <p>{item.answer}</p>
                      </details>
                    );
                  if ("quote" in item)
                    return (
                      <figure className="card" key={item.id}>
                        <blockquote>{item.quote}</blockquote>
                        <figcaption>
                          {item.name} · {item.country}
                        </figcaption>
                      </figure>
                    );
                  if ("pricingPlanPrice_planId" in item)
                    return (
                      <article className="card" key={item.id}>
                        <h3>{item.name}</h3>
                        <p>
                          {item.classesPerWeek} classes per week ·{" "}
                          {item.durationMin} minutes
                        </p>
                        {item.pricingPlanPrice_planId.map((price) => (
                          <p key={price.id}>
                            {formatMinor(price.amountMinor, price.currency)}
                          </p>
                        ))}
                      </article>
                    );
                  return null;
                })}
              </div>
            </section>
          ) : null;
        }),
      )}
    </>
  );
}
