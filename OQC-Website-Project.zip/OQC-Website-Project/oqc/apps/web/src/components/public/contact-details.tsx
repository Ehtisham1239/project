import { publicSettings } from "@/server/services/public";
import { settingSchemas } from "@/lib/validation/content";
export async function ContactDetails() {
  const values = Object.fromEntries(
    (await publicSettings()).map((item) => [item.key, item.value]),
  );
  const email = settingSchemas["contact.email"].safeParse(
      values["contact.email"],
    ),
    address = settingSchemas["contact.address"].safeParse(
      values["contact.address"],
    ),
    whatsapp = settingSchemas["contact.whatsapp"].safeParse(
      values["contact.whatsapp"],
    ),
    phones = settingSchemas["contact.phones"].safeParse(
      values["contact.phones"],
    );
  if (
    !email.success &&
    !(address.success && address.data) &&
    !whatsapp.success &&
    !(phones.success && phones.data.length)
  )
    return <p>Official contact details are awaiting confirmation.</p>;
  return (
    <address style={{ fontStyle: "normal" }}>
      {email.success && (
        <p>
          <a href={`mailto:${email.data}`}>{email.data}</a>
        </p>
      )}
      {address.success && address.data && <p>{address.data}</p>}
      {phones.success &&
        phones.data.map((phone) => (
          <p key={phone.number}>
            {phone.label}: <a href={`tel:${phone.number}`}>{phone.number}</a>
          </p>
        ))}
      {whatsapp.success && (
        <p>
          <a
            href={`https://wa.me/${whatsapp.data.slice(1)}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            Contact on WhatsApp
          </a>
        </p>
      )}
    </address>
  );
}
