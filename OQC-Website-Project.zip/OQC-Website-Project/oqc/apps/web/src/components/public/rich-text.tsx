import { renderRichHtml } from "@/lib/validation/richtext";
export function RichText({ document }: { document: unknown }) {
  let html = "";
  try {
    html = renderRichHtml(document);
  } catch {
    return null;
  }
  return (
    <div className="rich-content" dangerouslySetInnerHTML={{ __html: html }} />
  );
}
