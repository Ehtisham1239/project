import Link from "next/link";
import Image from "next/image";
import messages from "@/messages/en.json";
import { publicMenu } from "@/server/services/public";
import { publicSettings } from "@/server/services/public";
import { ContactDetails } from "@/components/public/contact-details";
import { PublicSocialLinks } from "@/components/public/social-links";
export async function Footer() {
  const menu = await publicMenu("FOOTER");
  const entity = (await publicSettings()).find(
    (item) => item.key === "legal.entity",
  )?.value;
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <Image
            src="/brand/logo.jpg"
            alt={messages.brand}
            width={100}
            height={100}
            className="brand-logo"
          />
          <p>{messages.footer}</p>
        </div>
        <div>
          <h2>Explore</h2>
          {(menu.length
            ? menu
            : [
                { href: "/courses", label: "Courses" },
                { href: "/teachers", label: "Teachers" },
                { href: "/pricing", label: "Schedule & fees" },
                { href: "/contact", label: "Contact" },
              ]
          ).map((item) => (
            <Link key={item.href + item.label} href={item.href}>
              {item.label}
            </Link>
          ))}
        </div>
        <div>
          <h2>Care & transparency</h2>
          <Link href="/careers">Careers</Link>
          {[
            "privacy",
            "terms",
            "refund",
            "child-safeguarding",
            "accessibility",
            "ai-disclosure",
          ].map((path) => (
            <Link href={"/" + path} key={path}>
              {path.replaceAll("-", " ")}
            </Link>
          ))}
        </div>
        <div>
          <h2>Contact</h2>
          <ContactDetails />
          <PublicSocialLinks />
        </div>
      </div>
      <div className="container footer-bottom">
        <span>
          © {new Date().getFullYear()}{" "}
          {typeof entity === "string" && entity.trim()
            ? entity
            : messages.brand}
        </span>
        <span>English · AI assistance disabled</span>
      </div>
    </footer>
  );
}
