export const recordFields: Record<
  string,
  {
    key: string;
    label: string;
    type?:
      "text" | "textarea" | "number" | "checkbox" | "list" | "select" | "rich";
    options?: (string | { value: string; label: string })[];
    required?: boolean;
    maxLength?: number;
  }[]
> = {
  menus: [
    {
      key: "menu",
      label: "Navigation location",
      type: "select",
      options: ["HEADER", "FOOTER"],
      required: true,
    },
    { key: "label", label: "Navigation label", required: true },
    { key: "href", label: "Navigation destination", required: true },
    {
      key: "sortOrder",
      label: "Navigation order",
      type: "number",
      required: true,
    },
  ],
  blog: [
    { key: "title", label: "Post title", required: true },
    { key: "slug", label: "Page address", required: true },
    { key: "excerpt", label: "Excerpt", type: "textarea", required: true },
    { key: "body", label: "Post body", type: "rich", required: true },
    { key: "tags", label: "Article topics (comma separated)", type: "list" },
    { key: "seoTitle", label: "Search title", maxLength: 60 },
    {
      key: "seoDescription",
      label: "Search description",
      type: "textarea",
      maxLength: 155,
    },
  ],
  courses: [
    { key: "title", label: "Course title", required: true },
    { key: "slug", label: "Page address", required: true },
    { key: "summary", label: "Summary", type: "textarea", required: true },
    { key: "description", label: "Course description", type: "rich" },
    { key: "ageGroup", label: "Age group", required: true },
    { key: "level", label: "Level", required: true },
    { key: "seoTitle", label: "Search title", maxLength: 60 },
    {
      key: "seoDescription",
      label: "Search description",
      type: "textarea",
      maxLength: 155,
    },
  ],
  teachers: [
    { key: "displayName", label: "Public name", required: true },
    { key: "slug", label: "Page address", required: true },
    {
      key: "gender",
      label: "Gender",
      type: "select",
      options: ["MALE", "FEMALE"],
    },
    { key: "bio", label: "Biography", type: "textarea", required: true },
    {
      key: "languages",
      label: "Languages (comma separated)",
      type: "list",
      required: true,
    },
    {
      key: "verificationNote",
      label: "Owner verification note",
      type: "textarea",
    },
    { key: "isPublic", label: "Public profile", type: "checkbox" },
  ],
  faqs: [
    { key: "question", label: "Question", required: true },
    { key: "answer", label: "Answer", type: "textarea", required: true },
    { key: "category", label: "Category", required: true },
  ],
  testimonials: [
    { key: "name", label: "Consented display name", required: true },
    { key: "role", label: "Relationship or role", required: true },
    { key: "country", label: "Country code", required: true },
    {
      key: "quote",
      label: "Consented statement",
      type: "textarea",
      required: true,
    },
    { key: "consentRecordedAt", label: "Consent timestamp (ISO format)" },
  ],
  pages: [
    { key: "title", label: "Page title", required: true },
    { key: "slug", label: "Page address", required: true },
    { key: "seoTitle", label: "Search title", maxLength: 60 },
    {
      key: "seoDescription",
      label: "Search description",
      type: "textarea",
      maxLength: 155,
    },
    {
      key: "template",
      label: "Template",
      type: "select",
      options: ["STANDARD", "POLICY"],
    },
  ],
  students: [
    { key: "fullName", label: "Learner name", required: true },
    {
      key: "ageBand",
      label: "Age band",
      type: "select",
      options: ["UNDER_6", "6_8", "9_12", "13_17", "18_PLUS"],
    },
    { key: "country", label: "Country code", required: true },
    { key: "timezone", label: "Time zone", required: true },
  ],
  guardians: [
    { key: "fullName", label: "Guardian name", required: true },
    { key: "email", label: "Email", required: true },
    { key: "phone", label: "International phone", required: true },
    { key: "relationship", label: "Relationship", required: true },
    { key: "country", label: "Country code", required: true },
  ],
  "pricing-plans": [
    {
      key: "isPublic",
      label: "Show plan publicly when published",
      type: "checkbox",
    },
    { key: "name", label: "Plan name", required: true },
    {
      key: "billingPeriod",
      label: "Billing period",
      type: "select",
      options: ["MONTHLY", "WEEKLY", "ONE_TIME"],
    },
    {
      key: "classesPerWeek",
      label: "Classes per week",
      type: "number",
      required: true,
    },
    {
      key: "durationMin",
      label: "Class duration (minutes)",
      type: "number",
      required: true,
    },
  ],
};
