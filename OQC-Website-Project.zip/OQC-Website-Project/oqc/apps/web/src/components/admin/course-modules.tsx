"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
type Module = { id: string; title: string; objectives: string };
export function CourseModules({
  id,
  version,
  status,
  initial,
}: {
  id: string;
  version: number;
  status: string;
  initial: Module[];
}) {
  const [items, setItems] = useState(initial),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  function update(index: number, key: "title" | "objectives", value: string) {
    setItems((current) =>
      current.map((item, i) =>
        i === index ? { ...item, [key]: value } : item,
      ),
    );
  }
  function move(index: number, direction: number) {
    setItems((current) => {
      const next = [...current];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Course syllabus</h2>
      {status === "PUBLISHED" ? (
        <p>Return the course to draft before changing its syllabus.</p>
      ) : (
        <form
          className="form"
          onSubmit={async (event) => {
            event.preventDefault();
            setBusy(true);
            setError("");
            try {
              const response = await fetch(
                `/api/v1/admin/courses/${id}/modules`,
                {
                  method: "PUT",
                  headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-Token": await getCsrfToken(),
                  },
                  body: JSON.stringify({
                    version,
                    modules: items.map(({ title, objectives }) => ({
                      title,
                      objectives,
                    })),
                  }),
                },
              );
              const payload = await response.json();
              if (!response.ok)
                throw new Error(
                  payload.error?.message ?? "Unable to save the syllabus.",
                );
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error
                  ? error.message
                  : "Unable to save the syllabus.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <p>Syllabus changes require approval before publication.</p>
          <fieldset disabled={busy || pending}>
            <legend>Modules in teaching order</legend>
            {!items.length && <p>No syllabus modules added.</p>}
            {items.map((item, index) => (
              <div className="card form" key={item.id}>
                <label className="field">
                  <span>Module {index + 1} title</span>
                  <input
                    required
                    minLength={2}
                    maxLength={160}
                    value={item.title}
                    onChange={(event) =>
                      update(index, "title", event.target.value)
                    }
                  />
                </label>
                <div className="field">
                  <label htmlFor={"module-objectives-" + item.id}>
                    Module {index + 1} objectives
                  </label>
                  <textarea
                    id={"module-objectives-" + item.id}
                    required
                    minLength={2}
                    maxLength={3000}
                    value={item.objectives}
                    onChange={(event) =>
                      update(index, "objectives", event.target.value)
                    }
                  />
                </div>
                <div className="actions">
                  <button
                    type="button"
                    className="button button-secondary"
                    disabled={index === 0}
                    aria-label={`Move module ${index + 1} up`}
                    onClick={() => move(index, -1)}
                  >
                    Move up
                  </button>
                  <button
                    type="button"
                    className="button button-secondary"
                    disabled={index === items.length - 1}
                    aria-label={`Move module ${index + 1} down`}
                    onClick={() => move(index, 1)}
                  >
                    Move down
                  </button>
                  <button
                    type="button"
                    className="button button-secondary"
                    aria-label={`Remove module ${index + 1}`}
                    onClick={() =>
                      setItems((current) =>
                        current.filter((_, i) => i !== index),
                      )
                    }
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            <button
              type="button"
              className="button button-secondary"
              disabled={items.length >= 30}
              onClick={() =>
                setItems((current) => [
                  ...current,
                  { id: crypto.randomUUID(), title: "", objectives: "" },
                ])
              }
            >
              Add module
            </button>
          </fieldset>
          {error && <p role="alert">{error}</p>}
          <button className="button button-primary" disabled={busy || pending}>
            {busy ? "Saving…" : "Save syllabus"}
          </button>
        </form>
      )}
    </section>
  );
}
