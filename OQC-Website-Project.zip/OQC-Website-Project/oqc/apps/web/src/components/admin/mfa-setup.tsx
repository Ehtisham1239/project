"use client";
import Link from "next/link";
import { useState } from "react";
export function MfaSetup() {
  const [secret, setSecret] = useState(""),
    [codes, setCodes] = useState<string[]>([]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const values = new FormData(event.currentTarget);
    const token = new URLSearchParams(window.location.hash.slice(1)).get(
      "token",
    );
    try {
      const response = await fetch("/api/v1/auth/mfa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, code: values.get("code") || undefined }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error?.message ?? "Setup failed.");
      if (body.data.secret) setSecret(body.data.secret);
      if (body.data.backupCodes) {
        setCodes(body.data.backupCodes);
        setSecret("");
        history.replaceState(null, "", "/admin/setup");
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  }
  if (codes.length)
    return (
      <section className="card">
        <h2>Save your backup codes</h2>
        <p>
          Each code works once. Store them securely; they will not be shown
          again.
        </p>
        <ul>
          {codes.map((code) => (
            <li key={code}>
              <code>{code}</code>
            </li>
          ))}
        </ul>
        <Link className="button button-primary" href="/admin/login">
          Go to sign in
        </Link>
      </section>
    );
  return (
    <form className="form card" onSubmit={submit}>
      {error && (
        <div className="error-summary" role="alert">
          {error}
        </div>
      )}
      {secret ? (
        <>
          <p>Enter this key in your authenticator app:</p>
          <code style={{ overflowWrap: "anywhere" }}>{secret}</code>
          <div className="field">
            <label htmlFor="mfa-code">Six-digit code</label>
            <input
              id="mfa-code"
              name="code"
              pattern="[0-9]{6}"
              autoComplete="one-time-code"
              required
            />
          </div>
        </>
      ) : (
        <p>Use your one-time setup link to enroll an authenticator.</p>
      )}
      <button className="button button-primary" disabled={busy}>
        {busy
          ? "Please wait…"
          : secret
            ? "Verify authenticator"
            : "Begin enrollment"}
      </button>
    </form>
  );
}
