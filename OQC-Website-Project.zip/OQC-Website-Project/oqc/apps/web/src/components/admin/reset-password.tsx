"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
export function ResetPassword() {
  const token = useRef("");
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [done, setDone] = useState(false);
  useEffect(() => {
    if (!token.current)
      token.current =
        new URLSearchParams(location.hash.slice(1)).get("token") ?? "";
    history.replaceState(null, "", location.pathname);
  }, []);
  if (done)
    return (
      <section className="card">
        <h2>Password changed</h2>
        <p>
          All previous sessions have been signed out. MFA is still required.
        </p>
        <Link className="button button-primary" href="/admin/login">
          Sign in
        </Link>
      </section>
    );
  return (
    <form
      className="form card"
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setBusy(true);
        setError("");
        if (data.get("password") !== data.get("confirmation")) {
          setError("Passwords must match.");
          setBusy(false);
          return;
        }
        try {
          const response = await fetch("/api/v1/auth/reset", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              token: token.current,
              password: data.get("password"),
              code: data.get("code") || undefined,
            }),
          });
          const body = await response.json();
          if (!response.ok)
            throw new Error(body.error?.message ?? "Unable to reset password.");
          token.current = "";
          setDone(true);
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to reset password.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <label>
        New passphrase{" "}
        <input
          name="password"
          type="password"
          autoComplete="new-password"
          minLength={12}
          maxLength={128}
          required
        />
      </label>
      <label>
        Confirm passphrase{" "}
        <input
          name="confirmation"
          type="password"
          autoComplete="new-password"
          required
        />
      </label>
      <label>
        Authenticator or unused backup code{" "}
        <input name="code" autoComplete="one-time-code" />
      </label>
      {error && <p role="alert">{error}</p>}
      <button className="button button-primary" disabled={busy}>
        {busy ? "Updating…" : "Change password"}
      </button>
    </form>
  );
}
