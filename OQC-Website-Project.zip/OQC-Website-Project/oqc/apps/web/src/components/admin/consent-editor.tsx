"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function ConsentEditor({
  current,
}: {
  current: { version: string; trialText: string; contactText: string } | null;
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [saved, setSaved] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <section className="card form" style={{ marginBlock: 24 }}>
      <h2>Admissions consent notice</h2>
      <p>
        {current
          ? "Current approved version: " + current.version
          : "No approved consent notice. Production submissions remain closed."}
      </p>
      <p>
        Obtain the owner’s legal approval and confirm your password and MFA
        below before publishing. Existing versions are retained; changed wording
        needs a new identifier.
      </p>
      <form
        className="form"
        onSubmit={async (event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          setBusy(true);
          setError("");
          setSaved("");
          try {
            const response = await fetch("/api/v1/admin/consent", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "X-CSRF-Token": await getCsrfToken(),
              },
              body: JSON.stringify({
                version: data.get("version"),
                trialText: data.get("trialText"),
                contactText: data.get("contactText"),
                ownerApproved: data.get("ownerApproved") === "on",
              }),
            });
            const result = await response.json();
            if (!response.ok)
              throw new Error(
                result.error?.message ?? "Unable to approve this notice.",
              );
            setSaved("Consent notice approved.");
            startTransition(() => router.refresh());
          } catch (error) {
            setError(
              error instanceof Error
                ? error.message
                : "Unable to approve this notice.",
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        <fieldset disabled={busy || pending}>
          <legend>New approved version</legend>
          <div className="field">
            <label htmlFor="consent-version">Consent version identifier</label>
            <input
              id="consent-version"
              name="version"
              required
              maxLength={64}
              pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}"
            />
          </div>
          <div className="field">
            <label htmlFor="consent-trialText">Trial consent wording</label>
            <textarea
              id="consent-trialText"
              name="trialText"
              required
              minLength={20}
              maxLength={2000}
              defaultValue={current?.trialText ?? ""}
            />
          </div>
          <div className="field">
            <label htmlFor="consent-contactText">Contact consent wording</label>
            <textarea
              id="consent-contactText"
              name="contactText"
              required
              minLength={20}
              maxLength={2000}
              defaultValue={current?.contactText ?? ""}
            />
          </div>
          <label>
            <input name="ownerApproved" type="checkbox" required /> The owner
            has approved this exact wording for publication.
          </label>
        </fieldset>
        {error && <p role="alert">{error}</p>}
        {saved && <p role="status">{saved}</p>}
        <button className="button button-primary" disabled={busy || pending}>
          {busy ? "Approving…" : "Approve new consent version"}
        </button>
      </form>
    </section>
  );
}
