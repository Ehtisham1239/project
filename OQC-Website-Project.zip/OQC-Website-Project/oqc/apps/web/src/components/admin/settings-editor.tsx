"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
const fields = [
  { key: "site.name", label: "Site name" },
  { key: "contact.email", label: "Official contact email", type: "email" },
  { key: "contact.address", label: "College contact address" },
  {
    key: "contact.whatsapp",
    label: "Official WhatsApp number (international format)",
  },
  { key: "legal.entity", label: "Legal entity name" },
  { key: "legal.registration", label: "Verified registration information" },
  {
    key: "retention.contactDays",
    label: "Approved contact retention period in days",
    type: "number",
    sensitive: true,
  },
  {
    key: "scheduling.meetingDomains",
    label: "Approved meeting hostnames (comma separated)",
    type: "list",
    sensitive: true,
  },
  {
    key: "readiness.contactForFeesAccepted",
    label: "Owner accepts contact-for-fees wording",
    type: "checkbox",
    sensitive: true,
  },
  {
    key: "readiness.botProtectionDisabledAccepted",
    label: "Owner accepts launching without bot protection",
    type: "checkbox",
    sensitive: true,
  },
  {
    key: "readiness.mailerDisabledAccepted",
    label: "Owner accepts launching without email delivery",
    type: "checkbox",
    sensitive: true,
  },
  {
    key: "readiness.brandApproved",
    label: "Owner has reviewed and approved the original logo and branding",
    type: "checkbox",
    sensitive: true,
  },
  {
    key: "readiness.ownerSignoff",
    label: "Owner has completed UAT and explicitly approved launch",
    type: "checkbox",
    sensitive: true,
  },
];
export function SettingsEditor({
  values,
  security,
}: {
  values: Record<string, unknown>;
  security: boolean;
}) {
  const [error, setError] = useState(""),
    [saved, setSaved] = useState(""),
    [busy, setBusy] = useState(""),
    [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <>
      {error && (
        <p className="error-summary" role="alert">
          {error}
        </p>
      )}
      {saved && <p role="status">{saved}</p>}
      {fields
        .filter((field) => !field.sensitive || security)
        .map((field) => (
          <form
            className="card form"
            style={{ marginBlock: 16 }}
            key={field.key + JSON.stringify(values[field.key])}
            onSubmit={async (event) => {
              event.preventDefault();
              setError("");
              setSaved("");
              setBusy(field.key);
              const data = new FormData(event.currentTarget);
              const value =
                field.type === "checkbox"
                  ? data.get("value") === "on"
                  : field.type === "number"
                    ? Number(data.get("value"))
                    : field.type === "list"
                      ? String(data.get("value"))
                          .split(",")
                          .map((x) => x.trim())
                          .filter(Boolean)
                      : data.get("value");
              try {
                const response = await fetch("/api/v1/admin/settings", {
                  method: "PUT",
                  headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-Token": await getCsrfToken(),
                  },
                  body: JSON.stringify({ key: field.key, value }),
                });
                const body = await response.json();
                if (!response.ok)
                  throw new Error(body.error?.message ?? "Unable to save.");
                setSaved(field.label + " saved.");
                startTransition(() => router.refresh());
              } catch (error) {
                setError(
                  error instanceof Error ? error.message : "Unable to save.",
                );
              } finally {
                setBusy("");
              }
            }}
          >
            <label htmlFor={field.key}>{field.label}</label>
            <input
              id={field.key}
              name="value"
              type={
                field.type === "checkbox"
                  ? "checkbox"
                  : field.type === "number"
                    ? "number"
                    : field.type === "email"
                      ? "email"
                      : "text"
              }
              defaultChecked={
                field.type === "checkbox"
                  ? values[field.key] === true
                  : undefined
              }
              defaultValue={
                field.type === "checkbox"
                  ? undefined
                  : Array.isArray(values[field.key])
                    ? (values[field.key] as string[]).join(", ")
                    : String(values[field.key] ?? "")
              }
              min={field.type === "number" ? 1 : undefined}
              required={field.type !== "checkbox"}
            />
            {values[field.key] === undefined && <p>Not configured.</p>}
            {field.sensitive && (
              <p>
                Requires recent identity confirmation. Record only approvals the
                owner has actually given.
              </p>
            )}
            <button
              className="button button-secondary"
              disabled={!!busy || pending}
            >
              {busy === field.key ? "Saving…" : "Save"}
            </button>
          </form>
        ))}
    </>
  );
}
