"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function InvoiceVoid({ id, version }: { id: string; version: number }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <form
      className="card form"
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        const input = new FormData(event.currentTarget);
        setError("");
        setBusy(true);
        try {
          const response = await fetch(`/api/v1/admin/invoices/${id}/void`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              version,
              reason: input.get("reason"),
              confirmed: input.get("confirm") === "on",
            }),
          });
          const payload = await response.json();
          if (!response.ok)
            throw new Error(
              payload.error?.message ?? "Unable to void this invoice.",
            );
          startTransition(() => router.refresh());
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to void this invoice.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Void an unpaid invoice</h2>
      <p>
        Invoices with recorded payments cannot be voided. Confirm your password
        and MFA in Your account first if your recent verification has expired.
      </p>
      <fieldset disabled={busy || pending}>
        <legend>Void confirmation</legend>
        <div className="field">
          <label htmlFor="void-reason">Reason for voiding</label>
          <select id="void-reason" name="reason" required defaultValue="">
            <option value="" disabled>
              Choose a reason
            </option>
            <option value="DUPLICATE">Duplicate invoice</option>
            <option value="INCORRECT_DETAILS">Incorrect invoice details</option>
            <option value="CANCELLED_ENROLLMENT">Cancelled enrollment</option>
            <option value="OTHER">Other</option>
          </select>
        </div>
        <label>
          <input type="checkbox" name="confirm" required /> I confirm this
          invoice should be voided.
        </label>
        <button className="button button-secondary" type="submit">
          Void invoice
        </button>
      </fieldset>
      {error && <p role="alert">{error}</p>}
    </form>
  );
}
