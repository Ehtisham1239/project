"use client";
type Data = Record<string, unknown>;
export function SectionFields({
  type,
  data,
  index,
  onChange,
}: {
  type: string;
  data: Data;
  index: number;
  onChange: (data: Data) => void;
}) {
  function field(key: string, label: string, multiline = false) {
    const id = `section-${index}-${key}`,
      props = {
        id,
        value: typeof data[key] === "string" ? (data[key] as string) : "",
        maxLength: multiline ? 10000 : 160,
        onChange: (
          event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
        ) => onChange({ ...data, [key]: event.target.value }),
      };
    return (
      <div className="field" key={key}>
        <label htmlFor={id}>
          Section {index + 1} {label}
        </label>
        {multiline ? <textarea {...props} /> : <input {...props} />}
      </div>
    );
  }
  if (type === "FEATURES") {
    const items = Array.isArray(data.items)
      ? (data.items as { title: string; body: string }[])
      : [];
    return (
      <>
        {items.map((item, row) => (
          <div className="card" key={row}>
            <div className="field">
              <label htmlFor={`feature-${index}-${row}-title`}>
                Feature {row + 1} title
              </label>
              <input
                id={`feature-${index}-${row}-title`}
                value={item.title}
                maxLength={160}
                onChange={(event) =>
                  onChange({
                    items: items.map((value, n) =>
                      n === row
                        ? { ...value, title: event.target.value }
                        : value,
                    ),
                  })
                }
              />
            </div>
            <div className="field">
              <label htmlFor={`feature-${index}-${row}-body`}>
                Feature {row + 1} description
              </label>
              <textarea
                id={`feature-${index}-${row}-body`}
                value={item.body}
                maxLength={10000}
                onChange={(event) =>
                  onChange({
                    items: items.map((value, n) =>
                      n === row
                        ? { ...value, body: event.target.value }
                        : value,
                    ),
                  })
                }
              />
            </div>
            <button
              type="button"
              className="button button-secondary"
              onClick={() =>
                onChange({ items: items.filter((_, n) => n !== row) })
              }
            >
              Remove feature {row + 1}
            </button>
          </div>
        ))}
        <button
          className="button button-secondary"
          type="button"
          disabled={items.length >= 8}
          onClick={() =>
            onChange({ items: [...items, { title: "", body: "" }] })
          }
        >
          Add feature
        </button>
      </>
    );
  }
  if (type === "HERO" || type === "CTA")
    return (
      <>
        {field("title", "heading")}
        {field("body", "description", true)}
        {field(type === "HERO" ? "ctaLabel" : "label", "button label")}
        {field(type === "HERO" ? "ctaHref" : "href", "button destination")}
        <p>Use an internal destination beginning with /.</p>
      </>
    );
  return field("title", "heading");
}
