"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { DateTime } from "luxon";
import { getCsrfToken } from "@/lib/auth/client";
export function PublicationSchedule({
  resource,
  id,
  version,
  status,
  scheduled,
}: {
  resource: string;
  id: string;
  version: number;
  status: string;
  scheduled: { publishAt: string; version: number } | null;
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition(),
    router = useRouter();
  async function save(method: "POST" | "DELETE", publishAt?: string) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(
        `/api/v1/admin/${resource}/${id}/schedule-publication`,
        {
          method,
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": await getCsrfToken(),
          },
          body: JSON.stringify({
            version,
            ...(publishAt ? { publishAt } : {}),
          }),
        },
      );
      const result = await response.json();
      if (!response.ok)
        throw new Error(
          result.error?.message ?? "Unable to update publication schedule.",
        );
      startTransition(() => router.refresh());
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Unable to update publication schedule.",
      );
    } finally {
      setBusy(false);
    }
  }
  const active = scheduled?.version === version ? scheduled : null;
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Scheduled publication</h2>
      {active && (
        <p>
          Scheduled for {active.publishAt} (UTC). Publication runs through the
          website worker and rechecks approval and staff permissions.
        </p>
      )}
      {status !== "APPROVED" ? (
        <p>Approve this content version before scheduling publication.</p>
      ) : (
        <form
          className="form"
          onSubmit={async (event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget),
              input = String(data.get("time")),
              local = DateTime.fromISO(input, {
                zone: String(data.get("zone")),
              });
            if (
              !local.isValid ||
              local.toFormat("yyyy-MM-dd'T'HH:mm") !== input ||
              local.getPossibleOffsets().length !== 1
            ) {
              setError(
                "Choose a valid, unambiguous local time and IANA time zone.",
              );
              return;
            }
            await save("POST", local.toUTC().toISO()!);
          }}
        >
          <fieldset disabled={busy || pending}>
            <legend>Choose a publication time</legend>
            <div className="field">
              <label htmlFor="publish-time">Publication date and time</label>
              <input
                id="publish-time"
                name="time"
                type="datetime-local"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="publish-zone">Publication time zone</label>
              <input
                id="publish-zone"
                name="zone"
                defaultValue="UTC"
                required
              />
            </div>
            <button className="button" type="submit">
              Schedule publication
            </button>
          </fieldset>
        </form>
      )}
      {active && (
        <button
          className="button button-secondary"
          type="button"
          disabled={busy || pending}
          onClick={() => void save("DELETE")}
        >
          Cancel publication schedule
        </button>
      )}
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
