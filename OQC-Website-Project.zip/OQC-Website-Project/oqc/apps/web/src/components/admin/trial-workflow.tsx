"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
import {
  canTransition,
  trialStates,
  type TrialState,
} from "@/lib/admissions/state-machine";
export function TrialWorkflow({
  id,
  status,
  version,
  timezone,
  assignedTeacherId,
  teachers,
  permissions,
}: {
  id: string;
  status: TrialState;
  version: number;
  timezone: string;
  assignedTeacherId?: string | null;
  teachers: { id: string; displayName: string }[];
  permissions: {
    assign: boolean;
    status: boolean;
    convert: boolean;
    notes: boolean;
  };
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  async function send(action: string, body: unknown) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`/api/v1/admin/trials/${id}/${action}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify(body),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(payload.error?.message ?? "Unable to save.");
      startTransition(() => router.refresh());
    } catch (error) {
      setError(error instanceof Error ? error.message : "Unable to save.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="card" style={{ marginBlock: 24 }}>
      <h2>Admissions workflow</h2>
      <p>Current status: {status.toLowerCase().replaceAll("_", " ")}</p>
      {assignedTeacherId && (
        <p>
          Assigned teacher:{" "}
          {teachers.find((teacher) => teacher.id === assignedTeacherId)
            ?.displayName ?? "Assigned staff teacher"}
        </p>
      )}
      <fieldset disabled={busy || pending}>
        <legend>Trial actions</legend>
        <p>
          Learner time zone: {timezone}. Assignment time below is entered in
          UTC.
        </p>
        {error && (
          <p className="error-summary" role="alert">
            {error}
          </p>
        )}
        {permissions.assign &&
          ["NEW", "REVIEWED"].includes(status) &&
          (teachers.length ? (
            <form
              className="form"
              onSubmit={(event) => {
                event.preventDefault();
                const data = new FormData(event.currentTarget);
                void send("assign", {
                  teacherId: data.get("teacherId"),
                  startsAtUtc: new Date(
                    String(data.get("startsAtUtc")) + "Z",
                  ).toISOString(),
                  durationMin: Number(data.get("durationMin")),
                  version,
                });
              }}
            >
              <div className="field">
                <label htmlFor="trial-teacher">Course teacher</label>
                <select id="trial-teacher" name="teacherId">
                  {teachers.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.displayName}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label htmlFor="trial-date">Trial start (UTC)</label>
                <input
                  id="trial-date"
                  name="startsAtUtc"
                  type="datetime-local"
                  required
                />
              </div>
              <div className="field">
                <label htmlFor="trial-duration">Duration in minutes</label>
                <input
                  id="trial-duration"
                  name="durationMin"
                  type="number"
                  min={1}
                  max={240}
                  required
                />
              </div>
              <button
                className="button button-primary"
                disabled={busy || pending}
              >
                Assign trial class
              </button>
            </form>
          ) : (
            <p>
              No active course teachers. Assign a course on a verified teacher
              record first.
            </p>
          ))}
        {permissions.status && (
          <form
            className="form"
            onSubmit={(event) => {
              event.preventDefault();
              const data = new FormData(event.currentTarget);
              void send("status", {
                status: data.get("status"),
                note: data.get("note") || undefined,
                version,
              });
            }}
          >
            <div className="field">
              <label htmlFor="trial-status">Next status</label>
              <select id="trial-status" name="status" required>
                <option value="">Choose a status</option>
                {trialStates
                  .filter(
                    (next) =>
                      next !== "ENROLLED" && canTransition(status, next),
                  )
                  .map((next) => (
                    <option key={next}>{next}</option>
                  ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="trial-reason">Change note</label>
              <textarea id="trial-reason" name="note" maxLength={1000} />
            </div>
            <button
              className="button button-secondary"
              disabled={busy || pending}
            >
              Update status
            </button>
          </form>
        )}
        {permissions.convert && status === "COMPLETED" && (
          <form
            className="form"
            onSubmit={(event) => {
              event.preventDefault();
              void send("convert", { version, confirmed: true });
            }}
          >
            <label>
              <input type="checkbox" required /> I confirm enrollment and
              creation of the learner and guardian records.
            </label>
            <button
              className="button button-primary"
              disabled={busy || pending}
            >
              Enroll learner
            </button>
          </form>
        )}
        {permissions.notes && (
          <form
            className="form"
            onSubmit={(event) => {
              event.preventDefault();
              void send("notes", {
                body: new FormData(event.currentTarget).get("body"),
              });
            }}
          >
            <div className="field">
              <label htmlFor="trial-note">Internal note</label>
              <textarea id="trial-note" name="body" required maxLength={1000} />
            </div>
            <button
              className="button button-secondary"
              disabled={busy || pending}
            >
              Add note
            </button>
          </form>
        )}
      </fieldset>
    </section>
  );
}
