"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function SessionList({
  sessions,
}: {
  sessions: {
    id: string;
    createdAt: string;
    lastSeenAt: string;
    isCurrent: boolean;
  }[];
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  async function revoke(target: string, signsOut: boolean) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/v1/auth/sessions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": await getCsrfToken(),
        },
        body: JSON.stringify({ target }),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(
          payload.error?.message ?? "Unable to revoke the session.",
        );
      startTransition(() => {
        if (signsOut) router.replace("/admin/login");
        router.refresh();
      });
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Unable to revoke the session.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="card form" style={{ marginBlock: 24 }}>
      <h2>Active sessions</h2>
      <p>
        A browser session may cover several tabs. Revoke a session you no longer
        use.
      </p>
      {sessions.map((session) => (
        <div className="card" key={session.id}>
          <h3>
            {session.isCurrent ? "This browser" : "Another browser session"}
          </h3>
          <p>
            Signed in:{" "}
            <time dateTime={session.createdAt}>
              {new Date(session.createdAt).toUTCString()}
            </time>
          </p>
          <p>
            Last activity:{" "}
            <time dateTime={session.lastSeenAt}>
              {new Date(session.lastSeenAt).toUTCString()}
            </time>
          </p>
          <button
            className="button button-secondary"
            disabled={busy || pending}
            onClick={() => revoke(session.id, session.isCurrent)}
          >
            {session.isCurrent ? "Sign out this browser" : "Revoke session"}
          </button>
        </div>
      ))}
      {error && <p role="alert">{error}</p>}
      <button
        className="button button-secondary"
        disabled={busy || pending}
        onClick={() => revoke("all", true)}
      >
        Sign out everywhere
      </button>
    </section>
  );
}
