"use client";
import { useState } from "react";
import { getCsrfToken } from "@/lib/auth/client";
export function InvoicePdf({ id, number }: { id: string; number: string }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <div className="card form" style={{ marginBlock: 24 }}>
      <h2>Invoice document</h2>
      <p>
        Confirm your password and MFA from Your account if your last
        verification was more than five minutes ago.
      </p>
      <button
        className="button button-secondary"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError("");
          try {
            const response = await fetch(`/api/v1/admin/invoices/${id}/pdf`, {
              method: "POST",
              headers: { "X-CSRF-Token": await getCsrfToken() },
            });
            if (!response.ok) {
              const payload = await response.json();
              throw new Error(
                payload.error?.message ?? "Unable to export this invoice.",
              );
            }
            const url = URL.createObjectURL(await response.blob()),
              anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = number.replace(/[^a-zA-Z0-9_-]/g, "_") + ".pdf";
            document.body.append(anchor);
            anchor.click();
            anchor.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
          } catch (error) {
            setError(
              error instanceof Error
                ? error.message
                : "Unable to export this invoice.",
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        {busy ? "Preparing…" : "Download invoice PDF"}
      </button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
