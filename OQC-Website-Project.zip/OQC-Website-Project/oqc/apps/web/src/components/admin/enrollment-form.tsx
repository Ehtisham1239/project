"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
type Choices = {
  students: { id: string; fullName: string }[];
  courses: { id: string; title: string }[];
  teachers: { id: string; displayName: string; courseIds: string[] }[];
  plans: { id: string; name: string; courseId: string | null }[];
};
export function EnrollmentForm({ choices }: { choices: Choices }) {
  const [course, setCourse] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <details className="card" style={{ marginBlock: 24 }}>
      <summary>Enroll an existing learner</summary>
      {!choices.students.length || !choices.courses.length ? (
        <p>Create an active learner and publish a course before enrolling.</p>
      ) : (
        <form
          className="form"
          style={{ marginTop: 24 }}
          onSubmit={async (event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            setBusy(true);
            setError("");
            try {
              const response = await fetch("/api/v1/admin/enrollments", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "X-CSRF-Token": await getCsrfToken(),
                },
                body: JSON.stringify({
                  studentId: data.get("studentId"),
                  courseId: course,
                  teacherId: data.get("teacherId"),
                  planId: data.get("planId") || undefined,
                  startDate: data.get("startDate"),
                  endDate: data.get("endDate") || undefined,
                }),
              });
              const payload = await response.json();
              if (!response.ok)
                throw new Error(
                  payload.error?.message ?? "Unable to enroll this learner.",
                );
              startTransition(() => router.refresh());
            } catch (error) {
              setError(
                error instanceof Error
                  ? error.message
                  : "Unable to enroll this learner.",
              );
            } finally {
              setBusy(false);
            }
          }}
        >
          <fieldset disabled={busy || pending}>
            <legend>Enrollment details</legend>
            <div className="field">
              <label htmlFor="enroll-student">Learner</label>
              <select
                id="enroll-student"
                name="studentId"
                required
                defaultValue=""
              >
                <option value="">Choose a learner</option>
                {choices.students.map((row) => (
                  <option key={row.id} value={row.id}>
                    {row.fullName}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="enroll-course">Published course</label>
              <select
                id="enroll-course"
                required
                value={course}
                onChange={(event) => setCourse(event.target.value)}
              >
                <option value="">Choose a course</option>
                {choices.courses.map((row) => (
                  <option key={row.id} value={row.id}>
                    {row.title}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="enroll-teacher">Course teacher</label>
              <select
                key={"teacher-" + course}
                id="enroll-teacher"
                name="teacherId"
                required
                defaultValue=""
              >
                <option value="">Choose an assigned teacher</option>
                {choices.teachers
                  .filter((row) => row.courseIds.includes(course))
                  .map((row) => (
                    <option key={row.id} value={row.id}>
                      {row.displayName}
                    </option>
                  ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="enroll-plan">Pricing plan (optional)</label>
              <select
                key={"plan-" + course}
                id="enroll-plan"
                name="planId"
                defaultValue=""
              >
                <option value="">No plan selected</option>
                {choices.plans
                  .filter((row) => !row.courseId || row.courseId === course)
                  .map((row) => (
                    <option key={row.id} value={row.id}>
                      {row.name}
                    </option>
                  ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="enroll-start">Enrollment start</label>
              <input id="enroll-start" name="startDate" type="date" required />
            </div>
            <div className="field">
              <label htmlFor="enroll-end">Enrollment end (optional)</label>
              <input id="enroll-end" name="endDate" type="date" />
            </div>
          </fieldset>
          {error && <p role="alert">{error}</p>}
          <button className="button button-primary" disabled={busy || pending}>
            {busy ? "Enrolling…" : "Confirm enrollment"}
          </button>
        </form>
      )}
    </details>
  );
}
