"use client";
import { contactTransitions } from "@/lib/validation/contact-workflow";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";

export function ContactWorkflow({
  id,
  updatedAt,
  status,
  assignedToUserId,
  operators,
}: {
  id: string;
  updatedAt: string;
  status: string;
  assignedToUserId: string | null;
  operators: { id: string; name: string }[];
}) {
  const [next, setNext] = useState(status),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <form
      className="card form"
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setBusy(true);
        setError("");
        try {
          const response = await fetch(
            `/api/v1/admin/contact-messages/${id}/workflow`,
            {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                "X-CSRF-Token": await getCsrfToken(),
              },
              body: JSON.stringify({
                updatedAt,
                status: next,
                assignedToUserId: data.get("operator") || null,
                replyConfirmed: data.get("replyConfirmed") === "on",
              }),
            },
          );
          const payload = await response.json();
          if (!response.ok)
            throw new Error(
              payload.error?.message ?? "Unable to update this message.",
            );
          startTransition(() => router.refresh());
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to update this message.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Contact workflow</h2>
      <p>Current status: {status.toLowerCase()}</p>
      <fieldset disabled={busy || pending}>
        <legend>Review and assignment</legend>
        <div className="field">
          <label htmlFor="contact-operator">Assigned operator</label>
          <select
            id="contact-operator"
            name="operator"
            defaultValue={assignedToUserId ?? ""}
          >
            <option value="">Unassigned</option>
            {operators.map((operator) => (
              <option key={operator.id} value={operator.id}>
                {operator.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="contact-status">Message status</label>
          <select
            id="contact-status"
            value={next}
            onChange={(event) => setNext(event.target.value)}
          >
            {[status, ...contactTransitions[status]].map((value) => (
              <option key={value} value={value}>
                {value.toLowerCase()}
              </option>
            ))}
          </select>
        </div>
        {next === "REPLIED" && (
          <label>
            <input name="replyConfirmed" type="checkbox" required /> I have
            already replied to this person through an approved channel.
          </label>
        )}
      </fieldset>
      {error && <p role="alert">{error}</p>}
      <button className="button button-secondary" disabled={busy || pending}>
        {busy ? "Saving…" : "Save message workflow"}
      </button>
    </form>
  );
}
