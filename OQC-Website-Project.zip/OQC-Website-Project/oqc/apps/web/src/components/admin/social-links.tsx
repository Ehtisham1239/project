"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function SocialLinks({
  initial,
}: {
  initial: { label: string; url: string }[];
}) {
  const [links, setLinks] = useState(initial),
    [error, setError] = useState(""),
    [saved, setSaved] = useState(false),
    [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  return (
    <form
      className="card form"
      onChange={() => setSaved(false)}
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        setBusy(true);
        setError("");
        setSaved(false);
        try {
          const response = await fetch("/api/v1/admin/settings", {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({ key: "social.links", value: links }),
          });
          const result = await response.json();
          if (!response.ok)
            throw new Error(
              result.error?.message ?? "Unable to save social links.",
            );
          startTransition(() => router.refresh());
          setSaved(true);
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : "Unable to save social links.",
          );
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>Website social links</h2>
      <p>
        Add only owner-approved public profiles. Saved changes appear on the
        website.
      </p>
      <fieldset disabled={busy || pending}>
        <legend>Public profiles</legend>
        {links.map((link, index) => (
          <div className="card" key={index}>
            <div className="field">
              <label htmlFor={`social-label-${index}`}>
                Profile {index + 1} label
              </label>
              <input
                id={`social-label-${index}`}
                value={link.label}
                required
                maxLength={40}
                onChange={(event) =>
                  setLinks((current) =>
                    current.map((item, row) =>
                      row === index
                        ? { ...item, label: event.target.value }
                        : item,
                    ),
                  )
                }
              />
            </div>
            <div className="field">
              <label htmlFor={`social-url-${index}`}>
                Profile {index + 1} HTTPS URL
              </label>
              <input
                id={`social-url-${index}`}
                type="url"
                value={link.url}
                required
                maxLength={2048}
                onChange={(event) =>
                  setLinks((current) =>
                    current.map((item, row) =>
                      row === index
                        ? { ...item, url: event.target.value }
                        : item,
                    ),
                  )
                }
              />
            </div>
            <button
              type="button"
              className="button button-secondary"
              onClick={() => {
                setSaved(false);
                setLinks((current) =>
                  current.filter((_, row) => row !== index),
                );
              }}
            >
              Remove profile {index + 1}
            </button>
          </div>
        ))}
        <div className="toolbar">
          <button
            className="button button-secondary"
            type="button"
            disabled={links.length >= 8}
            onClick={() => {
              setSaved(false);
              setLinks((current) => [...current, { label: "", url: "" }]);
            }}
          >
            Add social profile
          </button>
          <button className="button" type="submit">
            {busy || pending ? "Saving social links…" : "Save social links"}
          </button>
        </div>
      </fieldset>
      {error && <p role="alert">{error}</p>}
      {saved && !busy && !pending && <p role="status">Social links saved.</p>}
    </form>
  );
}
