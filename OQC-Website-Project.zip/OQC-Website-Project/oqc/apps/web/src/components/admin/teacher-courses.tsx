"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getCsrfToken } from "@/lib/auth/client";
export function TeacherCourses({
  id,
  version,
  courses,
  selected,
}: {
  id: string;
  version: number;
  courses: { id: string; title: string }[];
  selected: string[];
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <form
      className="card form"
      style={{ marginBlock: 24 }}
      onSubmit={async (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setBusy(true);
        setError("");
        try {
          const response = await fetch(`/api/v1/admin/teachers/${id}/courses`, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              "X-CSRF-Token": await getCsrfToken(),
            },
            body: JSON.stringify({
              version,
              courseIds: data.getAll("courseIds"),
            }),
          });
          const payload = await response.json();
          if (!response.ok)
            throw new Error(payload.error?.message ?? "Unable to save.");
          startTransition(() => router.refresh());
        } catch (error) {
          setError(error instanceof Error ? error.message : "Unable to save.");
        } finally {
          setBusy(false);
        }
      }}
    >
      <fieldset>
        <legend>Courses taught</legend>
        {courses.length ? (
          courses.map((course) => (
            <label className="field" key={course.id}>
              <span>
                <input
                  type="checkbox"
                  name="courseIds"
                  value={course.id}
                  defaultChecked={selected.includes(course.id)}
                />{" "}
                {course.title}
              </span>
            </label>
          ))
        ) : (
          <p>Create a course before assigning teachers.</p>
        )}
      </fieldset>
      {error && <p role="alert">{error}</p>}
      <button className="button button-secondary" disabled={busy || pending}>
        {busy ? "Saving…" : "Save course assignments"}
      </button>
    </form>
  );
}
