import { richDocumentSchema } from "@/lib/validation/richtext";
export function readableRichText(value: unknown): string {
  const parsed = richDocumentSchema.safeParse(value);
  if (!parsed.success) return "";
  const pending = [...(parsed.data.content ?? [])],
    lines: string[] = [];
  while (pending.length) {
    const node = pending.shift()!;
    if (node.text) lines.push(node.text);
    if (node.content) pending.unshift(...node.content);
  }
  return lines.join(" ");
}
export function revisionFields(snapshot: unknown): Record<string, string> {
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot))
    return {};
  const row = snapshot as Record<string, unknown>,
    fields: Record<string, string> = {};
  for (const [key, label] of Object.entries({
    title: "Title",
    slug: "Page address",
    summary: "Summary",
    excerpt: "Excerpt",
    ageGroup: "Age group",
    level: "Level",
    durationText: "Duration",
    seoTitle: "Search title",
    seoDescription: "Search description",
  }))
    if (Object.hasOwn(row, key))
      fields[label] = typeof row[key] === "string" ? (row[key] as string) : "";
  if (row.description || row.body)
    fields.Content = readableRichText(row.description ?? row.body);
  if (Array.isArray(row.tags))
    fields.Topics = row.tags
      .filter((item) => typeof item === "string")
      .join(", ");
  if (Array.isArray(row.modules))
    fields.Syllabus = row.modules
      .map((item) => {
        const syllabusItem = item as Record<string, unknown>;
        return `${String(syllabusItem.title ?? "")}\n${String(syllabusItem.objectives ?? "")}`;
      })
      .join("\n\n");
  if (Array.isArray(row.pageSection_pageId))
    fields.Sections = row.pageSection_pageId
      .map((item) => {
        const section = item as Record<string, unknown>,
          data = section.data as Record<string, unknown> | undefined;
        return [
          data?.title,
          data?.body,
          data?.text,
          readableRichText(data?.document),
        ]
          .filter((value) => typeof value === "string" && value.length)
          .join("\n");
      })
      .join("\n\n");
  return fields;
}
