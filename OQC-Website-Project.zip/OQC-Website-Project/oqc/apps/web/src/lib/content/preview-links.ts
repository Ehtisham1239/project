import { privateHash, safeEqual } from "@/lib/auth/crypto";
const lifetime = 10 * 60 * 1000;
export function previewSignature(
  sessionId: string,
  resource: string,
  id: string,
  version: number,
  expires: number,
) {
  return privateHash(
    `content-preview:v1:${sessionId}:${resource}:${id}:${version}:${expires}`,
  );
}
export function createPreviewLink(
  sessionId: string,
  resource: string,
  id: string,
  version: number,
  now = Date.now(),
) {
  const expires = now + lifetime,
    signature = previewSignature(sessionId, resource, id, version, expires);
  return `/admin/preview/${resource}/${id}?${new URLSearchParams({ version: String(version), expires: String(expires), signature })}`;
}
export function validPreviewLink(
  sessionId: string,
  resource: string,
  id: string,
  query: Record<string, string | string[] | undefined>,
  now = Date.now(),
) {
  if (
    typeof query.version !== "string" ||
    typeof query.expires !== "string" ||
    typeof query.signature !== "string" ||
    !/^[1-9]\d{0,9}$/.test(query.version) ||
    !/^\d{13}$/.test(query.expires) ||
    !/^[a-f0-9]{64}$/.test(query.signature)
  )
    return false;
  const version = Number(query.version),
    expires = Number(query.expires);
  return (
    expires > now &&
    expires <= now + lifetime &&
    safeEqual(
      query.signature,
      previewSignature(sessionId, resource, id, version, expires),
    )
  );
}
