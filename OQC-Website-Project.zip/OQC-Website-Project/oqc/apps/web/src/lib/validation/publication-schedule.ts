import { z } from "zod";
export const schedulePublicationSchema = z
  .object({ version: z.number().int().positive(), publishAt: z.iso.datetime() })
  .strict();
export const cancelPublicationSchema = z
  .object({ version: z.number().int().positive() })
  .strict();
export const publicationJobSchema = z
  .object({
    resource: z.enum(["courses", "blog", "pages"]),
    id: z.uuid(),
    version: z.number().int().positive(),
    actorId: z.uuid(),
    publishAt: z.iso.datetime(),
  })
  .strict();
