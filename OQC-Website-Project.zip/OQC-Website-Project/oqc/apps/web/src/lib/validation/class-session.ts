import { z } from "zod";
export const rescheduleSchema = z
  .object({
    version: z.number().int().positive(),
    startsAtUtc: z.iso.datetime(),
    durationMin: z.number().int().min(1).max(240),
    meetingUrl: z.url().max(2000).nullable().optional(),
  })
  .strict();
export const sessionStatusSchema = z
  .object({
    version: z.number().int().positive(),
    status: z.enum(["HELD", "CANCELLED"]),
  })
  .strict();
