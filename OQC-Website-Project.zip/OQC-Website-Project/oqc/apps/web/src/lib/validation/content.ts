import { z } from "zod";
import { richDocumentSchema } from "./richtext";
const text = z.string().trim().max(10000),
  title = z.string().trim().min(2).max(160),
  href = z.string().regex(/^\/(?!\/)[a-zA-Z0-9/_-]*$/);
export const sectionDataSchema = z.discriminatedUnion("type", [
  z
    .object({
      type: z.literal("HERO"),
      data: z
        .object({ title, body: text, ctaLabel: title, ctaHref: href })
        .strict(),
    })
    .strict(),
  z
    .object({
      type: z.literal("RICH_TEXT"),
      data: z
        .object({
          text: text.optional(),
          document: richDocumentSchema.optional(),
        })
        .strict()
        .refine(
          (value) => value.text !== undefined || value.document !== undefined,
          "Add content",
        ),
    })
    .strict(),
  z
    .object({
      type: z.literal("CTA"),
      data: z.object({ title, body: text, label: title, href }).strict(),
    })
    .strict(),
  z
    .object({
      type: z.literal("FEATURES"),
      data: z
        .object({
          items: z.array(z.object({ title, body: text }).strict()).max(8),
        })
        .strict(),
    })
    .strict(),
  ...(
    [
      "COURSES_GRID",
      "TEACHERS",
      "PRICING_TEASER",
      "TESTIMONIALS",
      "FAQ",
    ] as const
  ).map((type) =>
    z
      .object({ type: z.literal(type), data: z.object({ title }).strict() })
      .strict(),
  ),
]);
export const sectionsSchema = z
  .object({
    version: z.number().int().positive(),
    sections: z
      .array(z.object({ section: sectionDataSchema, isVisible: z.boolean() }))
      .max(30),
  })
  .strict();
export const settingSchemas = {
  "site.benefits": z
    .object({
      ownerApproved: z.literal(true),
      items: z
        .array(
          z
            .object({
              title: z.string().trim().min(2).max(160),
              body: z.string().trim().min(2).max(1000),
            })
            .strict(),
        )
        .max(8),
    })
    .strict(),
  "social.links": z
    .array(
      z
        .object({
          label: z.string().trim().min(2).max(40),
          url: z
            .url()
            .max(2048)
            .refine((value) => {
              try {
                const url = new URL(value);
                return (
                  url.protocol === "https:" && !url.username && !url.password
                );
              } catch {
                return false;
              }
            }, "Use an HTTPS URL without embedded credentials"),
        })
        .strict(),
    )
    .max(8),
  "site.name": z.string().trim().min(2).max(100),
  "contact.email": z.email(),
  "contact.address": z.string().trim().max(500),
  "contact.whatsapp": z.string().regex(/^\+[1-9]\d{7,14}$/),
  "contact.phones": z
    .array(
      z
        .object({
          label: z.string().max(40),
          number: z.string().regex(/^\+[1-9]\d{7,14}$/),
          region: z.string().length(2),
        })
        .strict(),
    )
    .max(5),
  "legal.entity": z.string().trim().min(2).max(200),
  "legal.registration": z.string().trim().max(100),
  "retention.contactDays": z.number().int().min(1).max(3650),
  "readiness.brandApproved": z.boolean(),
  "readiness.ownerSignoff": z.boolean(),
  "readiness.contactForFeesAccepted": z.boolean(),
  "readiness.botProtectionDisabledAccepted": z.boolean(),
  "readiness.mailerDisabledAccepted": z.boolean(),
  "scheduling.meetingDomains": z
    .array(z.string().regex(/^[a-z0-9.-]+\.[a-z]{2,}$/))
    .max(20),
};
export type SettingKey = keyof typeof settingSchemas;
export function settingKey(value: string): value is SettingKey {
  return Object.hasOwn(settingSchemas, value);
}
