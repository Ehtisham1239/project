import { z } from "zod";
import { parsePhoneNumberFromString } from "libphonenumber-js/max";
export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).max(100000).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  q: z.string().trim().max(100).default(""),
  sort: z.enum(["createdAt", "title", "name"]).default("createdAt"),
});
export const timezone = z.string().refine((value) => {
  try {
    new Intl.DateTimeFormat("en", { timeZone: value });
    return true;
  } catch {
    return false;
  }
}, "Select a valid time zone");
export const password = z
  .string()
  .min(12, "Use a passphrase of at least 12 characters")
  .max(128);
export const email = z.email().trim().toLowerCase().max(254);
export const slug = z
  .string()
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
  .max(120);

export const internationalPhone = z
  .string()
  .regex(
    /^\+[1-9]\d{7,14}$/,
    "Use international format, including the country calling code",
  )
  .refine(
    (value) => parsePhoneNumberFromString(value)?.isValid() === true,
    "Enter a valid international phone number",
  );

export const currencySchema = z
  .string()
  .refine(
    (value) => Intl.supportedValuesOf("currency").includes(value),
    "Choose a supported currency",
  );
