import { z } from "zod";
import { email, timezone, internationalPhone } from "./common";
const name = z.string().trim().min(2).max(120);
const spam = {
  website: z.string().max(200),
  startedAt: z.number().int().positive(),
  botToken: z.string().max(2048),
};
export const trialSchema = z
  .object({
    learnerName: name,
    guardianName: name.optional(),
    email,
    phoneE164: internationalPhone,
    country: z.string().regex(/^[A-Z]{2}$/),
    timezone,
    ageBand: z.enum(["UNDER_6", "6_8", "9_12", "13_17", "18_PLUS"]),
    courseId: z.uuid(),
    level: z.enum(["BEGINNER", "SLOW_READER", "FLUENT", "NOT_SURE"]),
    teacherGenderPref: z.enum(["ANY", "MALE", "FEMALE"]),
    teachingLanguage: z.enum(["ENGLISH", "URDU", "ARABIC", "OTHER"]),
    availableSlots: z
      .array(
        z
          .object({
            weekday: z.number().int().min(1).max(7),
            startMinute: z.number().int().min(0).max(1439),
            endMinute: z.number().int().min(1).max(1440),
          })
          .strict()
          .refine((x) => x.endMinute > x.startMinute, {
            message: "End time must be later than start time",
          }),
      )
      .min(1)
      .max(3),
    notes: z.string().trim().max(500).optional(),
    consentGiven: z.literal(true, { error: "Consent is required" }),
    consentTextVersion: z.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/),
    ...spam,
  })
  .strict()
  .superRefine((data, ctx) => {
    if (data.ageBand !== "18_PLUS" && !data.guardianName)
      ctx.addIssue({
        code: "custom",
        path: ["guardianName"],
        message: "A guardian name is required for learners under 18",
      });
  });
export const contactSchema = z
  .object({
    name,
    email,
    phone: internationalPhone.optional(),
    subject: z.string().trim().min(2).max(150),
    message: z.string().trim().min(10).max(2000),
    country: z
      .string()
      .regex(/^[A-Z]{2}$/)
      .optional(),
    city: z.string().trim().max(120).optional(),
    consentGiven: z.literal(true, { error: "Consent is required" }),
    consentTextVersion: z.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/),
    ...spam,
  })
  .strict();
export type TrialInput = z.infer<typeof trialSchema>;
export type ContactInput = z.infer<typeof contactSchema>;
