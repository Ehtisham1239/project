import { z } from "zod";
export const restoreRevisionSchema = z
  .object({
    revisionId: z.uuid(),
    version: z.number().int().positive(),
    confirmed: z.literal(true),
  })
  .strict();
