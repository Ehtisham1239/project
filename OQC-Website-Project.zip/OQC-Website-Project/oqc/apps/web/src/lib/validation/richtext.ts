import { z } from "zod";
export type RichNode = {
  type:
    | "doc"
    | "paragraph"
    | "heading"
    | "text"
    | "bulletList"
    | "orderedList"
    | "listItem"
    | "blockquote"
    | "hardBreak"
    | "codeBlock"
    | "horizontalRule";
  content?: RichNode[];
  text?: string;
  attrs?: {
    level?: number;
    start?: number;
    language?: string | null;
    type?: string | null;
  };
  marks?: { type: "bold" | "italic" | "strike" | "code" }[];
};
export const richNodeSchema: z.ZodType<RichNode> = z.lazy(() =>
  z
    .object({
      type: z.enum([
        "doc",
        "paragraph",
        "heading",
        "text",
        "bulletList",
        "orderedList",
        "listItem",
        "blockquote",
        "hardBreak",
        "codeBlock",
        "horizontalRule",
      ]),
      content: z.array(richNodeSchema).max(200).optional(),
      text: z.string().max(10000).optional(),
      attrs: z
        .object({
          level: z.number().int().min(2).max(3).optional(),
          start: z.number().int().min(1).optional(),
          language: z.string().max(32).nullable().optional(),
          type: z.enum(["1", "a", "A", "i", "I"]).nullable().optional(),
        })
        .strict()
        .optional(),
      marks: z
        .array(
          z
            .object({ type: z.enum(["bold", "italic", "strike", "code"]) })
            .strict(),
        )
        .max(4)
        .optional(),
    })
    .strict(),
);
function withinLimits(value: unknown) {
  const work: { value: unknown; depth: number }[] = [{ value, depth: 0 }];
  let count = 0;
  while (work.length) {
    const item = work.pop()!;
    if (item.depth > 32 || ++count > 4000) return false;
    if (item.value && typeof item.value === "object")
      for (const child of Object.values(item.value))
        work.push({ value: child, depth: item.depth + 1 });
  }
  return true;
}
export const richDocumentSchema = z.preprocess(
  (value, ctx) => {
    if (!withinLimits(value)) {
      ctx.addIssue({
        code: "custom",
        message: "Editor document exceeds nesting or size limits",
      });
      return z.NEVER;
    }
    return value;
  },
  richNodeSchema.refine(
    (node) => node.type === "doc",
    "Expected an editor document",
  ),
);
export function parseRichDocument(value: unknown) {
  return richDocumentSchema.parse(value);
}
const escape = (value: string) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
export function renderRichHtml(value: unknown) {
  const root = parseRichDocument(value);
  function render(node: RichNode): string {
    if (node.type === "text") {
      let result = escape(node.text ?? "");
      for (const mark of node.marks ?? []) {
        const tag = { bold: "strong", italic: "em", strike: "s", code: "code" }[
          mark.type
        ];
        result = `<${tag}>${result}</${tag}>`;
      }
      return result;
    }
    if (node.type === "hardBreak") return "<br>";
    if (node.type === "horizontalRule") return "<hr>";
    const content = (node.content ?? []).map(render).join("");
    if (node.type === "doc") return content;
    const tag = {
      paragraph: "p",
      heading: node.attrs?.level === 3 ? "h3" : "h2",
      bulletList: "ul",
      orderedList: "ol",
      listItem: "li",
      blockquote: "blockquote",
      codeBlock: "pre",
    }[node.type];
    return `<${tag}>${content}</${tag}>`;
  }
  return render(root);
}
