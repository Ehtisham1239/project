import { z } from "zod";
import { currencySchema } from "@/lib/validation/common";
export const publicCatalogQuery = z
  .object({
    page: z.coerce.number().int().min(1).max(100000).default(1),
    pageSize: z.coerce.number().int().min(1).max(100).default(20),
    q: z.string().trim().max(100).default(""),
    ageGroup: z.string().trim().max(80).optional(),
    level: z.string().trim().max(80).optional(),
    gender: z.string().trim().max(40).optional(),
    language: z.string().trim().max(80).optional(),
    courseId: z.uuid().optional(),
    category: z.string().trim().max(80).optional(),
    tag: z.string().trim().max(80).optional(),
    currency: currencySchema.optional(),
  })
  .strict();
