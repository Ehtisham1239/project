import { z } from "zod";
export const enrollmentSchema = z
  .object({
    studentId: z.uuid(),
    courseId: z.uuid(),
    teacherId: z.uuid(),
    planId: z.uuid().optional(),
    startDate: z.iso.date(),
    endDate: z.iso.date().optional(),
  })
  .strict()
  .refine((value) => !value.endDate || value.endDate >= value.startDate, {
    message: "The end date must be on or after the start date",
    path: ["endDate"],
  });
