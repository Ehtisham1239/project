import { z } from "zod";
import { richDocumentSchema } from "./richtext";
import { slug, timezone, email } from "./common";
const title = z.string().trim().min(2).max(160),
  text = z.string().trim().max(10000),
  uuid = z.uuid(),
  date = z.iso.datetime().transform((x) => new Date(x));
export const adminSchemas = {
  blog: z
    .object({
      slug,
      title,
      excerpt: z.string().trim().min(2).max(1000),
      body: richDocumentSchema,
      tags: z.array(z.string().max(40)).max(10).optional(),
      seoTitle: z.string().max(60).optional(),
      seoDescription: z.string().max(155).optional(),
    })
    .strict(),
  courses: z
    .object({
      slug,
      title,
      summary: z.string().trim().min(2).max(1000),
      description: richDocumentSchema.optional(),
      ageGroup: title,
      level: title,
      durationText: text.optional(),
      category: z.enum(["REGULAR", "COMPLEMENTARY"]).optional(),
      seoTitle: z.string().max(60).optional(),
      seoDescription: z.string().max(155).optional(),
      sortOrder: z.number().int().min(0).optional(),
    })
    .strict(),
  teachers: z
    .object({
      slug,
      displayName: title,
      gender: z.enum(["MALE", "FEMALE"]),
      bio: text.min(10),
      qualificationsText: text.optional(),
      languages: z.array(z.string().max(60)).min(1),
      isActive: z.boolean().optional(),
      isPublic: z.boolean().optional(),
      verificationNote: text.optional(),
    })
    .strict(),
  faqs: z
    .object({
      question: title,
      answer: text.min(2),
      category: title,
      locale: z.literal("en").optional(),
      sortOrder: z.number().int().min(0).optional(),
    })
    .strict(),
  testimonials: z
    .object({
      name: title,
      role: title,
      country: z.string().length(2),
      quote: text.min(10),
      consentRecordedAt: date.optional(),
    })
    .strict(),
  pages: z
    .object({
      slug,
      title,
      locale: z.literal("en").optional(),
      template: z
        .enum([
          "STANDARD",
          "COURSE_LISTING",
          "LOCATION_LANDING",
          "AUDIENCE_LANDING",
          "POLICY",
        ])
        .optional(),
      seoTitle: z.string().max(60).optional(),
      seoDescription: z.string().max(155).optional(),
    })
    .strict(),
  "pricing-plans": z
    .object({
      courseId: uuid.optional(),
      name: title,
      billingPeriod: z.enum(["MONTHLY", "WEEKLY", "ONE_TIME"]),
      classesPerWeek: z.number().int().min(1).max(7),
      durationMin: z.number().int().min(1).max(240),
      isPublic: z.boolean().optional(),
    })
    .strict(),
  students: z
    .object({
      fullName: title,
      ageBand: z.enum(["UNDER_6", "6_8", "9_12", "13_17", "18_PLUS"]),
      country: z.string().length(2),
      timezone,
      notes: text.optional(),
      guardianId: uuid.optional(),
    })
    .strict(),
  guardians: z
    .object({
      fullName: title,
      email,
      phone: z.string().regex(/^\+[1-9]\d{7,14}$/),
      relationship: title,
      country: z.string().length(2),
    })
    .strict(),
  menus: z
    .object({
      menu: z.enum(["HEADER", "FOOTER"]),
      label: title,
      href: z.string().regex(/^\/(?!\/)[a-zA-Z0-9/_-]*$/),
      sortOrder: z.number().int().min(0),
      parentId: uuid.optional(),
    })
    .strict(),
};
export type EditableResource = keyof typeof adminSchemas;
export function isEditableResource(
  resource: string,
): resource is EditableResource {
  return Object.hasOwn(adminSchemas, resource);
}
export const statusSchema = z
  .object({
    status: z.enum(["DRAFT", "SUBMITTED", "APPROVED", "PUBLISHED", "ARCHIVED"]),
    version: z.number().int().positive(),
  })
  .strict();
