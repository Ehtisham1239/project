import { z } from "zod";
export const consentSchema = z
  .object({
    version: z
      .string()
      .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/)
      .refine(
        (value) => value !== "v1-draft",
        "Use a new approved version identifier",
      ),
    trialText: z.string().trim().min(20).max(2000),
    contactText: z.string().trim().min(20).max(2000),
    ownerApproved: z.literal(true),
  })
  .strict();
export const storedConsentSchema = consentSchema.omit({ ownerApproved: true });
