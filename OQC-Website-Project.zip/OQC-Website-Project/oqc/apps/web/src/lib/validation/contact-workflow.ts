import { z } from "zod";
export const contactWorkflowSchema = z
  .object({
    updatedAt: z.iso.datetime(),
    status: z.enum(["NEW", "READ", "REPLIED", "SPAM", "ARCHIVED"]),
    assignedToUserId: z.uuid().nullable(),
    replyConfirmed: z.boolean().default(false),
  })
  .strict()
  .refine((value) => value.status !== "REPLIED" || value.replyConfirmed, {
    message: "Confirm that a reply has already been sent",
    path: ["replyConfirmed"],
  });

export const contactTransitions: Record<string, string[]> = {
  NEW: ["READ", "SPAM", "ARCHIVED"],
  READ: ["REPLIED", "SPAM", "ARCHIVED"],
  REPLIED: ["ARCHIVED"],
  SPAM: ["READ", "ARCHIVED"],
  ARCHIVED: ["READ"],
};
