import { z } from "zod";
export const courseModulesSchema = z
  .object({
    version: z.number().int().positive(),
    modules: z
      .array(
        z
          .object({
            title: z.string().trim().min(2).max(160),
            objectives: z.string().trim().min(2).max(3000),
          })
          .strict(),
      )
      .max(30),
  })
  .strict();
