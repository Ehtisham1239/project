import { z } from "zod";
import { timezone } from "@/lib/validation/common";
export const calendarSchema = z
  .object({
    from: z.iso.date().optional(),
    timezone: timezone.default("UTC"),
    days: z.enum(["1", "7"]).default("7"),
    teacherId: z.uuid().optional(),
  })
  .strict();
