import { z } from "zod";
import { email, password } from "./common";
export const loginSchema = z
  .object({
    email,
    password: z.string().min(1).max(128),
    code: z.string().max(64).optional(),
  })
  .strict();
export const bootstrapSchema = z
  .object({ email, password, name: z.string().trim().min(1).max(100) })
  .strict();
