import { z } from "zod";
export const invoiceVoidSchema = z
  .object({
    version: z.number().int().positive(),
    reason: z.enum([
      "DUPLICATE",
      "INCORRECT_DETAILS",
      "CANCELLED_ENROLLMENT",
      "OTHER",
    ]),
    confirmed: z.literal(true),
  })
  .strict();
