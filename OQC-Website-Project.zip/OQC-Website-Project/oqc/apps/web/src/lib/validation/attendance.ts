import { z } from "zod";
export const attendanceSchema = z
  .object({
    sessionId: z.uuid(),
    enrollmentId: z.uuid(),
    sessionVersion: z.number().int().positive(),
    expectedUpdatedAt: z.iso.datetime().nullable(),
    status: z.enum(["PRESENT", "ABSENT", "LATE", "EXCUSED"]),
    note: z.string().trim().max(1000).optional(),
  })
  .strict();
