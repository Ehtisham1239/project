import { currencySchema } from "./common";
import { z } from "zod";
export const pricesSchema = z
  .object({
    version: z.number().int().positive(),
    prices: z
      .array(
        z
          .object({
            currency: currencySchema,
            amountMinor: z.number().int().min(0).max(2147483647),
            isPublic: z.boolean(),
          })
          .strict(),
      )
      .max(20)
      .refine(
        (rows) => new Set(rows.map((row) => row.currency)).size === rows.length,
        "Add each currency only once",
      ),
  })
  .strict();
