export function csvCell(value: unknown) {
  let text = value instanceof Date ? value.toISOString() : String(value ?? "");
  text = text.replaceAll("\0", "");
  if (/^[=+\-@\t\r\n]/.test(text) || /^\s+[=+\-@]/.test(text))
    text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}
export function encodeCsv(columns: string[], rows: Record<string, unknown>[]) {
  return (
    "\ufeff" +
    [
      columns.map(csvCell).join(","),
      ...rows.map((row) => columns.map((key) => csvCell(row[key])).join(",")),
    ].join("\r\n") +
    "\r\n"
  );
}
