export type CountByStatus = { status: string; count: number };
export type Reports = {
  admissions?: { states: CountByStatus[]; duplicateCount: number };
  academic?: {
    activeEnrollments: number;
    upcomingClasses: number;
    attendance: CountByStatus[];
  };
  content?: { courses: CountByStatus[]; pages: CountByStatus[] };
  finance?: {
    invoices: {
      currency: string;
      status: string;
      amountMinor: number;
      count: number;
    }[];
  };
};
