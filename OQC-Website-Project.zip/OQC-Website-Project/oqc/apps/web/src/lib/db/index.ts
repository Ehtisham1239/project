import { runtimeEnv } from "@/lib/platform/env";
import { PrismaClient } from "@/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
const globalDb = globalThis as unknown as { oqcDb?: PrismaClient };
export function database() {
  if (!globalDb.oqcDb) {
    const url = runtimeEnv().DATABASE_URL;
    if (!url) throw new Error("DATABASE_URL required");
    globalDb.oqcDb = new PrismaClient({
      adapter: new PrismaPg({ connectionString: url }),
    });
  }
  return globalDb.oqcDb;
}
