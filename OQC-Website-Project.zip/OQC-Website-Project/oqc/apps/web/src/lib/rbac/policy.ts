export const roles = [
  "SUPER_ADMIN",
  "ADMIN",
  "CONTENT_EDITOR",
  "ADMISSIONS",
  "ACADEMIC_COORDINATOR",
] as const;
export type RoleKey = (typeof roles)[number];
const crud = ["read", "create", "update", "delete"] as const;
const expand = (modules: string[], actions: readonly string[] = crud) =>
  modules.flatMap((module) => actions.map((action) => `${module}:${action}`));
const content = ["pages", "blog", "faqs", "testimonials", "media", "menus"],
  catalog = ["courses", "teachers"],
  admissions = ["trials", "contact-messages"],
  academics = [
    "students",
    "guardians",
    "enrollments",
    "schedules",
    "sessions",
    "attendance",
    "progress",
  ],
  finance = ["pricing-plans", "invoices", "payments"];
const all = [
  ...expand([
    "users",
    ...content,
    ...catalog,
    ...admissions,
    ...academics,
    ...finance,
    "settings",
    "privacy-requests",
  ]),
  ...expand(
    ["roles", "audit-logs", "notifications", "reports", "backups"],
    ["read"],
  ),
  ...expand(content, ["submit", "publish"]),
  "courses:submit",
  "courses:publish",
  "pricing-plans:submit",
  "pricing-plans:publish",
  "trials:assign",
  "trials:convert",
  "trials:status",
  "trials:notes",
  "teachers:availability",
  "exports:all",
  "exports:admissions",
  "exports:academic",
  "exports:content",
  "ai:read",
  "ai:draft",
  "ai:toggle",
  "ai:evaluate",
  "ai:insights",
  "users:security",
  "settings:security",
  "retention:execute",
];
export const permissionMatrix: Record<RoleKey, readonly string[]> = {
  SUPER_ADMIN: all,
  ADMIN: all.filter(
    (x) =>
      ![
        "users:security",
        "settings:security",
        "retention:execute",
        "ai:evaluate",
      ].includes(x),
  ),
  CONTENT_EDITOR: [
    "notifications:read",
    ...expand(content),
    ...expand(content, ["submit"]),
    ...expand(catalog, ["read", "update-content"]),
    "courses:submit",
    "pricing-plans:read",
    "exports:content",
    "reports:content",
    "ai:draft",
  ],
  ADMISSIONS: [
    "notifications:read",
    ...expand(admissions),
    ...expand(catalog, ["read"]),
    ...expand(["students", "guardians", "enrollments"], ["create", "read"]),
    ...expand(
      ["schedules", "sessions", "attendance", "progress", ...finance],
      ["read"],
    ),
    "trials:assign",
    "trials:convert",
    "trials:status",
    "trials:notes",
    "exports:admissions",
    "reports:admissions",
  ],
  ACADEMIC_COORDINATOR: [
    "notifications:read",
    ...expand(catalog),
    ...expand(academics),
    ...expand([...content, ...finance], ["read"]),
    "courses:submit",
    "trials:read",
    "trials:assign",
    "exports:academic",
    "reports:academic",
    "ai:insights",
    "ai:read",
    "teachers:availability",
  ],
};
export const permissionKeys = [
  ...new Set(Object.values(permissionMatrix).flat()),
].sort();
export function can(role: string, permission: string) {
  return (
    roles.includes(role as RoleKey) &&
    permissionMatrix[role as RoleKey].includes(permission)
  );
}
export function canAssignRole(actorRole: string, targetRole: string) {
  return (
    actorRole === "SUPER_ADMIN" ||
    (actorRole === "ADMIN" &&
      targetRole !== "SUPER_ADMIN" &&
      roles.includes(targetRole as RoleKey))
  );
}
