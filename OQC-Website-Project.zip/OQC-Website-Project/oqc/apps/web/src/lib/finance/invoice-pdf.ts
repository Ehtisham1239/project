import PDFDocument from "pdfkit";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { formatMinor } from "@/lib/platform/money";
export type InvoiceDocument = {
  number: string;
  currency: string;
  totalMinor: number;
  paidMinor: number;
  status: string;
  issuedAt: Date | null;
  dueAt: Date | null;
  learnerName: string;
  courseTitle: string;
  companyName?: string;
  address?: string;
  email?: string;
  payments: { amountMinor: number; method: string; receivedAt: Date }[];
  paymentCount: number;
  generatedAt: Date;
};
export async function renderInvoicePdf(invoice: InvoiceDocument) {
  const regular = resolve(process.cwd(), "assets/pdf/DejaVuSans.ttf");
  const [logo, regularBytes, boldBytes] = await Promise.all([
    readFile(resolve(process.cwd(), "public/brand/logo.jpg")),
    readFile(resolve(process.cwd(), "assets/pdf/DejaVuSans.ttf")),
    readFile(resolve(process.cwd(), "assets/pdf/DejaVuSans-Bold.ttf")),
  ]);
  const document = new PDFDocument({
    size: "A4",
    margin: 48,
    tagged: true,
    lang: "en-GB",
    displayTitle: true,
    pdfVersion: "1.7",
    font: regular,
    info: {
      Title: "Invoice " + invoice.number,
      Author: invoice.companyName ?? "Online Quran College LTD",
      Subject: "Staff-issued invoice",
      CreationDate: invoice.generatedAt,
    },
  });
  document.registerFont("Regular", regularBytes);
  document.registerFont("Bold", boldBytes);
  const chunks: Buffer[] = [];
  const finished = new Promise<Buffer>((resolve, reject) => {
    document.on("data", (chunk: Buffer) => chunks.push(chunk));
    document.on("end", () => resolve(Buffer.concat(chunks)));
    document.on("error", reject);
  });
  const structure = document.struct("Document");
  document.addStructure(structure);
  function line(text: string, tag = "P", large = false) {
    structure.add(
      document.struct(tag, {}, () => {
        document
          .font(large ? "Bold" : "Regular")
          .fontSize(large ? 17 : 10)
          .fillColor(large ? "#085F0E" : "#193221")
          .text(text, { lineGap: 4 });
        document.moveDown(large ? 0.6 : 0.3);
      }),
    );
  }
  structure.add(
    document.struct("Figure", { alt: "Online Quran College logo" }, () => {
      document.image(logo, 48, 48, { fit: [72, 72] });
    }),
  );
  document.y = 132;
  line("Invoice " + invoice.number, "H1", true);
  line(invoice.companyName ?? "Online Quran College LTD");
  if (invoice.address) line(invoice.address);
  if (invoice.email) line(invoice.email);
  line("Status: " + invoice.status);
  line("Invoice details", "H2", true);
  line("Learner: " + invoice.learnerName);
  line("Course: " + invoice.courseTitle);
  if (invoice.issuedAt)
    line("Issued: " + invoice.issuedAt.toISOString().slice(0, 10));
  if (invoice.dueAt) line("Due: " + invoice.dueAt.toISOString().slice(0, 10));
  line("Amounts (" + invoice.currency + ")", "H2", true);
  line("Invoice total: " + formatMinor(invoice.totalMinor, invoice.currency));
  line(
    "Payments recorded: " + formatMinor(invoice.paidMinor, invoice.currency),
  );
  line(
    "Amount due: " +
      formatMinor(
        invoice.status === "VOID" ? 0 : invoice.totalMinor - invoice.paidMinor,
        invoice.currency,
      ),
  );
  if (invoice.paymentCount) {
    line("Recorded payments", "H2", true);
    for (const payment of invoice.payments)
      line(
        payment.receivedAt.toISOString().slice(0, 10) +
          " · " +
          payment.method.replaceAll("_", " ") +
          " · " +
          formatMinor(payment.amountMinor, invoice.currency),
      );
    if (invoice.paymentCount > invoice.payments.length)
      line(
        "Showing the first " +
          invoice.payments.length +
          " of " +
          invoice.paymentCount +
          " records. The payment total includes all records.",
      );
  }
  line("Generated: " + invoice.generatedAt.toISOString());
  structure.end();
  document.end();
  return finished;
}
