export function sumByCurrency(
  items: { currency: string; amountMinor: number }[],
) {
  const result: Record<string, number> = {};
  for (const item of items) {
    if (
      !/^[A-Z]{3}$/.test(item.currency) ||
      !Number.isSafeInteger(item.amountMinor) ||
      item.amountMinor < 0
    )
      throw new Error("Invalid monetary amount");
    const total = (result[item.currency] ?? 0) + item.amountMinor;
    if (!Number.isSafeInteger(total))
      throw new Error("Monetary amount exceeds supported range");
    result[item.currency] = total;
  }
  return result;
}

export function formatMinor(amount: number, currency: string, locale = "en") {
  const formatter = new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
  });
  const digits = formatter.resolvedOptions().maximumFractionDigits ?? 2;
  return formatter.format(amount / 10 ** digits);
}
export function majorToMinor(
  value: string,
  currency: string,
  allowZero = false,
) {
  if (!Intl.supportedValuesOf("currency").includes(currency))
    throw new Error("Choose a supported currency.");
  const digits =
    new Intl.NumberFormat("en", {
      style: "currency",
      currency,
    }).resolvedOptions().maximumFractionDigits ?? 2;
  const parts = value.trim().match(/^(\d+)(?:\.(\d+))?$/);
  if (!parts || (parts[2]?.length ?? 0) > digits)
    throw new Error("Use the currency’s supported decimal precision.");
  const amount =
    Number(parts[1]) * 10 ** digits +
    Number((parts[2] ?? "").padEnd(digits, "0"));
  if (
    !Number.isSafeInteger(amount) ||
    amount < (allowZero ? 0 : 1) ||
    amount > 2147483647
  )
    throw new Error("Enter a supported positive amount.");
  return amount;
}
