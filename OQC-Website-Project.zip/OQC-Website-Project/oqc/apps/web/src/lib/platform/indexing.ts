import { launchReadiness } from "@/server/services/content";

export async function publicIndexingAllowed() {
  return (
    process.env.INDEXING_ENABLED === "true" &&
    process.env.DEPLOYMENT_ENVIRONMENT === "production" &&
    (await launchReadiness()).every((item) => item.passed)
  );
}
