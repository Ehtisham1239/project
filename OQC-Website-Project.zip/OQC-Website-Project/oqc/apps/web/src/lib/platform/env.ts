import { z } from "zod";
const schema = z.object({
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
  APP_URL: z.url().default("http://localhost:3000"),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1).default("redis://localhost:6379"),
  AUTH_SECRET: z.string().min(32),
  AI_ENABLED: z.enum(["true", "false"]).default("false"),
  MAILER_DRIVER: z.enum(["console", "smtp", "resend"]).default("console"),
});
export function validateDatabaseUrl(
  value: string,
  requireTls = process.env.NODE_ENV === "production",
) {
  const url = new URL(value);
  if (!["postgres:", "postgresql:"].includes(url.protocol))
    throw new Error("A PostgreSQL connection is required");
  if (requireTls && url.searchParams.get("sslmode") !== "verify-full")
    throw new Error(
      "Production PostgreSQL requires verified TLS (sslmode=verify-full)",
    );
  return value;
}
export function validateEnv(input: NodeJS.ProcessEnv) {
  const parsed = schema.parse(input);
  validateDatabaseUrl(parsed.DATABASE_URL, parsed.NODE_ENV === "production");
  if (/change-me|default|example/i.test(parsed.AUTH_SECRET))
    throw new Error("AUTH_SECRET must be randomly generated");
  if (
    parsed.NODE_ENV === "production" &&
    new URL(parsed.APP_URL).protocol !== "https:"
  )
    throw new Error("Production requires HTTPS");
  return parsed;
}
export function runtimeEnv() {
  return validateEnv(process.env);
}
export function authCookiePolicy(input: NodeJS.ProcessEnv) {
  const config = validateEnv(input);
  const secure =
    config.NODE_ENV === "production" ||
    new URL(config.APP_URL).protocol === "https:";
  return { name: secure ? "__Host-oqc-session" : "oqc-session", secure };
}
