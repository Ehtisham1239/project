import { DateTime } from "luxon";
export function expandWeekly({
  weekday,
  startMinute,
  durationMin,
  timezone,
  from,
  to,
}: {
  weekday: number;
  startMinute: number;
  durationMin: number;
  timezone: string;
  from: string;
  to: string;
}) {
  if (
    weekday < 1 ||
    weekday > 7 ||
    !Number.isInteger(startMinute) ||
    startMinute < 0 ||
    startMinute > 1439 ||
    durationMin < 1 ||
    durationMin > 240
  )
    throw new Error("Invalid schedule");
  let date = DateTime.fromISO(from, { zone: timezone }).startOf("day");
  const end = DateTime.fromISO(to, { zone: timezone }).startOf("day");
  if (
    !date.isValid ||
    !end.isValid ||
    end < date ||
    end.diff(date, "days").days > 366
  )
    throw new Error("Invalid date range");
  const result: { startsAtUtc: Date; endsAtUtc: Date }[] = [];
  while (date <= end) {
    if (date.weekday === weekday) {
      const hour = Math.floor(startMinute / 60),
        minute = startMinute % 60;
      const local = date.set({ hour, minute });
      if (local.hour !== hour || local.minute !== minute)
        throw new Error("Schedule falls in a daylight-saving gap");
      if (local.getPossibleOffsets().length > 1)
        throw new Error("Schedule falls in an ambiguous daylight-saving hour");
      result.push({
        startsAtUtc: local.toUTC().toJSDate(),
        endsAtUtc: local.plus({ minutes: durationMin }).toUTC().toJSDate(),
      });
    }
    date = date.plus({ days: 1 });
  }
  return result;
}
export function overlaps(
  a: { start: Date; end: Date },
  b: { start: Date; end: Date },
) {
  return a.start < b.end && b.start < a.end;
}
export function withinAvailability(
  startsAt: Date,
  endsAt: Date,
  slots: {
    weekday: number;
    startMinute: number;
    endMinute: number;
    timezone: string;
  }[],
) {
  if (!slots.length || endsAt <= startsAt) return false;
  const covered = (timestamp: number) =>
    slots.some((slot) => {
      const local = DateTime.fromMillis(timestamp, { zone: slot.timezone });
      const minute =
        local.hour * 60 +
        local.minute +
        local.second / 60 +
        local.millisecond / 60000;
      return (
        local.isValid &&
        local.weekday === slot.weekday &&
        minute >= slot.startMinute &&
        minute < slot.endMinute
      );
    });
  for (
    let instant = startsAt.getTime();
    instant < endsAt.getTime();
    instant += 60000
  )
    if (!covered(instant)) return false;
  return covered(endsAt.getTime() - 1);
}
