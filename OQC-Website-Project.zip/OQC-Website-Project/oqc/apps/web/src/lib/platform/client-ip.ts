import { isIP } from "node:net";
export function clientAddress(request: Request) {
  const header =
    process.env.VERCEL === "1"
      ? "x-forwarded-for"
      : process.env.TRUSTED_PROXY_HEADER === "x-real-ip"
        ? "x-real-ip"
        : null;
  if (!header) return "unknown";
  const value = request.headers.get(header)?.split(",")[0]?.trim();
  return value && isIP(value) ? value : "unknown";
}
