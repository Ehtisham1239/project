import type { Metadata } from "next";
import messages from "@/messages/en.json";
export function siteUrl(path: string) {
  return new URL(path, process.env.APP_URL ?? "http://localhost:3000").href;
}
export function pageMetadata(
  title: string,
  description: string,
  path: string,
  article = false,
): Metadata {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      title,
      description,
      url: siteUrl(path),
      siteName: messages.brand,
      type: article ? "article" : "website",
      images: [{ url: siteUrl("/brand/logo.jpg"), alt: messages.brand }],
    },
    twitter: {
      card: "summary",
      title,
      description,
      images: [siteUrl("/brand/logo.jpg")],
    },
  };
}
export function jsonLd(value: unknown) {
  return JSON.stringify(value)
    .replace(/</g, "\\u003c")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}
export function breadcrumbData(items: { label: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.label,
      item: siteUrl(item.path),
    })),
  };
}
