import { logger } from "./log";
import { z } from "zod";
import { AppError, errorResponse } from "./errors";
import { randomUUID } from "node:crypto";
export async function parseBody<T>(
  request: Request,
  schema: z.ZodType<T>,
  max = 20480,
): Promise<T> {
  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > max)
    throw new AppError("PAYLOAD_TOO_LARGE", 413, "This request is too large.");
  if (!request.headers.get("content-type")?.startsWith("application/json"))
    throw new AppError("VALIDATION_ERROR", 400, "Send JSON content.");
  const reader = request.body?.getReader();
  if (!reader)
    throw new AppError("VALIDATION_ERROR", 400, "Request body is required.");
  let size = 0;
  const chunks: Uint8Array[] = [];
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.byteLength;
    if (size > max) {
      await reader.cancel();
      throw new AppError(
        "PAYLOAD_TOO_LARGE",
        413,
        "This request is too large.",
      );
    }
    chunks.push(part.value);
  }
  let input: unknown;
  try {
    input = JSON.parse(Buffer.concat(chunks).toString());
  } catch {
    throw new AppError("VALIDATION_ERROR", 400, "Invalid JSON.");
  }
  const result = schema.safeParse(input);
  if (!result.success)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Check the highlighted fields.",
      result.error.issues.map((issue) => ({
        path: issue.path.join("."),
        message: issue.message,
      })),
    );
  return result.data;
}
export async function api(run: (requestId: string) => Promise<Response>) {
  const requestId = randomUUID();
  try {
    const response = await run(requestId);
    response.headers.set("X-Request-Id", requestId);
    response.headers.set("X-Content-Type-Options", "nosniff");
    response.headers.set("Cache-Control", "no-store");
    return response;
  } catch (error) {
    logger.warn(
      {
        requestId,
        errorCode: error instanceof AppError ? error.code : "INTERNAL",
      },
      "API request failed",
    );
    const response = errorResponse(error, requestId);
    if (error instanceof AppError && error.status === 429)
      response.headers.set(
        "Retry-After",
        String((error.details as { retryAfter?: number })?.retryAfter ?? 60),
      );
    return response;
  }
}
