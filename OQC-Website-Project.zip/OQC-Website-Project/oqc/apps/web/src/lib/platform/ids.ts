import { v7 } from "uuid";
export const newId = () => v7();
