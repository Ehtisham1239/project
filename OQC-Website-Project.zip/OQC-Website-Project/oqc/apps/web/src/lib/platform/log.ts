import pino from "pino";
export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: {
    paths: [
      "password",
      "token",
      "email",
      "phone",
      "name",
      "notes",
      "prompt",
      "req.headers.cookie",
      "req.headers.authorization",
    ],
    remove: true,
  },
});
