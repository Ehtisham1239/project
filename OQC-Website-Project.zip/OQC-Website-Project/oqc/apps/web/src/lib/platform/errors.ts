import { ZodError } from "zod";
export class AppError extends Error {
  constructor(
    public code: string,
    public status: number,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}
export function errorResponse(error: unknown, requestId: string) {
  if (error instanceof Error && "code" in error) {
    const code = error.code;
    const mapped: Record<string, [string, number, string]> = {
      P2002: ["CONFLICT", 409, "A record with this identifier already exists."],
      P2003: ["CONFLICT", 409, "This record is still used by another record."],
      P2025: ["NOT_FOUND", 404, "Record not found."],
      P2034: [
        "CONFLICT",
        409,
        "Another change was made at the same time. Try again.",
      ],
    };
    if (typeof code === "string" && mapped[code]) {
      const [name, status, message] = mapped[code];
      error = new AppError(name, status, message);
    }
  }
  if (error instanceof ZodError)
    error = new AppError(
      "VALIDATION_ERROR",
      400,
      "Check the request fields.",
      error.issues.map((issue) => ({
        path: issue.path.join("."),
        message: issue.message,
      })),
    );
  if (error instanceof AppError)
    return Response.json(
      {
        error: {
          code: error.code,
          message: error.message,
          details: error.details,
          requestId,
        },
      },
      { status: error.status, headers: { "X-Request-Id": requestId } },
    );
  return Response.json(
    {
      error: {
        code: "INTERNAL",
        message: "Unable to complete this request. Please try again.",
        requestId,
      },
    },
    { status: 500, headers: { "X-Request-Id": requestId } },
  );
}
