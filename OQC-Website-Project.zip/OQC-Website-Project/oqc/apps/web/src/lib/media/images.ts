import { fileTypeFromBuffer } from "file-type";
import sharp from "sharp";
import { AppError } from "@/lib/platform/errors";
export const maxImageBytes = 4 * 1024 * 1024;
export async function normalizeUpload(input: Uint8Array) {
  if (!input.length || input.length > maxImageBytes)
    throw new AppError(
      "PAYLOAD_TOO_LARGE",
      413,
      "Images must be smaller than 4 MB.",
    );
  const type = await fileTypeFromBuffer(input).catch(() => undefined);
  if (!type || !["image/jpeg", "image/png", "image/webp"].includes(type.mime))
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Choose a JPEG, PNG or WebP image.",
    );
  try {
    const image = sharp(input, { limitInputPixels: 16000000, animated: false });
    const metadata = await image.metadata();
    if (metadata.pages && metadata.pages > 1) throw new Error("Animated image");
    const result = await image
      .rotate()
      .resize({
        width: 2400,
        height: 2400,
        fit: "inside",
        withoutEnlargement: true,
      })
      .webp({ quality: 85 })
      .toBuffer({ resolveWithObject: true });
    return {
      bytes: result.data,
      width: result.info.width,
      height: result.info.height,
      mimeType: "image/webp",
    };
  } catch {
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "This image could not be safely processed. Choose another image.",
    );
  }
}
