import { S3Client } from "@aws-sdk/client-s3";
export function storage() {
  const region = process.env.S3_REGION,
    accessKeyId = process.env.S3_ACCESS_KEY,
    secretAccessKey = process.env.S3_SECRET_KEY;
  if (!region || !accessKeyId || !secretAccessKey || !process.env.S3_BUCKET)
    throw new Error("Private object storage is not configured");
  return new S3Client({
    region,
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: !!process.env.S3_ENDPOINT,
    credentials: { accessKeyId, secretAccessKey },
  });
}
export function bucket() {
  if (!process.env.S3_BUCKET)
    throw new Error("Private object storage is not configured");
  return process.env.S3_BUCKET;
}
