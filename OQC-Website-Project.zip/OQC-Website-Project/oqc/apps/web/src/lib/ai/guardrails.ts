export function redact(text: string) {
  return text
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[email]")
    .replace(/(?:\+?\d[\d .()-]{7,}\d)/g, "[phone-or-id]")
    .replace(/https?:\/\/[^\s]+/g, "[url]");
}
export function verifiedNumbers(answer: string, sources: string[]) {
  const numbers: string[] = answer.match(/\d+(?:[.,]\d+)*/g) ?? [];
  return numbers.every((n) =>
    sources.some((source) =>
      Array.from(source.match(/\d+(?:[.,]\d+)*/g) ?? []).includes(n),
    ),
  );
}
export const aiFallback = {
  error: {
    code: "AI_UNAVAILABLE",
    message: "AI assistance is currently unavailable. Please contact our team.",
  },
  handoff: { show: true, href: "/contact" },
  disclosure: true,
};
