import type { NextResponse } from "next/server";
import { authCookiePolicy } from "@/lib/platform/env";
export function clearSessionCookie(
  response: NextResponse,
  input: NodeJS.ProcessEnv = process.env,
) {
  const policy = authCookiePolicy(input);
  response.cookies.set(policy.name, "", {
    httpOnly: true,
    secure: policy.secure,
    sameSite: "lax",
    path: "/",
    expires: new Date(0),
    maxAge: 0,
  });
}
