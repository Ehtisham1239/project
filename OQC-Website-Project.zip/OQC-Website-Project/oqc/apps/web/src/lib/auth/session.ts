import { cookies } from "next/headers";
import { AppError } from "@/lib/platform/errors";
import { can } from "@/lib/rbac/policy";
import { sessionByToken, validateCsrf } from "@/server/repositories/identity";
import { authCookiePolicy } from "@/lib/platform/env";
export function sessionCookieName() {
  return authCookiePolicy(process.env).name;
}
export async function currentSession() {
  const token = (await cookies()).get(sessionCookieName())?.value;
  if (!token) return null;
  return sessionByToken(token);
}
export async function requirePermission(permission: string) {
  const session = await currentSession();
  if (!session) throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
  if (!can(session.user.role.key, permission))
    throw new AppError(
      "FORBIDDEN",
      403,
      "You do not have permission for this action.",
    );
  return session;
}
export function requireOrigin(request: Request) {
  const expected = new URL(process.env.APP_URL ?? "http://localhost:3000")
    .origin;
  const origin = request.headers.get("origin");
  if (origin !== expected)
    throw new AppError("FORBIDDEN", 403, "Request origin is not allowed.");
}
export async function requireMutation(request: Request, permission: string) {
  requireOrigin(request);
  const session = await requirePermission(permission);
  const token = (await cookies()).get(sessionCookieName())?.value;
  const csrf = request.headers.get("x-csrf-token");
  if (!token || !csrf)
    throw new AppError("FORBIDDEN", 403, "Refresh this page and try again.");
  await validateCsrf(token, csrf);
  return session;
}
export function requireRecentAuth(session: { reauthenticatedAt: Date | null }) {
  if (
    !session.reauthenticatedAt ||
    Date.now() - session.reauthenticatedAt.getTime() > 5 * 60 * 1000
  )
    throw new AppError(
      "REAUTH_REQUIRED",
      403,
      "Please confirm your password and MFA code again.",
    );
}
export async function requireSessionMutation(request: Request) {
  requireOrigin(request);
  const session = await currentSession();
  if (!session) throw new AppError("UNAUTHENTICATED", 401, "Please sign in.");
  const token = (await cookies()).get(sessionCookieName())?.value;
  const csrf = request.headers.get("x-csrf-token");
  if (!token || !csrf)
    throw new AppError("FORBIDDEN", 403, "Refresh this page and try again.");
  await validateCsrf(token, csrf);
  return session;
}
