"use client";
export async function getCsrfToken() {
  const response = await fetch("/api/v1/auth/session", {
    cache: "no-store",
    credentials: "same-origin",
  });
  const body = await response.json();
  if (!response.ok)
    throw new Error(body.error?.message ?? "Please sign in again.");
  return body.data.csrf as string;
}
