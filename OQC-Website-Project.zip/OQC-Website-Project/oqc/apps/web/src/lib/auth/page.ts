import { forbidden, redirect } from "next/navigation";
import { currentSession } from "./session";
import { can } from "@/lib/rbac/policy";
export async function requirePagePermission(permission: string) {
  const session = await currentSession();
  if (!session) redirect("/admin/login");
  if (!can(session.user.role.key, permission)) forbidden();
  return session;
}
