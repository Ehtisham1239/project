import { trialSchema, type TrialInput } from "@/lib/validation/admissions";
export const preferenceDraftKey = "oqc.trial.preferences.v1";
const lifetime = 30 * 60 * 1000;
const fields = [
  "courseId",
  "country",
  "timezone",
  "ageBand",
  "level",
  "teacherGenderPref",
  "teachingLanguage",
  "availableSlots",
] as const;
function preferences(value: unknown): Partial<TrialInput> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const input = value as Record<string, unknown>,
    output: Record<string, unknown> = {};
  for (const field of fields) {
    const parsed = trialSchema.shape[field].safeParse(input[field]);
    if (parsed.success) output[field] = parsed.data;
  }
  return output as Partial<TrialInput>;
}
export function encodePreferenceDraft(value: unknown, now = Date.now()) {
  return JSON.stringify({
    expiresAt: now + lifetime,
    preferences: preferences(value),
  });
}
export function decodePreferenceDraft(
  raw: string | null,
  now = Date.now(),
): Partial<TrialInput> {
  if (!raw || raw.length > 4000) return {};
  try {
    const stored = JSON.parse(raw);
    if (
      typeof stored.expiresAt !== "number" ||
      stored.expiresAt <= now ||
      stored.expiresAt > now + lifetime
    )
      return {};
    return preferences(stored.preferences);
  } catch {
    return {};
  }
}
