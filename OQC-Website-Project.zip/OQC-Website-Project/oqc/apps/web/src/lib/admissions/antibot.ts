import { AppError } from "@/lib/platform/errors";
export async function verifyBot(
  {
    website,
    startedAt,
    botToken,
  }: {
    website: string;
    startedAt: number;
    botToken: string;
  },
  allowWithoutProvider = false,
) {
  const elapsed = Date.now() - startedAt;
  if (website || elapsed < 3000 || elapsed > 24 * 60 * 60 * 1000)
    throw new AppError(
      "BOT_CHECK_FAILED",
      400,
      "Please complete the form and try again.",
    );
  if (
    process.env.NODE_ENV !== "production" &&
    botToken === "development-bypass"
  )
    return;
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret && allowWithoutProvider) return;
  if (!secret)
    throw new AppError(
      "BOT_CHECK_UNAVAILABLE",
      503,
      "Admissions is temporarily unavailable. Please try again later.",
    );
  let result;
  try {
    const response = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ secret, response: botToken }),
        signal: AbortSignal.timeout(5000),
      },
    );
    if (!response.ok) throw new Error("Turnstile unavailable");
    result = (await response.json()) as { success: boolean; hostname?: string };
  } catch {
    throw new AppError(
      "BOT_CHECK_UNAVAILABLE",
      503,
      "Please try again shortly.",
    );
  }
  if (
    !result.success ||
    result.hostname !==
      new URL(process.env.APP_URL ?? "http://localhost:3000").hostname
  )
    throw new AppError(
      "BOT_CHECK_FAILED",
      400,
      "Please try the verification again.",
    );
}
