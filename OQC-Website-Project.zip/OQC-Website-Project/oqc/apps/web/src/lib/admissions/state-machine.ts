export const trialStates = [
  "NEW",
  "REVIEWED",
  "SCHEDULED",
  "COMPLETED",
  "ENROLLED",
  "CANCELLED",
  "NO_SHOW",
] as const;
export type TrialState = (typeof trialStates)[number];
const transitions: Record<TrialState, readonly TrialState[]> = {
  NEW: ["REVIEWED", "CANCELLED"],
  REVIEWED: ["SCHEDULED", "CANCELLED"],
  SCHEDULED: ["COMPLETED", "NO_SHOW", "CANCELLED"],
  COMPLETED: ["ENROLLED", "CANCELLED"],
  ENROLLED: ["CANCELLED"],
  CANCELLED: [],
  NO_SHOW: ["CANCELLED"],
};
export const canTransition = (from: TrialState, to: TrialState) =>
  transitions[from].includes(to);
