import Redis from "ioredis";
import { AppError } from "@/lib/platform/errors";
let redis: Redis | undefined;
const counters = new Map<string, { count: number; expires: number }>();
export async function rateLimit(
  key: string,
  limit: number,
  windowSeconds: number,
) {
  try {
    if (!redis) {
      redis = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
        maxRetriesPerRequest: 1,
        enableOfflineQueue: false,
        lazyConnect: true,
        connectTimeout: 1500,
        retryStrategy: () => null,
      });
      // Register once per connection; request failures are handled below.
      redis.on("error", () => {});
    }
    if (redis.status === "wait") await redis.connect();
    const result = (await redis.eval(
      "local c=redis.call('INCR',KEYS[1]); if c==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]) end; return c",
      1,
      "oqc:rate:" + key,
      windowSeconds,
    )) as number;
    if (result > limit)
      throw new AppError(
        "RATE_LIMITED",
        429,
        "Please wait before trying again.",
        { retryAfter: windowSeconds },
      );
    return;
  } catch (error) {
    if (error instanceof AppError) throw error;
    if (process.env.NODE_ENV === "production")
      throw new AppError(
        "RATE_LIMIT_UNAVAILABLE",
        503,
        "Please try again shortly.",
      );
    const now = Date.now();
    for (const [k, v] of counters) if (v.expires <= now) counters.delete(k);
    if (counters.size > 10000)
      throw new AppError("RATE_LIMITED", 429, "Please try again shortly.");
    const counter = counters.get(key) ?? {
      count: 0,
      expires: now + windowSeconds * 1000,
    };
    counter.count++;
    counters.set(key, counter);
    if (counter.count > limit)
      throw new AppError(
        "RATE_LIMITED",
        429,
        "Please wait before trying again.",
        { retryAfter: windowSeconds },
      );
  }
}
