import Link from "next/link";
export default function NotFound() {
  return (
    <main className="container page-title">
      <span className="eyebrow">404</span>
      <h1>This page isn’t here.</h1>
      <p>Return to the homepage or contact our team for help.</p>
      <Link href="/" className="button button-primary">
        Go home
      </Link>
    </main>
  );
}
