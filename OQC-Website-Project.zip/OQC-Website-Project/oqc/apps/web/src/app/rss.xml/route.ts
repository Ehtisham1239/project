import { database } from "@/lib/db";
import { siteUrl } from "@/lib/platform/seo";
import messages from "@/messages/en.json";
export const dynamic = "force-dynamic";
const xml = (value: string) =>
  value.replace(
    /[<>&"']/g,
    (char) =>
      ({
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        '"': "&quot;",
        "'": "&apos;",
      })[char]!,
  );
export async function GET() {
  const posts = await database().blogPost.findMany({
    where: { status: "PUBLISHED", locale: "en" },
    take: 50,
    orderBy: [{ publishedAt: "desc" }, { id: "asc" }],
    select: { slug: true, title: true, excerpt: true, publishedAt: true },
  });
  const body = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel><title>${xml(messages.brand)} Journal</title><link>${xml(siteUrl("/blog"))}</link><description>Published articles from ${xml(messages.brand)}</description><language>en</language><atom:link href="${xml(siteUrl("/rss.xml"))}" rel="self" type="application/rss+xml"/>${posts.map((post) => `<item><title>${xml(post.title)}</title><link>${xml(siteUrl("/blog/" + post.slug))}</link><guid isPermaLink="true">${xml(siteUrl("/blog/" + post.slug))}</guid><description>${xml(post.excerpt)}</description>${post.publishedAt ? `<pubDate>${post.publishedAt.toUTCString()}</pubDate>` : ""}</item>`).join("")}</channel></rss>`;
  return new Response(body, {
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
