import { InvoicePdf } from "@/components/admin/invoice-pdf";
import { InvoiceVoid } from "@/components/admin/invoice-void";
import { RevisionHistory } from "@/components/admin/revision-history";
import {
  contentRevisions,
  revisionResource,
} from "@/server/services/revisions";
import { revisionFields } from "@/lib/content/revision-fields";
import { PublicationSchedule } from "@/components/admin/publication-schedule";
import { PreviewLink } from "@/components/admin/preview-link";
import {
  scheduledPublication,
  scheduledResource,
} from "@/server/services/publication-schedules";
import { AttendanceEditor } from "@/components/admin/attendance-editor";
import { ClassSessionEditor } from "@/components/admin/class-session-editor";
import { sessionAttendance } from "@/server/services/academics";
import { contactAssignees } from "@/server/services/contact-workflow";
import { ContactWorkflow } from "@/components/admin/contact-workflow";
import { planPrices } from "@/server/services/prices";
import { PlanPrices } from "@/components/admin/plan-prices";
import { courseModules } from "@/server/services/course-modules";
import { CourseModules } from "@/components/admin/course-modules";
import {
  teacherAvailability,
  trialWorkspace,
  teacherCourses,
} from "@/server/services/academics";
import { TrialWorkflow } from "@/components/admin/trial-workflow";
import { TeacherAvailability } from "@/components/admin/teacher-availability";
import { TeacherCourses } from "@/components/admin/teacher-courses";
import type { TrialState } from "@/lib/admissions/state-machine";
import { pageSections } from "@/server/services/content";
import { PageEditor } from "@/components/admin/page-editor";
import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { requirePagePermission } from "@/lib/auth/page";
import { can } from "@/lib/rbac/policy";
import { getRecord } from "@/server/services/admin";
import { recordFields } from "@/components/admin/record-fields";
import { RecordEditor } from "@/components/admin/record-editor";
import { AppError } from "@/lib/platform/errors";
export default async function Detail({
  params,
}: {
  params: Promise<{ resource: string; id: string }>;
}) {
  const { resource, id } = await params;
  const session = await requirePagePermission(resource + ":read");
  if (!z.uuid().safeParse(id).success) notFound();
  let record;
  try {
    record = await getRecord(resource, id, session.userId);
  } catch (error) {
    if (error instanceof AppError && error.status === 404) notFound();
    throw error;
  }
  const trialData = resource === "trials" ? await trialWorkspace(id) : null;
  const teacherData =
    resource === "teachers" && can(session.user.role.key, "teachers:update")
      ? await teacherCourses(id)
      : null;
  const availability =
    resource === "teachers" &&
    can(session.user.role.key, "teachers:availability")
      ? await teacherAvailability(id)
      : null;
  const sections =
    resource === "pages" && can(session.user.role.key, "pages:update")
      ? await pageSections(id)
      : null;
  const modules =
    resource === "courses" &&
    (can(session.user.role.key, "courses:update") ||
      can(session.user.role.key, "courses:update-content"))
      ? await courseModules(id)
      : null;
  const prices =
    resource === "pricing-plans" &&
    can(session.user.role.key, "pricing-plans:update")
      ? await planPrices(id)
      : null;
  const contactOperators =
    resource === "contact-messages" &&
    can(session.user.role.key, "contact-messages:update")
      ? await contactAssignees()
      : null;
  const initial = JSON.parse(JSON.stringify(record));
  const attendance =
    resource === "sessions" && can(session.user.role.key, "attendance:read")
      ? await sessionAttendance(id)
      : null;
  const full = can(session.user.role.key, resource + ":update");
  const content = can(session.user.role.key, resource + ":update-content");
  const revisions = revisionResource(resource)
    ? await contentRevisions(resource, id)
    : null;
  const publication =
    scheduledResource(resource) &&
    can(session.user.role.key, resource + ":publish")
      ? await scheduledPublication(resource, id)
      : null;
  const allowed =
    resource === "courses"
      ? ["title", "summary", "description", "seoTitle", "seoDescription"]
      : ["bio", "qualificationsText"];
  const fields = recordFields[resource]?.filter(
    (field) => full || (content && allowed.includes(field.key)),
  );
  return (
    <div data-record-version={record.version}>
      <nav className="breadcrumbs">
        <Link href={"/admin/" + resource}>{resource.replaceAll("-", " ")}</Link>{" "}
        / Record
      </nav>
      <h1>
        {String(
          record.title ??
            record.displayName ??
            record.learnerName ??
            record.fullName ??
            record.name ??
            "Record details",
        )}
      </h1>
      {["courses", "blog", "pages"].includes(resource) && (
        <div style={{ marginBlock: 16 }}>
          <PreviewLink resource={resource} id={id} />
        </div>
      )}
      {fields?.length && (full || content) && (
        <>
          {[
            "courses",
            "blog",
            "pages",
            "faqs",
            "testimonials",
            "pricing-plans",
          ].includes(resource) && (
            <p>
              Content edits return approved or published records to draft for
              review.
            </p>
          )}
          {resource === "menus" && (
            <p>Navigation changes appear on the website immediately.</p>
          )}
          <RecordEditor
            key={String(record.version ?? record.updatedAt)}
            resource={resource}
            id={id}
            fields={fields}
            initial={initial}
          />
        </>
      )}
      {trialData && (
        <>
          <TrialWorkflow
            key={String(record.version)}
            id={id}
            status={record.status as TrialState}
            version={record.version!}
            timezone={String(record.timezone)}
            assignedTeacherId={record.assignedTeacherId as string | null}
            teachers={trialData.teachers}
            permissions={{
              assign: can(session.user.role.key, "trials:assign"),
              status: can(session.user.role.key, "trials:status"),
              convert: can(session.user.role.key, "trials:convert"),
              notes: can(session.user.role.key, "trials:notes"),
            }}
          />
          <section className="card">
            <h2>Internal notes</h2>
            {trialData.notes.length ? (
              trialData.notes.map((note) => (
                <article key={note.id}>
                  <p>{note.body}</p>
                  <p>
                    {note.author.name} · {note.createdAt.toISOString()}
                  </p>
                </article>
              ))
            ) : (
              <p>No internal notes.</p>
            )}
          </section>
        </>
      )}
      {modules && (
        <CourseModules
          key={"modules-" + record.version}
          id={id}
          version={record.version!}
          status={String(record.status)}
          initial={modules}
        />
      )}
      {teacherData && (
        <TeacherCourses
          key={String(record.version)}
          id={id}
          version={record.version!}
          {...teacherData}
        />
      )}
      {availability && (
        <TeacherAvailability
          key={"availability-" + record.version}
          id={id}
          version={record.version!}
          initial={availability}
        />
      )}
      {sections && (
        <PageEditor
          key={String(record.version)}
          id={id}
          version={record.version!}
          status={String(record.status)}
          sections={JSON.parse(JSON.stringify(sections))}
        />
      )}
      {prices && (
        <PlanPrices
          key={"prices-" + record.version}
          id={id}
          version={record.version!}
          status={String(record.status)}
          initial={prices}
        />
      )}
      {contactOperators && (
        <ContactWorkflow
          key={String(record.updatedAt)}
          id={id}
          updatedAt={String(initial.updatedAt)}
          status={String(record.status)}
          assignedToUserId={record.assignedToUserId as string | null}
          operators={contactOperators}
        />
      )}
      {resource === "invoices" && record.status !== "DRAFT" && (
        <InvoicePdf id={id} number={String(record.number)} />
      )}
      {resource === "invoices" &&
        ["DRAFT", "ISSUED"].includes(String(record.status)) &&
        can(session.user.role.key, "invoices:update") && (
          <InvoiceVoid
            key={"void-" + record.version}
            id={id}
            version={record.version!}
          />
        )}
      {resource === "sessions" &&
        record.kind === "REGULAR" &&
        ["PLANNED", "RESCHEDULED"].includes(String(record.status)) &&
        can(session.user.role.key, "sessions:update") && (
          <ClassSessionEditor
            key={"class-" + record.version}
            id={id}
            version={record.version!}
            startsAtUtc={initial.startsAtUtc}
            endsAtUtc={initial.endsAtUtc}
            meetingUrl={initial.meetingUrl}
            timezone={attendance?.teacher.timezone ?? "UTC"}
            canMarkHeld={attendance?.canMarkHeld ?? false}
          />
        )}
      {attendance && (
        <AttendanceEditor
          key={attendance.attendance?.updatedAt ?? "unmarked"}
          workspace={attendance}
          editable={can(session.user.role.key, "attendance:create")}
        />
      )}
      {resource === "attendance" &&
        can(session.user.role.key, "sessions:read") && (
          <Link
            className="button button-secondary"
            href={`/admin/sessions/${record.sessionId}`}
          >
            Open class attendance
          </Link>
        )}
      {resource === "media" && (
        <a
          className="button button-secondary"
          href={`/api/v1/admin/media/${id}/file`}
          target="_blank"
          rel="noopener noreferrer"
        >
          View private image
        </a>
      )}
      {revisions && (
        <RevisionHistory
          key={"history-" + record.version}
          resource={resource}
          id={id}
          version={record.version!}
          current={revisionFields({
            ...record,
            ...(modules ? { modules } : {}),
            ...(sections ? { pageSection_pageId: sections } : {}),
          })}
          restorable={full || content}
          revisions={revisions.map((revision) => ({
            id: revision.id,
            createdAt: revision.createdAt.toISOString(),
            author: revision.author.name,
            fields: revisionFields(revision.snapshot),
          }))}
        />
      )}
      {scheduledResource(resource) &&
        can(session.user.role.key, resource + ":publish") && (
          <PublicationSchedule
            key={"publication-" + record.version}
            resource={resource}
            id={id}
            version={record.version!}
            status={String(record.status)}
            scheduled={publication}
          />
        )}
      <dl className="card">
        {Object.entries(initial)
          .filter(
            ([key]) =>
              ![
                "description",
                "body",
                "renderedHtml",
                "ipHash",
                "userAgentHash",
                "requestHash",
                "idempotencyKey",
              ].includes(key),
          )
          .map(([key, value]) => (
            <div className="field" key={key}>
              <dt>{key.replace(/([A-Z])/g, " $1")}</dt>
              <dd>
                {typeof value === "object"
                  ? JSON.stringify(value)
                  : String(value ?? "—")}
              </dd>
            </div>
          ))}
      </dl>
    </div>
  );
}
