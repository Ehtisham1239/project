import { requirePagePermission } from "@/lib/auth/page";
import { staffUsers } from "@/server/services/users";
import { StaffUsers } from "@/components/admin/users";
export default async function Users() {
  const session = await requirePagePermission("users:read");
  return (
    <>
      <h1>Staff access</h1>
      <StaffUsers
        users={JSON.parse(JSON.stringify(await staffUsers()))}
        actorRole={session.user.role.key}
      />
    </>
  );
}
