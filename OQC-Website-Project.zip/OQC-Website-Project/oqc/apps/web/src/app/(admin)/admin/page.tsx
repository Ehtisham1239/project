import { currentSession } from "@/lib/auth/session";
import { can } from "@/lib/rbac/policy";
import { listRecords } from "@/server/services/admin";
import { launchReadiness } from "@/server/services/content";
export default async function Dashboard() {
  const session = await currentSession();
  if (!session) return null;
  const modules = [
    "courses",
    "teachers",
    "trials",
    "students",
    "enrollments",
    "contact-messages",
  ];
  const readiness = can(session.user.role.key, "settings:read")
    ? await launchReadiness()
    : [];
  const counts = await Promise.all(
    modules
      .filter((module) => can(session.user.role.key, module + ":read"))
      .map(async (module) => ({
        module,
        total: (await listRecords(module, 1, 1, session.userId)).meta.total,
      })),
  );
  return (
    <>
      <span className="eyebrow">Staff workspace</span>
      <h1>Overview</h1>
      <p>Only records visible to your role are counted.</p>
      <div className="card-grid">
        {counts.map(({ module, total }) => (
          <article className="card" key={module}>
            <h2>{total}</h2>
            <p>{module.replaceAll("-", " ")}</p>
          </article>
        ))}
      </div>
      {readiness.length > 0 && (
        <section className="card" style={{ marginTop: 24 }}>
          <h2>Launch readiness</h2>
          <ul>
            {readiness.map((item) => (
              <li key={item.key}>
                {item.passed ? "✓" : "Pending:"} {item.label}
              </li>
            ))}
          </ul>
        </section>
      )}
      <section className="notice" style={{ marginTop: 32 }}>
        Development in progress. Public launch requires approved content, legal
        policies and owner signoff.
      </section>
    </>
  );
}
