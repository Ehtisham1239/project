import Link from "next/link";
import { DateTime } from "luxon";
import { requirePagePermission } from "@/lib/auth/page";
import { classCalendar } from "@/server/services/calendar";
import { AppError } from "@/lib/platform/errors";
export default async function Calendar({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requirePagePermission("sessions:read");
  const query = await searchParams;
  let result;
  try {
    result = await classCalendar(
      Object.fromEntries(
        Object.entries(query).filter(
          ([, value]) => value !== "" && value !== undefined,
        ),
      ),
    );
  } catch (error) {
    if (error instanceof AppError && error.status === 400)
      return (
        <>
          <h1>Class calendar</h1>
          <p role="alert">{error.message}</p>
          <Link href="/admin/calendar">Reset calendar filters</Link>
        </>
      );
    throw error;
  }
  const start = DateTime.fromISO(result.from, { zone: result.timezone });
  const link = (direction: number) =>
    `/admin/calendar?${new URLSearchParams({ from: start.plus({ days: direction * Number(result.days) }).toISODate()!, timezone: result.timezone, days: result.days, ...(result.teacherId ? { teacherId: result.teacherId } : {}) })}`;
  const time = (value: string, zone: string) =>
    DateTime.fromISO(value).setZone(zone).toFormat("dd LLL, HH:mm");
  return (
    <>
      <nav className="breadcrumbs">
        <Link href="/admin">Overview</Link> / Calendar
      </nav>
      <h1>Class calendar</h1>
      <form action="/admin/calendar" method="GET" className="card form">
        <div className="field">
          <label htmlFor="calendar-from">Calendar start date</label>
          <input
            id="calendar-from"
            type="date"
            name="from"
            required
            defaultValue={result.from}
          />
        </div>
        <div className="field">
          <label htmlFor="calendar-zone">Calendar time zone</label>
          <input
            id="calendar-zone"
            name="timezone"
            required
            defaultValue={result.timezone}
          />
        </div>
        <div className="field">
          <label htmlFor="calendar-days">Calendar view</label>
          <select id="calendar-days" name="days" defaultValue={result.days}>
            <option value="1">Day</option>
            <option value="7">Week</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="calendar-teacher">Calendar teacher</label>
          <select
            id="calendar-teacher"
            name="teacherId"
            defaultValue={result.teacherId}
          >
            <option value="">All teachers</option>
            {result.teachers.map((teacher) => (
              <option key={teacher.id} value={teacher.id}>
                {teacher.displayName}
              </option>
            ))}
          </select>
        </div>
        <button className="button" type="submit">
          Show calendar
        </button>
      </form>
      <nav className="toolbar" aria-label="Calendar periods">
        <Link href={link(-1)}>
          Previous {result.days === "7" ? "week" : "day"}
        </Link>
        <span>Times shown in {result.timezone}</span>
        <Link href={link(1)}>Next {result.days === "7" ? "week" : "day"}</Link>
      </nav>
      {result.truncated && (
        <p role="status">
          Showing the first 500 classes. Choose a day or teacher to narrow the
          calendar.
        </p>
      )}
      {result.dates.map((date) => {
        const dayStart = DateTime.fromISO(date, { zone: result.timezone }),
          dayEnd = dayStart.plus({ days: 1 });
        const sessions = result.sessions.filter(
          (session) =>
            DateTime.fromISO(session.startsAtUtc).toMillis() <
              dayEnd.toMillis() &&
            DateTime.fromISO(session.endsAtUtc).toMillis() >
              dayStart.toMillis(),
        );
        return (
          <section className="card" style={{ marginBlock: 16 }} key={date}>
            <h2>{dayStart.toFormat("cccc, dd LLL yyyy")}</h2>
            {sessions.length ? (
              <ul>
                {sessions.map((session) => (
                  <li key={session.id} style={{ marginBlock: 16 }}>
                    <Link href={`/admin/sessions/${session.id}`}>
                      {session.course} ·{" "}
                      {session.learner?.name ?? "Unassigned learner"}
                    </Link>
                    <p>
                      {time(session.startsAtUtc, result.timezone)}–
                      {time(session.endsAtUtc, result.timezone)} ·{" "}
                      {session.status.toLowerCase()}
                    </p>
                    <p>
                      Teacher: {session.teacher.name} ·{" "}
                      {time(session.startsAtUtc, session.teacher.timezone)} (
                      {session.teacher.timezone})
                    </p>
                    {session.learner && (
                      <p>
                        Learner time:{" "}
                        {time(session.startsAtUtc, session.learner.timezone)} (
                        {session.learner.timezone})
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p>No classes scheduled.</p>
            )}
          </section>
        );
      })}
    </>
  );
}
