import Link from "next/link";
import { requirePagePermission } from "@/lib/auth/page";
import { staffNotifications } from "@/server/services/notifications";
import { NotificationRead } from "@/components/admin/notification-read";
const links: Record<string, string> = {
  "trial.submitted": "trials",
  "trial.status_changed": "trials",
  "contact.received": "contact-messages",
  "invoice.issued": "invoices",
  "payment.recorded": "payments",
};
export default async function Notifications() {
  const session = await requirePagePermission("notifications:read");
  const items = await staffNotifications(session.userId);
  return (
    <>
      <h1>Your notifications</h1>
      {items.length ? (
        items.map((item) => (
          <article className="card" key={item.id} style={{ marginBlock: 16 }}>
            <h2>{item.kind.replaceAll(".", " ").replaceAll("_", " ")}</h2>
            <p>
              {item.createdAt.toISOString()} · {item.readAt ? "Read" : "Unread"}
            </p>
            {links[item.kind] && item.entityId && (
              <Link href={"/admin/" + links[item.kind] + "/" + item.entityId}>
                Open record
              </Link>
            )}
            {!item.readAt && <NotificationRead id={item.id} />}
          </article>
        ))
      ) : (
        <section className="card">
          <h2>No notifications yet</h2>
          <p>Updates relevant to your work will appear here.</p>
        </section>
      )}
    </>
  );
}
