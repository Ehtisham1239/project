import { ownSessions } from "@/server/services/session-management";
import { SessionList } from "@/components/admin/session-list";
import { currentSession } from "@/lib/auth/session";
import { redirect } from "next/navigation";
import { AccountSecurity } from "@/components/admin/account";
import { Reauthenticate } from "@/components/admin/users";
export default async function Account() {
  const session = await currentSession();
  if (!session) redirect("/admin/login");
  const sessions = await ownSessions(session.userId, session.id);
  return (
    <>
      <h1>Your staff account</h1>
      <p>
        {session.user.name} · {session.user.email}
      </p>
      <p>Role: {session.user.role.key.replaceAll("_", " ").toLowerCase()}</p>
      <SessionList
        sessions={sessions.map((item) => ({
          ...item,
          createdAt: item.createdAt.toISOString(),
          lastSeenAt: item.lastSeenAt.toISOString(),
        }))}
      />
      <AccountSecurity />
      <Reauthenticate />
    </>
  );
}
