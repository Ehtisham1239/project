import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { requirePagePermission } from "@/lib/auth/page";
import { getRecord } from "@/server/services/admin";
import { pageSections } from "@/server/services/content";
import { courseModules } from "@/server/services/course-modules";
import { PageSections } from "@/components/public/page-sections";
import { RichText } from "@/components/public/rich-text";
import { AppError } from "@/lib/platform/errors";
import { validPreviewLink } from "@/lib/content/preview-links";
export const metadata = {
  title: "Private content preview",
  robots: { index: false, follow: false },
};
export default async function Preview({
  params,
  searchParams,
}: {
  params: Promise<{ resource: string; id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { resource, id } = await params;
  if (
    !["courses", "blog", "pages"].includes(resource) ||
    !z.uuid().safeParse(id).success
  )
    notFound();
  const actor = await requirePagePermission(resource + ":read"),
    query = await searchParams;
  if (!validPreviewLink(actor.id, resource, id, query))
    return (
      <>
        <h1>Preview link expired or invalid</h1>
        <p>
          Open a new preview from the content record. Links are valid for ten
          minutes in the staff session that created them.
        </p>
        <Link href={`/admin/${resource}/${id}`}>Back to editing</Link>
      </>
    );
  let record;
  try {
    record = await getRecord(resource, id);
  } catch (error) {
    if (error instanceof AppError && error.status === 404) notFound();
    throw error;
  }
  if (record.version !== Number(query.version))
    return (
      <>
        <h1>Content changed since this preview was opened</h1>
        <Link href={`/admin/${resource}/${id}`}>
          Open the current content record
        </Link>
      </>
    );
  const sections = resource === "pages" ? await pageSections(id) : null;
  const modules = resource === "courses" ? await courseModules(id) : null;
  return (
    <>
      <nav className="breadcrumbs">
        <Link href={`/admin/${resource}/${id}`}>Back to editing</Link> / Preview
      </nav>
      <h1>Private content preview</h1>
      <p className="notice">
        Status: {String(record.status).toLowerCase()}. This preview is available
        to authorized staff. Publishing requires the approval workflow.
      </p>
      <article className="container page-content">
        <h2>{String(record.title)}</h2>
        {Boolean(record.summary) && <p>{String(record.summary)}</p>}
        {Boolean(record.excerpt) && <p>{String(record.excerpt)}</p>}
        {resource === "courses" && <RichText document={record.description} />}
        {resource === "blog" && <RichText document={record.body} />}
        {sections && (
          <PageSections
            sections={sections.filter((section) => section.isVisible)}
          />
        )}
        {modules?.map((module) => (
          <section className="card" key={module.id}>
            <h3>{module.title}</h3>
            <p>{module.objectives}</p>
          </section>
        ))}
      </article>
    </>
  );
}
