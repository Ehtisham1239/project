import { notFound } from "next/navigation";
import Link from "next/link";
import sanitizeHtml from "sanitize-html";
import { publicPost, relatedPosts } from "@/server/services/public";
import { pageMetadata, jsonLd, siteUrl } from "@/lib/platform/seo";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const slug = (await params).slug,
    post = await publicPost(slug);
  if (!post) notFound();
  return pageMetadata(
    post.seoTitle || post.title,
    post.seoDescription || post.excerpt,
    "/blog/" + slug,
    true,
  );
}
export const dynamic = "force-dynamic";
export default async function PostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const post = await publicPost((await params).slug);
  if (!post) notFound();
  const related = await relatedPosts((await params).slug, post.tags);
  const readingMinutes = Math.max(
    1,
    Math.ceil(
      sanitizeHtml(post.renderedHtml, {
        allowedTags: [],
        allowedAttributes: {},
      })
        .split(/\s+/)
        .filter(Boolean).length / 200,
    ),
  );
  return (
    <article className="container">
      <header className="page-title">
        <Link href="/blog" className="breadcrumbs">
          ← Journal
        </Link>
        <h1>{post.title}</h1>
        <p>{post.excerpt}</p>
        <p>
          By {post.author.name} · {readingMinutes} minute read
          {post.publishedAt
            ? " · " + post.publishedAt.toISOString().slice(0, 10)
            : ""}
        </p>
        {post.tags.length > 0 && (
          <p>
            {post.tags.map((tag) => (
              <Link
                href={`/blog?tag=${encodeURIComponent(tag)}`}
                key={tag}
                style={{ marginInlineEnd: 12 }}
              >
                {tag}
              </Link>
            ))}
          </p>
        )}
      </header>
      <div
        className="page-content"
        dangerouslySetInnerHTML={{
          __html: sanitizeHtml(post.renderedHtml, {
            allowedTags: [
              "p",
              "h2",
              "h3",
              "ul",
              "ol",
              "li",
              "strong",
              "em",
              "blockquote",
              "br",
            ],
            allowedAttributes: {},
          }),
        }}
      />
      {related.length > 0 && (
        <section className="page-content">
          <h2>Related articles</h2>
          <div className="card-grid">
            {related.map((article) => (
              <article className="card" key={article.id}>
                <h3>
                  <Link href={"/blog/" + article.slug}>{article.title}</Link>
                </h3>
                <p>{article.excerpt}</p>
              </article>
            ))}
          </div>
        </section>
      )}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: jsonLd({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: post.title,
            description: post.excerpt,
            ...(post.publishedAt
              ? { datePublished: post.publishedAt.toISOString() }
              : {}),
            author: { "@type": "Person", name: post.author.name },
            url: siteUrl("/blog/" + (await params).slug),
          }),
        }}
      />
    </article>
  );
}
