"use client";
import Link from "next/link";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <section className="container page-title">
      <h1>We could not load this page.</h1>
      <p>Please try again or contact our team for help.</p>
      <button className="button button-primary" onClick={reset}>
        Try again
      </button>
      <p>
        <Link href="/courses">Browse courses</Link> ·{" "}
        <Link href="/contact">Contact our team</Link>
      </p>
    </section>
  );
}
