import type { MetadataRoute } from "next";
import { publishedPaths } from "@/server/services/public";
export const dynamic = "force-dynamic";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.APP_URL ?? "http://localhost:3000";
  const pages = await publishedPaths();
  return [
    { url: base },
    ...pages.map((page) => ({
      url: base + page.path,
      lastModified: page.updatedAt,
    })),
  ];
}
