import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireOrigin } from "@/lib/auth/session";
import { resetPassword } from "@/server/services/users";
import { password } from "@/lib/validation/common";
import { hashToken } from "@/lib/auth/crypto";
import { rateLimit } from "@/lib/ratelimit";
export function POST(request: Request) {
  return api(async () => {
    requireOrigin(request);
    const body = await parseBody(
      request,
      z
        .object({
          token: z.string().min(40).max(100),
          password,
          code: z.string().max(64).optional(),
        })
        .strict(),
    );
    await rateLimit("reset:" + hashToken(body.token), 5, 900);
    return Response.json({
      data: await resetPassword(body.token, body.password, body.code),
    });
  });
}
