import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireOrigin } from "@/lib/auth/session";
import {
  beginMfaEnrollment,
  completeMfaEnrollment,
} from "@/server/services/identity";
import { rateLimit } from "@/lib/ratelimit";
import { hashToken } from "@/lib/auth/crypto";
const schema = z
  .object({
    token: z.string().min(40).max(100),
    code: z
      .string()
      .regex(/^\d{6}$/)
      .optional(),
  })
  .strict();
export function POST(request: Request) {
  return api(async () => {
    requireOrigin(request);
    const body = await parseBody(request, schema);
    await rateLimit("mfa:" + hashToken(body.token), 5, 900);
    return Response.json({
      data: body.code
        ? await completeMfaEnrollment(body.token, body.code)
        : await beginMfaEnrollment(body.token),
    });
  });
}
