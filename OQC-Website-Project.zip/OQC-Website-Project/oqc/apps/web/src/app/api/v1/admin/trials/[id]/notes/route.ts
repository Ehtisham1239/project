import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { addTrialNote } from "@/server/services/academics";
export function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "trials:notes");
    const body = await parseBody(
      request,
      z.object({ body: z.string().trim().min(1).max(1000) }).strict(),
    );
    return Response.json(
      {
        data: await addTrialNote(
          z.uuid().parse((await params).id),
          body.body,
          session.userId,
        ),
      },
      { status: 201 },
    );
  });
}
