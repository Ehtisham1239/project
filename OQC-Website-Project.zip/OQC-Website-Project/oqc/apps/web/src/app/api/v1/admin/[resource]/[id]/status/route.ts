import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { statusSchema } from "@/lib/validation/admin";
import { trialStates } from "@/lib/admissions/state-machine";
import { publishRecord } from "@/server/services/admin";
import { changeTrialStatus } from "@/server/services/admissions";
import { z } from "zod";
export async function POST(
  request: Request,
  { params }: { params: Promise<{ resource: string; id: string }> },
) {
  return api(async () => {
    const { resource, id } = await params;
    if (resource === "trials") {
      const session = await requireMutation(request, "trials:status");
      const data = await parseBody(
        request,
        z
          .object({
            status: z.enum(trialStates),
            version: z.number().int().positive(),
            note: z.string().max(1000).optional(),
          })
          .strict(),
      );
      return Response.json({
        data: await changeTrialStatus(
          id,
          data.status,
          session.userId,
          data.version,
          data.note,
        ),
      });
    }
    const body = await parseBody(request, statusSchema);
    const session = await requireMutation(
      request,
      resource + ":" + (body.status === "SUBMITTED" ? "submit" : "publish"),
    );
    return Response.json({
      data: await publishRecord(
        resource,
        id,
        body.status,
        body.version,
        session.userId,
      ),
    });
  });
}
