import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import {
  requirePermission,
  requireMutation,
  requireRecentAuth,
} from "@/lib/auth/session";
import { staffUsers, inviteUser } from "@/server/services/users";
import { roles } from "@/lib/rbac/policy";
import { email } from "@/lib/validation/common";
export function GET() {
  return api(async () => {
    await requirePermission("users:read");
    return Response.json({ data: await staffUsers() });
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "users:create");
    requireRecentAuth(session);
    const body = await parseBody(
      request,
      z
        .object({
          name: z.string().trim().min(2).max(100),
          email,
          role: z.enum(roles),
        })
        .strict(),
    );
    return Response.json(
      { data: await inviteUser(body, session.userId, session.user.role.key) },
      { status: 201 },
    );
  });
}
