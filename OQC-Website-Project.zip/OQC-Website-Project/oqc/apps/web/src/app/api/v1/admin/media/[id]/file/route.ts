import { api } from "@/lib/platform/http";
import { requirePermission } from "@/lib/auth/session";
import { privateImage } from "@/server/services/media";
import { z } from "zod";
import { AppError } from "@/lib/platform/errors";
export function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    await requirePermission("media:read");
    const id = (await params).id;
    if (!z.uuid().safeParse(id).success)
      throw new AppError("NOT_FOUND", 404, "Image not found.");
    return privateImage(id);
  });
}
