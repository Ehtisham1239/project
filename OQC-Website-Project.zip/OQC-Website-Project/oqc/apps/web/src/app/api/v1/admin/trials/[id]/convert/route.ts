import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { convertTrial } from "@/server/services/academics";
export function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "trials:convert");
    const body = await parseBody(
      request,
      z
        .object({
          version: z.number().int().positive(),
          confirmed: z.literal(true),
        })
        .strict(),
    );
    return Response.json(
      {
        data: await convertTrial(
          (await params).id,
          body.version,
          session.userId,
        ),
      },
      { status: 201 },
    );
  });
}
