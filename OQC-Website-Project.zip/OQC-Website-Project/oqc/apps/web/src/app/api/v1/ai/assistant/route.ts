import { api } from "@/lib/platform/http";
import { aiFallback } from "@/lib/ai/guardrails";
export function POST() {
  return api(async (requestId) =>
    Response.json(
      { ...aiFallback, error: { ...aiFallback.error, requestId } },
      { status: 503 },
    ),
  );
}
