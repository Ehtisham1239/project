import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { recordPayment } from "@/server/services/finance";
import { listRecords } from "@/server/services/admin";
export function GET() {
  return api(async () => {
    const session = await requirePermission("payments:read");
    return Response.json(await listRecords("payments", 1, 20, session.userId));
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "payments:create");
    const body = await parseBody(
      request,
      z
        .object({
          invoiceId: z.uuid(),
          amountMinor: z.number().int().min(1).max(2147483647),
          method: z.enum(["BANK", "CARD_EXTERNAL", "CASH", "OTHER"]),
          reference: z.string().max(150).optional(),
          receivedAt: z.iso.datetime().transform((x) => new Date(x)),
        })
        .strict(),
    );
    return Response.json(
      { data: await recordPayment(body, session.userId) },
      { status: 201 },
    );
  });
}
