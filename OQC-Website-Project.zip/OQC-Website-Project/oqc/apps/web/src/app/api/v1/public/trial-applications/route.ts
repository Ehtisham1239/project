import { clientAddress } from "@/lib/platform/client-ip";
import { api, parseBody } from "@/lib/platform/http";
import { trialSchema } from "@/lib/validation/admissions";
import { requireOrigin } from "@/lib/auth/session";
import { privateHash } from "@/lib/auth/crypto";
import { AppError } from "@/lib/platform/errors";
import { submitTrial } from "@/server/services/admissions";
export function POST(request: Request) {
  return api(async () => {
    requireOrigin(request);
    const key = request.headers.get("idempotency-key");
    if (!key || !/^[-a-zA-Z0-9_]{16,100}$/.test(key))
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "A valid submission key is required.",
      );
    const input = await parseBody(request, trialSchema);
    const ip = privateHash(clientAddress(request));
    return Response.json(
      { data: await submitTrial(input, key, ip) },
      { status: 201 },
    );
  });
}
