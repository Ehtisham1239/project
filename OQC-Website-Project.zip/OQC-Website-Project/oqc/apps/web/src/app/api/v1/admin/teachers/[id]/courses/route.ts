import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { replaceTeacherCourses } from "@/server/services/academics";
export function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "teachers:update");
    const body = await parseBody(
      request,
      z
        .object({
          courseIds: z
            .array(z.uuid())
            .max(100)
            .refine((x) => new Set(x).size === x.length),
          version: z.number().int().positive(),
        })
        .strict(),
    );
    return Response.json({
      data: await replaceTeacherCourses(
        z.uuid().parse((await params).id),
        body.courseIds,
        body.version,
        session.userId,
      ),
    });
  });
}
