import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { timezone } from "@/lib/validation/common";
import { replaceTeacherAvailability } from "@/server/services/academics";
export function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "teachers:availability");
    const body = await parseBody(
      request,
      z
        .object({
          version: z.number().int().positive(),
          slots: z
            .array(
              z
                .object({
                  weekday: z.number().int().min(1).max(7),
                  startMinute: z.number().int().min(0).max(1439),
                  endMinute: z.number().int().min(1).max(1440),
                  timezone,
                })
                .strict()
                .refine(
                  (slot) => slot.endMinute > slot.startMinute,
                  "End time must follow start time",
                ),
            )
            .max(21),
        })
        .strict(),
    );
    return Response.json({
      data: await replaceTeacherAvailability(
        z.uuid().parse((await params).id),
        body.slots,
        body.version,
        session.userId,
      ),
    });
  });
}
