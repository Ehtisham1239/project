import { currencySchema } from "@/lib/validation/common";
import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { issueInvoice } from "@/server/services/finance";
import { listRecords } from "@/server/services/admin";
export function GET() {
  return api(async () => {
    const session = await requirePermission("invoices:read");
    return Response.json(await listRecords("invoices", 1, 20, session.userId));
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "invoices:create");
    const body = await parseBody(
      request,
      z
        .object({
          enrollmentId: z.uuid(),
          currency: currencySchema,
          totalMinor: z.number().int().min(1).max(2147483647),
          dueAt: z.iso.datetime().transform((x) => new Date(x)),
        })
        .strict(),
    );
    return Response.json(
      { data: await issueInvoice(body, session.userId) },
      { status: 201 },
    );
  });
}
