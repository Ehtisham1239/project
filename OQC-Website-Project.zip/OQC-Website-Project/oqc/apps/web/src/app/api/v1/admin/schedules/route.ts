import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { timezone, paginationSchema } from "@/lib/validation/common";
import { createSchedule } from "@/server/services/academics";
import { listRecords } from "@/server/services/admin";
export function GET(request: Request) {
  return api(async () => {
    const session = await requirePermission("schedules:read");
    const q = paginationSchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    return Response.json(
      await listRecords("schedules", q.page, q.pageSize, session.userId),
    );
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "schedules:create");
    const body = await parseBody(
      request,
      z
        .object({
          enrollmentId: z.uuid(),
          weekday: z.number().int().min(1).max(7),
          startMinute: z.number().int().min(0).max(1439),
          durationMin: z.number().int().min(1).max(240),
          timezone,
          from: z.iso.date(),
          to: z.iso.date(),
        })
        .strict(),
    );
    return Response.json(
      { data: await createSchedule(body, session.userId) },
      { status: 201 },
    );
  });
}
