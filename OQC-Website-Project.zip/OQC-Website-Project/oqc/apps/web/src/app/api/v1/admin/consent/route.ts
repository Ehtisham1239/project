import { api, parseBody } from "@/lib/platform/http";
import {
  requirePermission,
  requireMutation,
  requireRecentAuth,
} from "@/lib/auth/session";
import { consentSchema } from "@/lib/validation/consent";
import { activeConsent, publishConsent } from "@/server/services/consent";
export function GET() {
  return api(async () => {
    await requirePermission("settings:read");
    return Response.json({ data: await activeConsent() });
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "settings:security");
    requireRecentAuth(session);
    return Response.json(
      {
        data: await publishConsent(
          await parseBody(request, consentSchema),
          session.userId,
        ),
      },
      { status: 201 },
    );
  });
}
