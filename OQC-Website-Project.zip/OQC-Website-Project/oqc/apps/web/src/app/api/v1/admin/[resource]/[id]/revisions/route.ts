import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { can } from "@/lib/rbac/policy";
import { AppError } from "@/lib/platform/errors";
import { restoreRevisionSchema } from "@/lib/validation/revision";
import {
  contentRevisions,
  restoreRevision,
  revisionResource,
} from "@/server/services/revisions";
type Context = { params: Promise<{ resource: string; id: string }> };
export function GET(request: Request, { params }: Context) {
  return api(async () => {
    const { resource, id } = await params;
    if (!revisionResource(resource))
      throw new AppError("NOT_FOUND", 404, "Content workflow not found.");
    await requirePermission(resource + ":read");
    return Response.json({
      data: await contentRevisions(resource, z.uuid().parse(id)),
    });
  });
}
export function POST(request: Request, { params }: Context) {
  return api(async () => {
    const { resource, id } = await params;
    if (!revisionResource(resource))
      throw new AppError("NOT_FOUND", 404, "Content workflow not found.");
    let actor;
    try {
      actor = await requireMutation(request, resource + ":update");
    } catch (error) {
      if (
        resource === "courses" &&
        error instanceof AppError &&
        error.status === 403
      )
        actor = await requireMutation(request, "courses:update-content");
      else throw error;
    }
    return Response.json({
      data: await restoreRevision(
        resource,
        z.uuid().parse(id),
        await parseBody(request, restoreRevisionSchema),
        actor.userId,
        can(actor.user.role.key, resource + ":update"),
      ),
    });
  });
}
