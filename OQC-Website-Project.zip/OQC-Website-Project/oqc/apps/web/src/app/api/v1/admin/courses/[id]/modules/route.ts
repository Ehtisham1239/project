import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation, currentSession } from "@/lib/auth/session";
import { can } from "@/lib/rbac/policy";
import { courseModulesSchema } from "@/lib/validation/course-modules";
import { replaceCourseModules } from "@/server/services/course-modules";
export function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const current = await currentSession();
    const session = await requireMutation(
      request,
      current && can(current.user.role.key, "courses:update")
        ? "courses:update"
        : "courses:update-content",
    );
    const body = await parseBody(request, courseModulesSchema, 120000);
    return Response.json({
      data: await replaceCourseModules(
        z.uuid().parse((await params).id),
        body,
        session.userId,
      ),
    });
  });
}
