import { attendanceSchema } from "@/lib/validation/attendance";
import { api, parseBody } from "@/lib/platform/http";
import { requirePermission, requireMutation } from "@/lib/auth/session";
import { markAttendance } from "@/server/services/academics";
import { listRecords } from "@/server/services/admin";
export function GET() {
  return api(async () => {
    const session = await requirePermission("attendance:read");
    return Response.json(
      await listRecords("attendance", 1, 20, session.userId),
    );
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "attendance:create");
    const body = await parseBody(request, attendanceSchema);
    return Response.json(
      { data: await markAttendance(body, session.userId) },
      { status: 201 },
    );
  });
}
