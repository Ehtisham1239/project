import { z } from "zod";
import { api } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { AppError } from "@/lib/platform/errors";
import { createPreviewLink } from "@/lib/content/preview-links";
import { getRecord } from "@/server/services/admin";
import { revisionResource } from "@/server/services/revisions";
export function POST(
  request: Request,
  { params }: { params: Promise<{ resource: string; id: string }> },
) {
  return api(async () => {
    const { resource, id } = await params;
    if (!revisionResource(resource))
      throw new AppError("NOT_FOUND", 404, "Preview workflow not found.");
    const actor = await requireMutation(request, resource + ":read"),
      record = await getRecord(resource, z.uuid().parse(id));
    return Response.json({
      data: {
        href: createPreviewLink(actor.id, resource, id, record.version!),
      },
    });
  });
}
