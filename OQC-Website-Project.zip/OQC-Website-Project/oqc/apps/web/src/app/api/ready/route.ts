import { ready } from "@/server/services/readiness";
export async function GET() {
  try {
    const result = await ready();
    return Response.json(
      { status: result ? "ready" : "unavailable" },
      { status: result ? 200 : 503, headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json(
      { status: "unavailable" },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
}
