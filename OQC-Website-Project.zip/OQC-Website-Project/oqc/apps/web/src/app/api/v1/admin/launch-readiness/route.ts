import { api } from "@/lib/platform/http";
import { requirePermission } from "@/lib/auth/session";
import { launchReadiness } from "@/server/services/content";
export function GET() {
  return api(async () => {
    await requirePermission("settings:read");
    return Response.json({ data: await launchReadiness() });
  });
}
