import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { assignTrial } from "@/server/services/academics";
export function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "trials:assign");
    const body = await parseBody(
      request,
      z
        .object({
          teacherId: z.uuid(),
          startsAtUtc: z.iso.datetime().transform((x) => new Date(x)),
          durationMin: z.number().int().min(1).max(240),
          version: z.number().int().positive(),
        })
        .strict(),
    );
    return Response.json({
      data: await assignTrial({
        id: (await params).id,
        ...body,
        actorId: session.userId,
      }),
    });
  });
}
