import { api, parseBody } from "@/lib/platform/http";
import { requireMutation, requirePermission } from "@/lib/auth/session";
import { paginationSchema } from "@/lib/validation/common";
import { enrollmentSchema } from "@/lib/validation/enrollment";
import { createEnrollment } from "@/server/services/enrollments";
import { listRecords } from "@/server/services/admin";
export function GET(request: Request) {
  return api(async () => {
    const session = await requirePermission("enrollments:read");
    const query = paginationSchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    return Response.json(
      await listRecords(
        "enrollments",
        query.page,
        query.pageSize,
        session.userId,
      ),
    );
  });
}
export function POST(request: Request) {
  return api(async () => {
    const session = await requireMutation(request, "enrollments:create");
    return Response.json(
      {
        data: await createEnrollment(
          await parseBody(request, enrollmentSchema),
          session.userId,
        ),
      },
      { status: 201 },
    );
  });
}
