import { z } from "zod";
import { api, parseBody } from "@/lib/platform/http";
import { requireMutation } from "@/lib/auth/session";
import { contactWorkflowSchema } from "@/lib/validation/contact-workflow";
import { updateContactWorkflow } from "@/server/services/contact-workflow";
export function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  return api(async () => {
    const session = await requireMutation(request, "contact-messages:update");
    return Response.json({
      data: await updateContactWorkflow(
        z.uuid().parse((await params).id),
        await parseBody(request, contactWorkflowSchema),
        session.userId,
      ),
    });
  });
}
