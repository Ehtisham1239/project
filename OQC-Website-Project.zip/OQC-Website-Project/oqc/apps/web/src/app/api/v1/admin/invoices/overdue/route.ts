import { api } from "@/lib/platform/http";
import { requirePermission } from "@/lib/auth/session";
import { overdueInvoices } from "@/server/services/finance";
export function GET() {
  return api(async () => {
    await requirePermission("invoices:read");
    return Response.json(await overdueInvoices());
  });
}
