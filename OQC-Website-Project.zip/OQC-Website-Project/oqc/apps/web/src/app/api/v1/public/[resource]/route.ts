import { publicCatalogQuery as querySchema } from "@/lib/validation/public-catalog";
import { api } from "@/lib/platform/http";
import { publicCatalog, publicSettings } from "@/server/services/public";
import { AppError } from "@/lib/platform/errors";
export function GET(
  request: Request,
  { params }: { params: Promise<{ resource: string }> },
) {
  return api(async () => {
    const { resource } = await params;
    const query = querySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    if (resource === "site") {
      const items = await publicSettings();
      return Response.json({
        data: items.slice(
          (query.page - 1) * query.pageSize,
          query.page * query.pageSize,
        ),
        meta: {
          page: query.page,
          pageSize: query.pageSize,
          total: items.length,
        },
      });
    }
    if (
      ![
        "courses",
        "teachers",
        "faqs",
        "testimonials",
        "blog",
        "pricing",
      ].includes(resource)
    )
      throw new AppError("NOT_FOUND", 404, "Resource not found.");
    return Response.json(await publicCatalog(resource, query));
  });
}
