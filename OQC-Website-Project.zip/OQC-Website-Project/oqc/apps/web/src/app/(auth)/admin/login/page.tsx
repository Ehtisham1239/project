import { LoginForm } from "@/components/admin/login-form";
export default function Login() {
  return (
    <main className="container page-title" style={{ maxWidth: 600 }}>
      <span className="eyebrow">Online Quran College LTD · Staff</span>
      <h1>Welcome back.</h1>
      <p>Sign in with your staff account. Privileged accounts require MFA.</p>
      <LoginForm />
    </main>
  );
}
