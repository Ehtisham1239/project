import { MfaSetup } from "@/components/admin/mfa-setup";
export default function Setup() {
  return (
    <main className="container page-title" style={{ maxWidth: 600 }}>
      <h1>Secure your staff account.</h1>
      <MfaSetup />
    </main>
  );
}
