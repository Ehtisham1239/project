import type { MetadataRoute } from "next";
import { publicIndexingAllowed } from "@/lib/platform/indexing";
export default async function robots(): Promise<MetadataRoute.Robots> {
  const approved = await publicIndexingAllowed();
  if (!approved) return { rules: { userAgent: "*", disallow: "/" } };
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/admin", "/api"] },
    sitemap: (process.env.APP_URL ?? "") + "/sitemap.xml",
  };
}
