import { database } from "@/lib/db";
import { AppError } from "@/lib/platform/errors";
import { newId } from "@/lib/platform/ids";
import { withinAvailability } from "@/lib/platform/time";
import { Prisma } from "@/generated/prisma/client";
import type { z } from "zod";
import type {
  rescheduleSchema,
  sessionStatusSchema,
} from "@/lib/validation/class-session";

export function approvedMeetingUrl(value: string | null, domains: unknown) {
  if (value === null) return null;
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Enter a valid approved HTTPS meeting URL.",
    );
  }
  if (
    url.protocol !== "https:" ||
    url.username ||
    url.password ||
    (url.port && url.port !== "443") ||
    !Array.isArray(domains) ||
    !domains.includes(url.hostname)
  )
    throw new AppError(
      "MEETING_HOST_UNAPPROVED",
      400,
      "Use HTTPS and an exact meeting hostname approved in Settings.",
    );
  return url.href;
}

export async function rescheduleSession(
  id: string,
  input: z.infer<typeof rescheduleSchema>,
  actorId: string,
) {
  try {
    return await database().$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"session:" + id},0))`;
      const current = await tx.classSession.findUnique({
        where: { id },
        include: { schedule: { include: { enrollment: true } } },
      });
      if (!current) throw new AppError("NOT_FOUND", 404, "Class not found.");
      if (
        current.version !== input.version ||
        !["PLANNED", "RESCHEDULED"].includes(current.status)
      )
        throw new AppError(
          "CONFLICT",
          409,
          "Refresh this class; only planned classes can be rescheduled.",
        );
      if (
        !current.schedule ||
        current.schedule.deletedAt ||
        current.schedule.enrollment.deletedAt ||
        current.schedule.enrollment.status !== "ACTIVE" ||
        !current.studentId
      )
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Use trial assignment for trial classes; regular classes require an active enrollment.",
        );
      for (const key of [current.teacherId, current.studentId].sort())
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${key},0))`;
      const teacher = await tx.teacher.findFirst({
        where: {
          id: current.teacherId,
          isActive: true,
          deletedAt: null,
          teacherCourse_teacherId: {
            some: { courseId: current.schedule.enrollment.courseId },
          },
        },
      });
      const student = await tx.student.findFirst({
        where: { id: current.studentId, status: "ACTIVE", deletedAt: null },
      });
      if (!teacher || !student)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "This class requires an active learner and assigned course teacher.",
        );
      const startsAtUtc = new Date(input.startsAtUtc),
        endsAtUtc = new Date(startsAtUtc.getTime() + input.durationMin * 60000);
      if (!Number.isFinite(startsAtUtc.getTime()) || startsAtUtc <= new Date())
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Choose a future class time.",
        );
      const availability = await tx.teacherAvailability.findMany({
        where: { teacherId: current.teacherId },
      });
      if (!withinAvailability(startsAtUtc, endsAtUtc, availability))
        throw new AppError(
          "TEACHER_UNAVAILABLE",
          409,
          "Choose a time within the teacher’s recorded weekly availability.",
        );
      if (await tx.attendance.count({ where: { sessionId: id } }))
        throw new AppError(
          "CONFLICT",
          409,
          "A class with recorded attendance cannot be rescheduled.",
        );
      const setting = await tx.setting.findUnique({
        where: { key: "scheduling.meetingDomains" },
      });
      const meetingUrl = approvedMeetingUrl(
        input.meetingUrl === undefined ? current.meetingUrl : input.meetingUrl,
        setting?.value,
      );
      const result = await tx.classSession.update({
        where: { id },
        data: {
          startsAtUtc,
          endsAtUtc,
          meetingUrl,
          status: "RESCHEDULED",
          version: { increment: 1 },
        },
        select: { id: true, version: true },
      });
      await tx.auditLog.create({
        data: {
          id: newId(),
          actorId,
          action: "session.rescheduled",
          entityType: "ClassSession",
          entityId: id,
          before: {
            startsAtUtc: current.startsAtUtc.toISOString(),
            endsAtUtc: current.endsAtUtc.toISOString(),
            status: current.status,
          },
          after: {
            startsAtUtc: startsAtUtc.toISOString(),
            endsAtUtc: endsAtUtc.toISOString(),
            status: "RESCHEDULED",
          },
        },
      });
      await tx.outboxEvent.create({
        data: { id: newId(), kind: "session.rescheduled", payload: { id } },
      });
      return result;
    });
  } catch (error) {
    if (
      (error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002") ||
      (error instanceof Error && /exclusion|overlap|23P01/.test(error.message))
    )
      throw new AppError(
        "SCHEDULE_OVERLAP",
        409,
        "The teacher or learner already has a class at this time. Choose another time.",
      );
    throw error;
  }
}

export async function changeSessionStatus(
  id: string,
  input: z.infer<typeof sessionStatusSchema>,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"session:" + id},0))`;
    const current = await tx.classSession.findUnique({ where: { id } });
    if (!current) throw new AppError("NOT_FOUND", 404, "Class not found.");
    if (
      current.kind !== "REGULAR" ||
      current.version !== input.version ||
      !["PLANNED", "RESCHEDULED"].includes(current.status)
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this class; only planned regular classes can change status.",
      );
    if (input.status === "HELD" && current.endsAtUtc > new Date())
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "A class can be marked held after its end time.",
      );
    if (
      input.status === "CANCELLED" &&
      (await tx.attendance.count({ where: { sessionId: id } }))
    )
      throw new AppError(
        "CONFLICT",
        409,
        "A class with recorded attendance cannot be cancelled.",
      );
    const result = await tx.classSession.update({
      where: { id },
      data: { status: input.status, version: { increment: 1 } },
      select: { id: true, version: true },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "session.status_changed",
        entityType: "ClassSession",
        entityId: id,
        before: { status: current.status },
        after: { status: input.status },
      },
    });
    await tx.outboxEvent.create({
      data: { id: newId(), kind: "session.status_changed", payload: { id } },
    });
    return result;
  });
}
