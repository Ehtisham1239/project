import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { can } from "@/lib/rbac/policy";
import type { Prisma } from "@/generated/prisma/client";
type Event = { id: string; kind: string; payload: Prisma.JsonValue };
const permissions: Record<string, string> = {
  "invoice.voided": "invoices:read",
  "session.rescheduled": "sessions:read",
  "session.status_changed": "sessions:read",
  "enrollment.created": "enrollments:read",
  "trial.submitted": "trials:read",
  "trial.status_changed": "trials:read",
  "contact.received": "contact-messages:read",
  "content.published": "pages:publish",
  "content.unpublished": "pages:publish",
  "invoice.issued": "invoices:read",
  "payment.recorded": "payments:read",
};
export async function processNextOutbox() {
  return database().$transaction(async (tx) => {
    const [event] = await tx.$queryRaw<
      Event[]
    >`SELECT id,kind,payload FROM "OutboxEvent" WHERE "processedAt" IS NULL AND attempts < 5 ORDER BY "createdAt",id FOR UPDATE SKIP LOCKED LIMIT 1`;
    if (!event) return false;
    const permission = permissions[event.kind];
    if (!permission) {
      await tx.outboxEvent.update({
        where: { id: event.id },
        data: { attempts: { increment: 1 }, errorCode: "UNSUPPORTED_EVENT" },
      });
      return true;
    }
    const payload =
      event.payload &&
      typeof event.payload === "object" &&
      !Array.isArray(event.payload)
        ? event.payload
        : {};
    const entityId = ["trialId", "contactId", "invoiceId", "paymentId", "id"]
      .map((key) => payload[key])
      .find((value) => typeof value === "string");
    const users = await tx.user.findMany({
      where: { isActive: true, deletedAt: null, mustEnrollMfa: false },
      select: { id: true, role: { select: { key: true } } },
    });
    await tx.notification.createMany({
      data: users
        .filter((user) => can(user.role.key, permission))
        .map((user) => ({
          id: newId(),
          userId: user.id,
          kind: event.kind,
          entityId: typeof entityId === "string" ? entityId : null,
        })),
    });
    await tx.outboxEvent.update({
      where: { id: event.id },
      data: {
        processedAt: new Date(),
        attempts: { increment: 1 },
        errorCode: null,
      },
    });
    return true;
  });
}
export async function drainOutbox(limit = 50) {
  let processed = 0;
  for (let i = 0; i < limit; i++) {
    if (!(await processNextOutbox())) break;
    processed++;
  }
  return { processed };
}
export async function markNotificationRead(id: string, userId: string) {
  await database().notification.updateMany({
    where: { id, userId, readAt: null },
    data: { readAt: new Date() },
  });
  return { read: true };
}
export async function staffNotifications(userId: string) {
  return database().notification.findMany({
    where: { userId },
    select: {
      id: true,
      kind: true,
      entityId: true,
      createdAt: true,
      readAt: true,
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
}
