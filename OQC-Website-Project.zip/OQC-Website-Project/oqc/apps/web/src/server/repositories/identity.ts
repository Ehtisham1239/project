import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import {
  hashToken,
  randomToken,
  safeEqual,
  sessionCsrf,
} from "@/lib/auth/crypto";
import { AppError } from "@/lib/platform/errors";
export async function sessionByToken(token: string) {
  const session = await database().session.findUnique({
    where: { tokenHash: hashToken(token) },
    include: { user: { include: { role: true } } },
  });
  const now = new Date();
  if (
    !session ||
    session.expiresAt <= now ||
    now.getTime() - session.lastSeenAt.getTime() > 30 * 60 * 1000 ||
    !session.user.isActive ||
    session.user.deletedAt ||
    session.user.mustEnrollMfa
  )
    return null;
  if (
    ["SUPER_ADMIN", "ADMIN"].includes(session.user.role.key) &&
    !session.user.mfaEnabled
  )
    return null;
  await database().session.updateMany({
    where: { id: session.id, lastSeenAt: session.lastSeenAt },
    data: { lastSeenAt: now },
  });
  return session;
}
export async function createSession(userId: string) {
  const token = randomToken(),
    csrf = sessionCsrf(token),
    now = new Date();
  await database().session.create({
    data: {
      id: newId(),
      userId,
      tokenHash: hashToken(token),
      csrfHash: hashToken(csrf),
      lastSeenAt: now,
      reauthenticatedAt: now,
      expiresAt: new Date(now.getTime() + 12 * 60 * 60 * 1000),
    },
  });
  return { token, csrf };
}
export async function validateCsrf(token: string, value: string) {
  const session = await database().session.findUnique({
    where: { tokenHash: hashToken(token) },
  });
  if (!session || !safeEqual(session.csrfHash, hashToken(value)))
    throw new AppError("FORBIDDEN", 403, "Refresh this page and try again.");
}
export async function revokeSession(token: string) {
  await database().$transaction(async (tx) => {
    const session = await tx.session.findUnique({
      where: { tokenHash: hashToken(token) },
    });
    if (!session) return;
    await tx.session.delete({ where: { id: session.id } });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId: session.userId,
        action: "identity.logout",
        entityType: "Session",
        entityId: session.id,
      },
    });
  });
}
