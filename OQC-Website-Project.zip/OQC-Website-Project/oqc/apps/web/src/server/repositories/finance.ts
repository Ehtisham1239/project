import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
export async function issueInvoice(
  data: {
    enrollmentId: string;
    currency: string;
    totalMinor: number;
    dueAt: Date;
  },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    const enrollment = await tx.enrollment.findFirst({
      where: { id: data.enrollmentId, deletedAt: null },
    });
    if (!enrollment)
      throw new AppError("VALIDATION_ERROR", 400, "Enrollment not found.");
    const sequence = await tx.$queryRaw<
      { number: bigint }[]
    >`SELECT nextval('invoice_number_seq') AS number`;
    const number = `OQC-INV-${new Date().getUTCFullYear()}-${String(sequence[0].number).padStart(6, "0")}`;
    const invoice = await tx.invoice.create({
      data: {
        id: newId(),
        ...data,
        number,
        status: "ISSUED",
        issuedAt: new Date(),
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "invoice.issued",
        entityType: "Invoice",
        entityId: invoice.id,
        after: { currency: data.currency, totalMinor: data.totalMinor },
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "invoice.issued",
        payload: { invoiceId: invoice.id },
      },
    });
    return invoice;
  });
}
export async function recordPayment(
  data: {
    invoiceId: string;
    amountMinor: number;
    method: "BANK" | "CARD_EXTERNAL" | "CASH" | "OTHER";
    reference?: string;
    receivedAt: Date;
  },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${data.invoiceId},0))`;
    const invoice = await tx.invoice.findFirst({
      where: { id: data.invoiceId, deletedAt: null },
    });
    if (!invoice || invoice.status !== "ISSUED")
      throw new AppError(
        "CONFLICT",
        409,
        "Only issued unpaid invoices accept payment records.",
      );
    const sum = await tx.paymentRecord.aggregate({
      where: { invoiceId: data.invoiceId, deletedAt: null },
      _sum: { amountMinor: true },
    });
    const paid = (sum._sum.amountMinor ?? 0) + data.amountMinor;
    if (paid > invoice.totalMinor)
      throw new AppError(
        "CONFLICT",
        409,
        "This payment would exceed the invoice total.",
      );
    const payment = await tx.paymentRecord.create({
      data: { id: newId(), ...data, recordedById: actorId },
    });
    await tx.invoice.update({
      where: { id: invoice.id },
      data: {
        status: paid === invoice.totalMinor ? "PAID" : "ISSUED",
        version: { increment: 1 },
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "payment.recorded",
        entityType: "PaymentRecord",
        entityId: payment.id,
        after: { currency: invoice.currency, amountMinor: data.amountMinor },
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "payment.recorded",
        payload: { paymentId: payment.id },
      },
    });
    return {
      id: payment.id,
      invoiceStatus: paid === invoice.totalMinor ? "PAID" : "ISSUED",
    };
  });
}
export async function unpaidInvoices() {
  return database().invoice.findMany({
    where: { status: "ISSUED", deletedAt: null },
    select: {
      id: true,
      number: true,
      currency: true,
      totalMinor: true,
      enrollment: { select: { student: { select: { fullName: true } } } },
      paymentRecord_invoiceId: {
        where: { deletedAt: null },
        select: { amountMinor: true },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
}
export async function voidInvoice(
  id: string,
  input: { version: number; reason: string },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const invoice = await tx.invoice.findFirst({
      where: { id, deletedAt: null },
    });
    if (!invoice) throw new AppError("NOT_FOUND", 404, "Invoice not found.");
    if (
      invoice.version !== input.version ||
      !["DRAFT", "ISSUED"].includes(invoice.status)
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this invoice; only unpaid draft or issued invoices can be voided.",
      );
    if (await tx.paymentRecord.count({ where: { invoiceId: id } }))
      throw new AppError(
        "CONFLICT",
        409,
        "An invoice with recorded payments cannot be voided. Keep its financial history intact.",
      );
    const result = await tx.invoice.update({
      where: { id },
      data: { status: "VOID", version: { increment: 1 } },
      select: { id: true, version: true },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "invoice.voided",
        entityType: "Invoice",
        entityId: id,
        before: { status: invoice.status },
        after: { status: "VOID", reason: input.reason },
      },
    });
    await tx.outboxEvent.create({
      data: { id: newId(), kind: "invoice.voided", payload: { invoiceId: id } },
    });
    return result;
  });
}
export async function overdueInvoices() {
  const asOf = new Date();
  const records = await database().invoice.findMany({
    where: { status: "ISSUED", deletedAt: null, dueAt: { lt: asOf } },
    take: 201,
    orderBy: [{ dueAt: "asc" }, { id: "asc" }],
    select: {
      id: true,
      number: true,
      currency: true,
      totalMinor: true,
      dueAt: true,
      enrollment: { select: { student: { select: { fullName: true } } } },
      paymentRecord_invoiceId: {
        where: { deletedAt: null },
        select: { amountMinor: true },
      },
    },
  });
  return {
    asOf: asOf.toISOString(),
    truncated: records.length > 200,
    data: records
      .slice(0, 200)
      .map((record) => ({
        id: record.id,
        number: record.number,
        currency: record.currency,
        dueAt: record.dueAt!.toISOString(),
        learner: record.enrollment.student.fullName,
        balanceMinor:
          record.totalMinor -
          record.paymentRecord_invoiceId.reduce(
            (total, payment) => total + payment.amountMinor,
            0,
          ),
      })),
  };
}
