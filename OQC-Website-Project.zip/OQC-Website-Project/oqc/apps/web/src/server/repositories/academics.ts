import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { expandWeekly, withinAvailability } from "@/lib/platform/time";
function translateOverlap(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (/exclusion|overlap|23P01/.test(message))
    throw new AppError(
      "SCHEDULE_OVERLAP",
      409,
      "The teacher or learner already has a class at this time. Choose another time.",
    );
  throw error;
}
export async function assignTrial({
  id,
  teacherId,
  startsAtUtc,
  durationMin,
  version,
  actorId,
}: {
  id: string;
  teacherId: string;
  startsAtUtc: Date;
  durationMin: number;
  version: number;
  actorId: string;
}) {
  try {
    return await database().$transaction(async (tx) => {
      for (const lockId of [id, teacherId].sort())
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${lockId},0))`;
      const trial = await tx.trialApplication.findFirst({
        where: { id, deletedAt: null },
      });
      if (!trial) throw new AppError("NOT_FOUND", 404, "Trial not found.");
      if (
        !["NEW", "REVIEWED"].includes(trial.status) ||
        trial.version !== version
      )
        throw new AppError(
          "CONFLICT",
          409,
          "Refresh this application before assigning a class.",
        );
      const teacher = await tx.teacher.findFirst({
        where: {
          id: teacherId,
          isActive: true,
          deletedAt: null,
          teacherCourse_teacherId: { some: { courseId: trial.courseId } },
        },
      });
      if (!teacher)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Choose an active teacher assigned to this course.",
        );
      const endsAtUtc = new Date(startsAtUtc.getTime() + durationMin * 60000);
      const availability = await tx.teacherAvailability.findMany({
        where: { teacherId },
      });
      if (!withinAvailability(startsAtUtc, endsAtUtc, availability))
        throw new AppError(
          "TEACHER_UNAVAILABLE",
          409,
          "Choose a time within the teacher’s recorded weekly availability.",
        );
      if (
        await tx.classSession.count({
          where: {
            teacherId,
            status: { not: "CANCELLED" },
            startsAtUtc: { lt: endsAtUtc },
            endsAtUtc: { gt: startsAtUtc },
          },
        })
      )
        throw new AppError(
          "SCHEDULE_OVERLAP",
          409,
          "The teacher is already booked at this time.",
        );
      await tx.classSession.create({
        data: {
          id: newId(),
          trialId: id,
          teacherId,
          kind: "TRIAL",
          startsAtUtc,
          endsAtUtc,
        },
      });
      await tx.trialApplication.update({
        where: { id },
        data: {
          assignedTeacherId: teacherId,
          trialSessionAtUtc: startsAtUtc,
          version: { increment: 1 },
        },
      });
      await tx.auditLog.create({
        data: {
          id: newId(),
          actorId,
          action: "trial.teacher_assigned",
          entityType: "TrialApplication",
          entityId: id,
          after: { teacherId, startsAtUtc: startsAtUtc.toISOString() },
        },
      });
      return { id, version: version + 1 };
    });
  } catch (error) {
    translateOverlap(error);
  }
}
export async function convertTrial(
  id: string,
  version: number,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const trial = await tx.trialApplication.findFirst({
      where: { id, deletedAt: null },
    });
    if (!trial) throw new AppError("NOT_FOUND", 404, "Application not found.");
    if (
      trial.version !== version ||
      trial.status !== "COMPLETED" ||
      !trial.assignedTeacherId
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Complete the trial and assign a teacher before enrolling.",
      );
    const student = await tx.student.create({
      data: {
        id: newId(),
        fullName: trial.learnerName,
        ageBand: trial.ageBand,
        country: trial.country,
        timezone: trial.timezone,
        createdFromTrialId: id,
      },
    });
    if (trial.ageBand !== "18_PLUS") {
      if (!trial.guardianName)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Guardian details are required.",
        );
      const guardian = await tx.guardian.create({
        data: {
          id: newId(),
          fullName: trial.guardianName,
          email: trial.email,
          phone: trial.phoneE164,
          relationship: "GUARDIAN",
          country: trial.country,
        },
      });
      await tx.studentGuardian.create({
        data: {
          id: newId(),
          studentId: student.id,
          guardianId: guardian.id,
          isPrimary: true,
        },
      });
    }
    const enrollment = await tx.enrollment.create({
      data: {
        id: newId(),
        studentId: student.id,
        courseId: trial.courseId,
        teacherId: trial.assignedTeacherId,
        startDate: new Date(),
      },
    });
    await tx.trialApplication.update({
      where: { id },
      data: { status: "ENROLLED", version: { increment: 1 } },
    });
    await tx.trialHistory.create({
      data: {
        id: newId(),
        trialId: id,
        fromStatus: "COMPLETED",
        toStatus: "ENROLLED",
        actorId,
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "trial.converted",
        entityType: "TrialApplication",
        entityId: id,
        after: { studentId: student.id, enrollmentId: enrollment.id },
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "trial.status_changed",
        payload: { trialId: id, status: "ENROLLED" },
      },
    });
    return { studentId: student.id, enrollmentId: enrollment.id };
  });
}
export async function createSchedule(
  data: {
    enrollmentId: string;
    weekday: number;
    startMinute: number;
    durationMin: number;
    timezone: string;
    from: string;
    to: string;
  },
  actorId: string,
) {
  const occurrences = expandWeekly(data);
  if (!occurrences.length)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "There are no class dates in this range.",
    );
  try {
    return await database().$transaction(async (tx) => {
      const enrollment = await tx.enrollment.findFirst({
        where: { id: data.enrollmentId, status: "ACTIVE", deletedAt: null },
      });
      if (!enrollment)
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Select an active enrollment.",
        );
      for (const key of [enrollment.teacherId, enrollment.studentId].sort())
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${key},0))`;
      const availability = await tx.teacherAvailability.findMany({
        where: { teacherId: enrollment.teacherId },
      });
      if (
        occurrences.some(
          (times) =>
            !withinAvailability(
              times.startsAtUtc,
              times.endsAtUtc,
              availability,
            ),
        )
      )
        throw new AppError(
          "TEACHER_UNAVAILABLE",
          409,
          "Some class dates are outside the teacher’s recorded weekly availability.",
        );
      const schedule = await tx.classSchedule.create({
        data: {
          id: newId(),
          enrollmentId: enrollment.id,
          teacherId: enrollment.teacherId,
          weekday: data.weekday,
          startMinute: data.startMinute,
          durationMin: data.durationMin,
          timezone: data.timezone,
          effectiveFrom: new Date(data.from),
          effectiveTo: new Date(data.to),
        },
      });
      await tx.classSession.createMany({
        data: occurrences.map((times) => ({
          id: newId(),
          scheduleId: schedule.id,
          teacherId: enrollment.teacherId,
          studentId: enrollment.studentId,
          ...times,
        })),
      });
      await tx.auditLog.create({
        data: {
          id: newId(),
          actorId,
          action: "schedule.created",
          entityType: "ClassSchedule",
          entityId: schedule.id,
          after: { sessionCount: occurrences.length },
        },
      });
      return { id: schedule.id, sessionCount: occurrences.length };
    });
  } catch (error) {
    translateOverlap(error);
  }
}
export async function markAttendance(
  data: {
    sessionId: string;
    enrollmentId: string;
    status: "PRESENT" | "ABSENT" | "LATE" | "EXCUSED";
    note?: string;
    sessionVersion?: number;
    expectedUpdatedAt?: string | null;
  },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"session:" + data.sessionId},0))`;
    const session = await tx.classSession.findUnique({
        where: { id: data.sessionId },
        include: { schedule: true },
      }),
      enrollment = await tx.enrollment.findUnique({
        where: { id: data.enrollmentId },
      });
    if (
      !session ||
      !enrollment ||
      enrollment.deletedAt !== null ||
      !session.schedule ||
      session.schedule.deletedAt !== null ||
      session.schedule.enrollmentId !== enrollment.id ||
      session.studentId !== enrollment.studentId ||
      session.teacherId !== enrollment.teacherId ||
      session.status === "CANCELLED"
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "This learner is not assigned to this class.",
      );
    const previous = await tx.attendance.findUnique({
      where: {
        sessionId_enrollmentId: {
          sessionId: data.sessionId,
          enrollmentId: data.enrollmentId,
        },
      },
    });
    if (
      (data.sessionVersion !== undefined &&
        session.version !== data.sessionVersion) ||
      (data.expectedUpdatedAt !== undefined &&
        (previous?.updatedAt.toISOString() ?? null) !== data.expectedUpdatedAt)
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Attendance or the class changed. Refresh before saving.",
      );
    const updatedAt = new Date(
      Math.max(Date.now(), (previous?.updatedAt.getTime() ?? 0) + 1),
    );
    const record = await tx.attendance.upsert({
      where: {
        sessionId_enrollmentId: {
          sessionId: data.sessionId,
          enrollmentId: data.enrollmentId,
        },
      },
      create: {
        id: newId(),
        sessionId: data.sessionId,
        enrollmentId: data.enrollmentId,
        status: data.status,
        note: data.note || null,
        updatedAt,
      },
      update: { status: data.status, note: data.note || null, updatedAt },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "attendance.marked",
        entityType: "Attendance",
        entityId: record.id,
        before: previous ? { status: previous.status } : undefined,
        after: { status: data.status },
      },
    });
    return { id: record.id };
  });
}
export async function sessionAttendance(id: string) {
  const session = await database().classSession.findUnique({
    where: { id },
    select: {
      id: true,
      version: true,
      status: true,
      startsAtUtc: true,
      endsAtUtc: true,
      student: { select: { fullName: true, timezone: true } },
      teacher: {
        select: {
          displayName: true,
          teacherAvailability_teacherId: {
            select: { timezone: true },
            take: 1,
          },
        },
      },
      schedule: {
        select: {
          deletedAt: true,
          enrollment: {
            select: {
              id: true,
              deletedAt: true,
              course: { select: { title: true } },
            },
          },
        },
      },
      attendance_sessionId: {
        select: {
          enrollmentId: true,
          status: true,
          note: true,
          updatedAt: true,
        },
      },
    },
  });
  if (!session) throw new AppError("NOT_FOUND", 404, "Class not found.");
  if (
    !session.schedule ||
    session.schedule.deletedAt ||
    session.schedule.enrollment.deletedAt ||
    !session.student
  )
    return null;
  const attendance = session.attendance_sessionId.find(
    (item) => item.enrollmentId === session.schedule!.enrollment.id,
  );
  return {
    sessionId: session.id,
    sessionVersion: session.version,
    enrollmentId: session.schedule.enrollment.id,
    student: session.student,
    teacher: {
      displayName: session.teacher.displayName,
      timezone:
        session.teacher.teacherAvailability_teacherId[0]?.timezone ?? "UTC",
    },
    course: session.schedule.enrollment.course.title,
    startsAtUtc: session.startsAtUtc.toISOString(),
    endsAtUtc: session.endsAtUtc.toISOString(),
    cancelled: session.status === "CANCELLED",
    canMarkHeld: session.endsAtUtc.getTime() <= Date.now(),
    attendance: attendance
      ? {
          status: attendance.status,
          note: attendance.note,
          updatedAt: attendance.updatedAt.toISOString(),
        }
      : null,
  };
}
export async function trialWorkspace(id: string) {
  const trial = await database().trialApplication.findFirst({
    where: { id, deletedAt: null },
  });
  if (!trial) throw new AppError("NOT_FOUND", 404, "Trial not found.");
  const [teachers, notes] = await Promise.all([
    database().teacher.findMany({
      where: {
        isActive: true,
        deletedAt: null,
        teacherCourse_teacherId: { some: { courseId: trial.courseId } },
      },
      select: { id: true, displayName: true },
      orderBy: { displayName: "asc" },
    }),
    database().trialNote.findMany({
      where: { trialId: id },
      select: {
        id: true,
        body: true,
        createdAt: true,
        author: { select: { name: true } },
      },
      orderBy: { createdAt: "desc" },
    }),
  ]);
  return { teachers, notes };
}
export async function addTrialNote(id: string, body: string, actorId: string) {
  return database().$transaction(async (tx) => {
    if (
      !(await tx.trialApplication.findFirst({ where: { id, deletedAt: null } }))
    )
      throw new AppError("NOT_FOUND", 404, "Trial not found.");
    const note = await tx.trialNote.create({
      data: { id: newId(), trialId: id, authorId: actorId, body },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "trial.note_added",
        entityType: "TrialNote",
        entityId: note.id,
      },
    });
    return { id: note.id };
  });
}
export async function teacherCourses(id: string) {
  const teacher = await database().teacher.findFirst({
    where: { id, deletedAt: null },
  });
  if (!teacher) throw new AppError("NOT_FOUND", 404, "Teacher not found.");
  const [courses, selected] = await Promise.all([
    database().course.findMany({
      where: { deletedAt: null },
      select: { id: true, title: true },
      orderBy: { title: "asc" },
    }),
    database().teacherCourse.findMany({
      where: { teacherId: id },
      select: { courseId: true },
    }),
  ]);
  return { courses, selected: selected.map((x) => x.courseId) };
}
export async function replaceTeacherCourses(
  id: string,
  courseIds: string[],
  version: number,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const teacher = await tx.teacher.findFirst({
      where: { id, deletedAt: null, version },
    });
    if (!teacher)
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this teacher before saving.",
      );
    if (
      (await tx.course.count({
        where: { id: { in: courseIds }, deletedAt: null },
      })) !== courseIds.length
    )
      throw new AppError("VALIDATION_ERROR", 400, "Select existing courses.");
    const removed = await tx.teacherCourse.findMany({
      where: { teacherId: id, courseId: { notIn: courseIds } },
    });
    for (const item of removed) {
      if (
        (await tx.enrollment.count({
          where: {
            teacherId: id,
            courseId: item.courseId,
            status: "ACTIVE",
            deletedAt: null,
          },
        })) ||
        (await tx.classSession.count({
          where: {
            teacherId: id,
            startsAtUtc: { gt: new Date() },
            status: { not: "CANCELLED" },
            trial: { courseId: item.courseId },
          },
        }))
      )
        throw new AppError(
          "CONFLICT",
          409,
          "Reassign active learners and future trial classes before removing this course.",
        );
    }
    await tx.teacherCourse.deleteMany({
      where: { teacherId: id, courseId: { notIn: courseIds } },
    });
    await tx.teacherCourse.createMany({
      data: courseIds.map((courseId) => ({
        id: newId(),
        teacherId: id,
        courseId,
      })),
      skipDuplicates: true,
    });
    const changed = await tx.teacher.updateMany({
      where: { id, version },
      data: { version: { increment: 1 } },
    });
    if (!changed.count)
      throw new AppError(
        "CONFLICT",
        409,
        "Teacher changed; refresh and try again.",
      );
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "teacher.courses_changed",
        entityType: "Teacher",
        entityId: id,
        after: { courseIds },
      },
    });
    return { id, version: version + 1 };
  });
}
export async function enrollmentOptions() {
  return database().enrollment.findMany({
    where: { status: "ACTIVE", deletedAt: null },
    select: {
      id: true,
      student: { select: { fullName: true, timezone: true } },
      course: { select: { title: true } },
      teacher: { select: { displayName: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
}
export async function recordProgress(
  data: {
    enrollmentId: string;
    summary: string;
    lessonRef?: string;
    level?: string;
  },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    if (
      !(await tx.enrollment.findFirst({
        where: { id: data.enrollmentId, deletedAt: null, status: "ACTIVE" },
      }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose an active enrollment.",
      );
    const item = await tx.progressRecord.create({
      data: { id: newId(), ...data, authorId: actorId },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "progress.recorded",
        entityType: "ProgressRecord",
        entityId: item.id,
      },
    });
    return { id: item.id };
  });
}
export async function teacherAvailability(id: string) {
  return database().teacherAvailability.findMany({
    where: { teacherId: id },
    select: {
      id: true,
      weekday: true,
      startMinute: true,
      endMinute: true,
      timezone: true,
    },
    orderBy: [{ weekday: "asc" }, { startMinute: "asc" }],
  });
}
export async function replaceTeacherAvailability(
  id: string,
  slots: {
    weekday: number;
    startMinute: number;
    endMinute: number;
    timezone: string;
  }[],
  version: number,
  actorId: string,
) {
  for (let i = 0; i < slots.length; i++)
    for (let j = i + 1; j < slots.length; j++)
      if (
        slots[i].weekday === slots[j].weekday &&
        slots[i].timezone === slots[j].timezone &&
        slots[i].startMinute < slots[j].endMinute &&
        slots[j].startMinute < slots[i].endMinute
      )
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Availability slots overlap.",
        );
  if (new Set(slots.map((slot) => slot.timezone)).size > 1)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Use one teacher time zone for all weekly availability.",
    );
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const teacher = await tx.teacher.findFirst({
      where: { id, version, deletedAt: null },
    });
    if (!teacher)
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this teacher before saving.",
      );
    await tx.teacherAvailability.deleteMany({ where: { teacherId: id } });
    await tx.teacherAvailability.createMany({
      data: slots.map((slot) => ({ id: newId(), teacherId: id, ...slot })),
    });
    const changed = await tx.teacher.updateMany({
      where: { id, version },
      data: { version: { increment: 1 } },
    });
    if (!changed.count)
      throw new AppError(
        "CONFLICT",
        409,
        "Teacher changed; refresh and try again.",
      );
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "teacher.availability_changed",
        entityType: "Teacher",
        entityId: id,
        after: { slotCount: slots.length },
      },
    });
    return { id, version: version + 1 };
  });
}
