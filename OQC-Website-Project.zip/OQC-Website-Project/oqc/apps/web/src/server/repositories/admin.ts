import { renderRichHtml } from "@/lib/validation/richtext";
import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { Prisma } from "@/generated/prisma/client";
type RecordData = Record<string, unknown> & {
  id: string;
  version?: number;
  status?: string;
  slug?: string;
  isPublic?: boolean;
  verificationNote?: string;
  consentRecordedAt?: Date | null;
  deletedAt?: Date | null;
};
type Delegate = {
  findMany: (args: unknown) => Promise<RecordData[]>;
  findFirst: (args: unknown) => Promise<RecordData | null>;
  count: (args: unknown) => Promise<number>;
  create: (args: unknown) => Promise<RecordData>;
  updateMany: (args: unknown) => Promise<{ count: number }>;
  delete: (args: unknown) => Promise<RecordData>;
};
const mapped = {
  media: "mediaAsset",
  blog: "blogPost",
  courses: "course",
  teachers: "teacher",
  faqs: "fAQ",
  testimonials: "testimonial",
  pages: "cMSPage",
  "pricing-plans": "pricingPlan",
  students: "student",
  guardians: "guardian",
  menus: "menuItem",
  trials: "trialApplication",
  "contact-messages": "contactMessage",
  enrollments: "enrollment",
  schedules: "classSchedule",
  sessions: "classSession",
  attendance: "attendance",
  progress: "progressRecord",
  invoices: "invoice",
  payments: "paymentRecord",
  "audit-logs": "auditLog",
  notifications: "notification",
  roles: "role",
} as const;
const soft = new Set([
  "courses",
  "teachers",
  "pricing-plans",
  "students",
  "guardians",
  "trials",
  "contact-messages",
  "enrollments",
  "schedules",
  "invoices",
  "payments",
]);
const versioned = new Set([
  "blog",
  "courses",
  "teachers",
  "pricing-plans",
  "pages",
  "faqs",
  "testimonials",
  "trials",
  "enrollments",
  "schedules",
  "sessions",
  "invoices",
]);
function delegate(client: unknown, resource: string): Delegate {
  if (!Object.hasOwn(mapped, resource))
    throw new AppError("NOT_FOUND", 404, "Module not found.");
  return (client as Record<string, unknown>)[
    mapped[resource as keyof typeof mapped]
  ] as Delegate;
}
function whereFor(resource: string, userId?: string) {
  return {
    ...(soft.has(resource) ? { deletedAt: null } : {}),
    ...(resource === "notifications" ? { userId } : {}),
  };
}
export async function listRecords(
  resource: string,
  page: number,
  pageSize: number,
  userId?: string,
) {
  const repository = delegate(database(), resource),
    where = whereFor(resource, userId);
  const [items, total] = await Promise.all([
    repository.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: [{ createdAt: "desc" }, { id: "asc" }],
    }),
    repository.count({ where }),
  ]);
  return { data: items, meta: { page, pageSize, total } };
}
export async function getRecord(resource: string, id: string, userId?: string) {
  const record = await delegate(database(), resource).findFirst({
    where: { id, ...whereFor(resource, userId) },
  });
  if (!record) throw new AppError("NOT_FOUND", 404, "Record not found.");
  return record;
}
export async function createRecord(
  resource: string,
  data: Record<string, unknown>,
  actorId: string,
) {
  if (resource === "teachers" && data.isPublic && !data.verificationNote)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Verify teacher credentials before making the profile public.",
    );
  if (resource === "students" && data.ageBand !== "18_PLUS" && !data.guardianId)
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Select a guardian for a learner under 18.",
    );
  return database().$transaction(async (tx) => {
    const { guardianId, ...recordData } = data;
    if (
      resource === "students" &&
      guardianId &&
      !(await tx.guardian.findFirst({
        where: { id: String(guardianId), deletedAt: null },
      }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose an existing guardian.",
      );
    const item = await delegate(tx, resource).create({
      data: {
        id: newId(),
        ...recordData,
        ...(resource === "blog"
          ? {
              authorId: actorId,
              renderedHtml: renderRichHtml(data.body),
              tags: data.tags ?? [],
            }
          : {}),
      },
    });
    if (resource === "students" && guardianId)
      await tx.studentGuardian.create({
        data: {
          id: newId(),
          studentId: item.id,
          guardianId: String(guardianId),
          isPrimary: true,
        },
      });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: resource + ".created",
        entityType: resource,
        entityId: item.id,
      },
    });
    return item;
  });
}
export async function updateRecord(
  resource: string,
  id: string,
  data: Record<string, unknown>,
  actorId: string,
  version?: number,
) {
  return database().$transaction(async (tx) => {
    if (resource === "teachers")
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const { guardianId, ...recordData } = data;
    if (
      resource === "students" &&
      guardianId &&
      !(await tx.guardian.findFirst({
        where: { id: String(guardianId), deletedAt: null },
      }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose an existing guardian.",
      );
    const repository = delegate(tx, resource);
    const current = await repository.findFirst({
      where: { id, ...whereFor(resource) },
    });
    if (!current) throw new AppError("NOT_FOUND", 404, "Record not found.");
    if (versioned.has(resource) && current.version !== version)
      throw new AppError(
        "CONFLICT",
        409,
        "This record has changed. Refresh and try again.",
      );
    if (
      [
        "courses",
        "blog",
        "pages",
        "faqs",
        "testimonials",
        "pricing-plans",
      ].includes(resource)
    ) {
      await tx.contentRevision.create({
        data: {
          id: newId(),
          entityType: resource,
          entityId: id,
          authorId: actorId,
          snapshot: JSON.parse(
            JSON.stringify(current),
          ) as Prisma.InputJsonValue,
        },
      });
    }
    if (
      resource === "students" &&
      data.ageBand &&
      data.ageBand !== "18_PLUS" &&
      !(await tx.studentGuardian.count({ where: { studentId: id } }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Add guardian information before changing this learner to a minor age band.",
      );
    if (
      resource === "students" &&
      data.ageBand &&
      data.ageBand !== "18_PLUS" &&
      !guardianId &&
      !(await tx.studentGuardian.count({ where: { studentId: id } }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Select a guardian for a learner under 18.",
      );
    if (resource === "teachers") {
      if (
        (data.isPublic ?? current.isPublic) &&
        !(data.verificationNote ?? current.verificationNote)
      )
        throw new AppError(
          "VALIDATION_ERROR",
          400,
          "Verify teacher credentials first.",
        );
      if (
        data.isActive === false &&
        (await tx.classSession.count({
          where: {
            teacherId: id,
            startsAtUtc: { gt: new Date() },
            status: { not: "CANCELLED" },
          },
        }))
      )
        throw new AppError(
          "CONFLICT",
          409,
          "Reassign or cancel future sessions before deactivating this teacher.",
        );
    }
    if (
      resource === "teachers" &&
      data.isActive === false &&
      (await tx.enrollment.count({
        where: {
          teacherId: id,
          deletedAt: null,
          status: { in: ["ACTIVE", "PAUSED"] },
        },
      }))
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Reassign or close active enrollments before deactivating this teacher.",
      );
    const changed = await repository.updateMany({
      where: {
        id,
        ...(versioned.has(resource) ? { version } : {}),
        ...whereFor(resource),
      },
      data: {
        ...recordData,
        ...([
          "blog",
          "courses",
          "pages",
          "faqs",
          "testimonials",
          "pricing-plans",
        ].includes(resource) && current.status !== "DRAFT"
          ? {
              status: "DRAFT",
              ...(["blog", "courses", "pages"].includes(resource)
                ? { publishedAt: null }
                : {}),
            }
          : {}),
        ...(resource === "blog" && data.body
          ? { renderedHtml: renderRichHtml(data.body) }
          : {}),
        ...(versioned.has(resource) ? { version: { increment: 1 } } : {}),
      },
    });
    if (!changed.count)
      throw new AppError("CONFLICT", 409, "This record has changed.");
    if (["courses", "blog", "pages"].includes(resource))
      await tx.setting.deleteMany({
        where: { key: "publication.schedule." + resource + "." + id },
      });
    if (resource === "courses" && data.slug && data.slug !== current.slug) {
      await tx.redirect.upsert({
        where: { fromPath: "/courses/" + current.slug },
        create: {
          id: newId(),
          fromPath: "/courses/" + current.slug,
          toPath: "/courses/" + data.slug,
        },
        update: { toPath: "/courses/" + data.slug },
      });
    }
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: resource + ".updated",
        entityType: resource,
        entityId: id,
      },
    });
    return repository.findFirst({ where: { id } });
  });
}
export async function deleteRecord(
  resource: string,
  id: string,
  actorId: string,
  version?: number,
) {
  return database().$transaction(async (tx) => {
    if (resource === "teachers")
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const repository = delegate(tx, resource),
      current = await repository.findFirst({
        where: { id, ...whereFor(resource) },
      });
    if (!current) throw new AppError("NOT_FOUND", 404, "Record not found.");
    if (versioned.has(resource) && current.version !== version)
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this record before deleting.",
      );
    if (
      resource === "teachers" &&
      (await tx.classSession.count({
        where: {
          teacherId: id,
          startsAtUtc: { gt: new Date() },
          status: { not: "CANCELLED" },
        },
      }))
    )
      throw new AppError("CONFLICT", 409, "Teacher has future sessions.");
    if (
      resource === "teachers" &&
      (await tx.enrollment.count({
        where: {
          teacherId: id,
          deletedAt: null,
          status: { in: ["ACTIVE", "PAUSED"] },
        },
      }))
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Reassign or close active enrollments before deleting this teacher.",
      );
    if (soft.has(resource))
      await repository.updateMany({
        where: { id, ...(versioned.has(resource) ? { version } : {}) },
        data: {
          deletedAt: new Date(),
          ...(versioned.has(resource) ? { version: { increment: 1 } } : {}),
        },
      });
    else await repository.delete({ where: { id } });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: resource + ".deleted",
        entityType: resource,
        entityId: id,
      },
    });
  });
}
export async function publishRecord(
  resource: string,
  id: string,
  status: string,
  version: number,
  actorId: string,
) {
  return database().$transaction((tx) =>
    publishRecordInTransaction(tx, resource, id, status, version, actorId),
  );
}
export async function publicationHead(
  tx: Prisma.TransactionClient,
  resource: string,
  id: string,
) {
  return delegate(tx, resource).findFirst({
    where: { id, ...whereFor(resource) },
  });
}
export async function publishRecordInTransaction(
  tx: Prisma.TransactionClient,
  resource: string,
  id: string,
  status: string,
  version: number,
  actorId: string,
) {
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"publication:" + resource + ":" + id},0))`;
  if (
    ![
      "blog",
      "courses",
      "faqs",
      "testimonials",
      "pages",
      "pricing-plans",
    ].includes(resource)
  )
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "This module does not use publishing.",
    );

  const repository = delegate(tx, resource),
    current = await repository.findFirst({
      where: { id, ...whereFor(resource) },
    });
  if (!current) throw new AppError("NOT_FOUND", 404, "Record not found.");
  const allowed: Record<string, string[]> = {
    DRAFT: ["SUBMITTED"],
    SUBMITTED: ["APPROVED", "DRAFT"],
    APPROVED: ["PUBLISHED", "DRAFT"],
    PUBLISHED: ["DRAFT", "ARCHIVED"],
    ARCHIVED: ["DRAFT"],
  };
  if (
    !allowed[String(current.status)]?.includes(status) ||
    current.version !== version
  )
    throw new AppError(
      "CONFLICT",
      409,
      "This publishing transition is not available.",
    );
  if (
    resource === "testimonials" &&
    status === "PUBLISHED" &&
    !current.consentRecordedAt
  )
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Record consent before publishing a testimonial.",
    );
  const changed = await repository.updateMany({
    where: { id, version },
    data: {
      status,
      version: { increment: 1 },
      ...(["blog", "courses", "pages"].includes(resource)
        ? { publishedAt: status === "PUBLISHED" ? new Date() : null }
        : {}),
    },
  });
  if (!changed.count)
    throw new AppError("CONFLICT", 409, "Record changed; refresh it.");
  await tx.setting.deleteMany({
    where: { key: "publication.schedule." + resource + "." + id },
  });
  await tx.contentRevision.create({
    data: {
      id: newId(),
      entityType: resource,
      entityId: id,
      snapshot: JSON.parse(JSON.stringify(current)) as Prisma.InputJsonValue,
      authorId: actorId,
    },
  });
  await tx.auditLog.create({
    data: {
      id: newId(),
      actorId,
      action: resource + ".status_changed",
      entityType: resource,
      entityId: id,
      before: { status: current.status },
      after: { status },
    },
  });
  await tx.outboxEvent.create({
    data: {
      id: newId(),
      kind:
        status === "PUBLISHED" ? "content.published" : "content.unpublished",
      payload: { resource, id },
    },
  });
  return repository.findFirst({ where: { id } });
}

export async function guardianOptions() {
  return database().guardian.findMany({
    where: { deletedAt: null },
    select: { id: true, fullName: true },
    orderBy: { fullName: "asc" },
    take: 200,
  });
}
