import { database } from "@/lib/db";
import { login } from "./identity-workflows";
import { revokeSession } from "./identity";
export async function reauthenticate(
  sessionId: string,
  email: string,
  password: string,
  code?: string,
) {
  const fresh = await login(email, password, code);
  await revokeSession(fresh.token);
  await database().session.update({
    where: { id: sessionId },
    data: { reauthenticatedAt: new Date() },
  });
  return { confirmed: true };
}
