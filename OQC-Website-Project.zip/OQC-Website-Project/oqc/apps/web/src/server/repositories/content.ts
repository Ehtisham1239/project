import { activeConsent } from "@/server/services/consent";
import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { Prisma } from "@/generated/prisma/client";
import { sectionsSchema } from "@/lib/validation/content";
import type { z } from "zod";
export async function replaceSections(
  id: string,
  input: z.infer<typeof sectionsSchema>,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    const current = await tx.cMSPage.findUnique({
      where: { id },
      include: { pageSection_pageId: true },
    });
    if (!current) throw new AppError("NOT_FOUND", 404, "Page not found.");
    if (current.status === "PUBLISHED")
      throw new AppError(
        "CONFLICT",
        409,
        "Return this page to draft before editing.",
      );
    const updated = await tx.cMSPage.updateMany({
      where: { id, version: input.version },
      data: { version: { increment: 1 }, status: "DRAFT" },
    });
    if (!updated.count)
      throw new AppError(
        "CONFLICT",
        409,
        "This page changed. Refresh before editing.",
      );
    await tx.contentRevision.create({
      data: {
        id: newId(),
        entityType: "pages",
        entityId: id,
        authorId: actorId,
        snapshot: JSON.parse(JSON.stringify(current)) as Prisma.InputJsonValue,
      },
    });
    await tx.pageSection.deleteMany({ where: { pageId: id } });
    await tx.pageSection.createMany({
      data: input.sections.map(({ section, isVisible }, index) => ({
        id: newId(),
        pageId: id,
        type: section.type,
        data: section.data as Prisma.InputJsonValue,
        sortOrder: index,
        isVisible,
      })),
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "page.sections_updated",
        entityType: "CMSPage",
        entityId: id,
        after: { sectionCount: input.sections.length },
      },
    });
    return { id, version: input.version + 1 };
  });
}
export async function settings() {
  return database().setting.findMany({
    select: { key: true, value: true, isPublic: true },
  });
}
export async function updateSetting(
  key: string,
  value: unknown,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    const isPublic = [
      "site.benefits",
      "social.links",
      "site.name",
      "contact.email",
      "contact.address",
      "contact.whatsapp",
      "contact.phones",
      "legal.entity",
      "legal.registration",
    ].includes(key);
    const item = await tx.setting.upsert({
      where: { key },
      create: {
        id: newId(),
        key,
        value: value as Prisma.InputJsonValue,
        isPublic,
      },
      update: { value: value as Prisma.InputJsonValue, isPublic },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "settings.updated",
        entityType: "Setting",
        entityId: item.id,
        after: { key },
      },
    });
    return { key, value, isPublic };
  });
}
export async function launchReadiness() {
  const db = database();
  const [courses, teachers, policies, values, prices] = await Promise.all([
    db.course.count({ where: { status: "PUBLISHED", deletedAt: null } }),
    db.teacher.count({
      where: {
        isActive: true,
        isPublic: true,
        deletedAt: null,
        verificationNote: { not: null },
      },
    }),
    db.cMSPage.findMany({
      where: {
        slug: { in: ["privacy", "terms", "refund", "child-safeguarding"] },
        status: "PUBLISHED",
        template: "POLICY",
        locale: "en",
      },
      select: { slug: true },
    }),
    db.setting.findMany({
      where: {
        key: {
          in: [
            "contact.email",
            "legal.entity",
            "readiness.brandApproved",
            "readiness.ownerSignoff",
            "readiness.contactForFeesAccepted",
            "readiness.botProtectionDisabledAccepted",
            "readiness.mailerDisabledAccepted",
          ],
        },
      },
    }),
    db.pricingPlanPrice.count({
      where: {
        isPublic: true,
        plan: { status: "PUBLISHED", isPublic: true, deletedAt: null },
      },
    }),
  ]);
  const map = Object.fromEntries(values.map((x) => [x.key, x.value]));
  const consent = await activeConsent();
  return [
    {
      key: "consent",
      label: "Owner-approved versioned admissions consent",
      passed: !!consent,
    },
    {
      key: "courses",
      label: "At least one published course",
      passed: courses > 0,
    },
    {
      key: "teachers",
      label: "At least one verified public teacher",
      passed: teachers > 0,
    },
    {
      key: "contact",
      label: "Official contact and legal entity set",
      passed: !!map["contact.email"] && !!map["legal.entity"],
    },
    {
      key: "policies",
      label: "Required policies approved and published",
      passed: new Set(policies.map((x) => x.slug)).size === 4,
    },
    {
      key: "pricing",
      label: "Public pricing or contact-for-fees accepted",
      passed: prices > 0 || map["readiness.contactForFeesAccepted"] === true,
    },
    {
      key: "bot",
      label: "Bot protection configured or consciously disabled",
      passed:
        (!!process.env.TURNSTILE_SECRET_KEY &&
          !!process.env.TURNSTILE_SITE_KEY) ||
        map["readiness.botProtectionDisabledAccepted"] === true,
    },
    {
      key: "mailer",
      label: "Mailer configured or consciously disabled",
      passed:
        (process.env.MAILER_DRIVER !== "console" &&
          !!process.env.MAILER_FROM) ||
        map["readiness.mailerDisabledAccepted"] === true,
    },
    {
      key: "brand",
      label: "Owner logo and brand review",
      passed: map["readiness.brandApproved"] === true,
    },
    {
      key: "signoff",
      label: "Owner launch signoff",
      passed: map["readiness.ownerSignoff"] === true,
    },
  ];
}

export async function pageSections(id: string) {
  return database().pageSection.findMany({
    where: { pageId: id },
    select: { id: true, type: true, data: true, isVisible: true },
    orderBy: { sortOrder: "asc" },
  });
}
