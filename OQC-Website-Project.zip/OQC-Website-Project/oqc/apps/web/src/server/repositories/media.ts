import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { hashToken } from "@/lib/auth/crypto";
export async function recordImage(
  data: {
    storageKey: string;
    mimeType: string;
    sizeBytes: number;
    width: number;
    height: number;
    checksum: string;
    altText: string;
  },
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    const asset = await tx.mediaAsset.create({
      data: { id: newId(), ...data, uploadedById: actorId, status: "READY" },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "media.uploaded",
        entityType: "MediaAsset",
        entityId: asset.id,
        after: { checksumHash: hashToken(data.checksum) },
      },
    });
    return {
      id: asset.id,
      width: asset.width,
      height: asset.height,
      altText: asset.altText,
    };
  });
}
export async function imageById(id: string) {
  return database().mediaAsset.findFirst({ where: { id, status: "READY" } });
}
