import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import type { InvoiceDocument } from "@/lib/finance/invoice-pdf";
export async function invoiceDocumentData(
  id: string,
): Promise<InvoiceDocument> {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const invoice = await tx.invoice.findFirst({
      where: { id, deletedAt: null },
      select: {
        number: true,
        currency: true,
        totalMinor: true,
        status: true,
        issuedAt: true,
        dueAt: true,
        enrollment: {
          select: {
            student: { select: { fullName: true } },
            course: { select: { title: true } },
          },
        },
      },
    });
    if (!invoice) throw new AppError("NOT_FOUND", 404, "Invoice not found.");
    if (invoice.status === "DRAFT")
      throw new AppError(
        "CONFLICT",
        409,
        "Issue the invoice before exporting it.",
      );
    const [payments, total, paymentCount, settings] = await Promise.all([
      tx.paymentRecord.findMany({
        where: { invoiceId: id, deletedAt: null },
        orderBy: [{ receivedAt: "asc" }, { id: "asc" }],
        take: 100,
        select: { amountMinor: true, method: true, receivedAt: true },
      }),
      tx.paymentRecord.aggregate({
        where: { invoiceId: id, deletedAt: null },
        _sum: { amountMinor: true },
      }),
      tx.paymentRecord.count({ where: { invoiceId: id, deletedAt: null } }),
      tx.setting.findMany({
        where: {
          key: { in: ["legal.entity", "contact.address", "contact.email"] },
        },
        select: { key: true, value: true },
      }),
    ]);
    const values = Object.fromEntries(
      settings
        .filter((row) => typeof row.value === "string" && row.value)
        .map((row) => [row.key, row.value as string]),
    );
    const { enrollment, ...details } = invoice;
    return {
      ...details,
      learnerName: enrollment.student.fullName,
      courseTitle: enrollment.course.title,
      companyName: values["legal.entity"],
      address: values["contact.address"],
      email: values["contact.email"],
      paidMinor: total._sum.amountMinor ?? 0,
      payments,
      paymentCount,
      generatedAt: new Date(),
    };
  });
}
export function auditInvoicePdf(id: string, actorId: string, checksum: string) {
  return database().auditLog.create({
    data: {
      id: newId(),
      actorId,
      action: "invoice.pdf_exported",
      entityType: "Invoice",
      entityId: id,
      after: { checksum },
    },
  });
}
