import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import {
  publicationHead,
  publishRecordInTransaction,
} from "@/server/repositories/admin";
import { publicationJobSchema } from "@/lib/validation/publication-schedule";
import { can } from "@/lib/rbac/policy";
export type PublicationResource = "courses" | "blog" | "pages";
const key = (resource: string, id: string) =>
  `publication.schedule.${resource}.${id}`;
export function scheduledResource(value: string): value is PublicationResource {
  return ["courses", "blog", "pages"].includes(value);
}
export async function scheduledPublication(
  resource: PublicationResource,
  id: string,
) {
  const value = await database().setting.findUnique({
      where: { key: key(resource, id) },
    }),
    parsed = publicationJobSchema.safeParse(value?.value);
  return parsed.success
    ? { publishAt: parsed.data.publishAt, version: parsed.data.version }
    : null;
}
export async function schedulePublication(
  resource: PublicationResource,
  id: string,
  input: { version: number; publishAt: string },
  actorId: string,
) {
  const when = new Date(input.publishAt),
    now = Date.now();
  if (
    !Number.isFinite(when.getTime()) ||
    when.getTime() <= now ||
    when.getTime() - now > 365 * 86400000
  )
    throw new AppError(
      "VALIDATION_ERROR",
      400,
      "Choose a future publication time within one year.",
    );
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"publication:" + resource + ":" + id},0))`;
    const record = await publicationHead(tx, resource, id);
    if (!record) throw new AppError("NOT_FOUND", 404, "Content not found.");
    if (record.status !== "APPROVED" || record.version !== input.version)
      throw new AppError(
        "CONFLICT",
        409,
        "Approve this version and refresh it before scheduling publication.",
      );
    // Incrementing the version atomically invalidates concurrent edits or old jobs.
    const delegate = tx[
      { courses: "course", blog: "blogPost", pages: "cMSPage" }[
        resource
      ] as "course"
    ] as unknown as { updateMany(args: unknown): Promise<{ count: number }> };
    const changed = await delegate.updateMany({
      where: { id, version: input.version, status: "APPROVED" },
      data: {
        version: { increment: 1 },
        ...(resource === "blog" ? { scheduledAt: when } : {}),
      },
    });
    if (changed.count !== 1)
      throw new AppError(
        "CONFLICT",
        409,
        "This content changed. Refresh before scheduling it.",
      );
    const value = {
      resource,
      id,
      version: input.version + 1,
      actorId,
      publishAt: when.toISOString(),
    };
    await tx.setting.upsert({
      where: { key: key(resource, id) },
      create: { id: newId(), key: key(resource, id), value, isPublic: false },
      update: { value, isPublic: false },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "content.publication_scheduled",
        entityType: resource,
        entityId: id,
        after: { publishAt: value.publishAt, version: value.version },
      },
    });
    return { id, version: value.version, publishAt: value.publishAt };
  });
}
export async function cancelPublication(
  resource: PublicationResource,
  id: string,
  version: number,
  actorId: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"publication:" + resource + ":" + id},0))`;
    const record = await publicationHead(tx, resource, id);
    if (!record) throw new AppError("NOT_FOUND", 404, "Content not found.");
    if (record.version !== version)
      throw new AppError(
        "CONFLICT",
        409,
        "Refresh this content before cancelling its schedule.",
      );
    const delegate = tx[
      { courses: "course", blog: "blogPost", pages: "cMSPage" }[
        resource
      ] as "course"
    ] as unknown as { updateMany(args: unknown): Promise<{ count: number }> };
    const changed = await delegate.updateMany({
      where: { id, version },
      data: {
        version: { increment: 1 },
        ...(resource === "blog" ? { scheduledAt: null } : {}),
      },
    });
    if (changed.count !== 1)
      throw new AppError(
        "CONFLICT",
        409,
        "This content changed while cancelling its schedule.",
      );
    const deleted = await tx.setting.deleteMany({
      where: { key: key(resource, id) },
    });
    if (!deleted.count)
      throw new AppError(
        "CONFLICT",
        409,
        "There is no pending publication schedule.",
      );
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "content.publication_schedule_cancelled",
        entityType: resource,
        entityId: id,
      },
    });
    return { id, version: version + 1 };
  });
}
export async function publishDueContent(limit = 20, at = new Date()) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 50)
    throw new Error("Invalid publication batch size");
  if (!Number.isFinite(at.getTime()))
    throw new Error("Invalid publication clock");
  const candidates = await database().setting.findMany({
    where: {
      key: { startsWith: "publication.schedule." },
      value: { path: ["publishAt"], lte: at.toISOString() },
    },
    take: limit,
    orderBy: { key: "asc" },
    select: { key: true, value: true },
  });
  let published = 0,
    cancelled = 0;
  for (const candidate of candidates) {
    const initial = publicationJobSchema.safeParse(candidate.value);
    if (
      !initial.success ||
      candidate.key !== key(initial.data.resource, initial.data.id)
    )
      continue;
    const job = initial.data;
    const outcome = await database().$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${"publication:" + job.resource + ":" + job.id},0))`;
      const current = await tx.setting.findUnique({
          where: { key: candidate.key },
        }),
        checked = publicationJobSchema.safeParse(current?.value);
      if (
        !checked.success ||
        checked.data.version !== job.version ||
        checked.data.publishAt !== job.publishAt ||
        checked.data.actorId !== job.actorId ||
        new Date(checked.data.publishAt).getTime() > at.getTime()
      )
        return "skipped";
      await tx.$queryRaw`SELECT id FROM "User" WHERE id=${job.actorId}::uuid FOR SHARE`;
      const actor = await tx.user.findUnique({
          where: { id: job.actorId },
          include: { role: true },
        }),
        record = await publicationHead(tx, job.resource, job.id);
      let reason =
        !actor ||
        !actor.isActive ||
        actor.deletedAt ||
        actor.mustEnrollMfa ||
        !actor.mfaEnabled ||
        !can(actor.role.key, job.resource + ":publish")
          ? "ACTOR_UNAVAILABLE"
          : !record ||
              record.version !== job.version ||
              record.status !== "APPROVED"
            ? "CONTENT_CHANGED"
            : null;
      if (!reason) {
        try {
          await publishRecordInTransaction(
            tx,
            job.resource,
            job.id,
            "PUBLISHED",
            job.version,
            job.actorId,
          );
          return "published";
        } catch (error) {
          if (error instanceof AppError && error.code === "CONFLICT")
            reason = "CONTENT_CHANGED";
          else throw error;
        }
      }
      await tx.setting.deleteMany({ where: { key: candidate.key } });
      await tx.auditLog.create({
        data: {
          id: newId(),
          action: "content.publication_schedule_rejected",
          entityType: job.resource,
          entityId: job.id,
          after: { reason },
        },
      });
      return "cancelled";
    });
    if (outcome === "published") published++;
    if (outcome === "cancelled") cancelled++;
  }
  return { published, cancelled };
}
