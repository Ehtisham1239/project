import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import {
  hashPassword,
  hashToken,
  randomToken,
  decryptSecret,
  verifyPassword,
} from "@/lib/auth/crypto";
import { AppError } from "@/lib/platform/errors";
import { verify } from "otplib";
export async function issuePasswordReset(
  id: string,
  actorId: string,
  actorRole: string,
) {
  const token = randomToken();
  await database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${id},0))`;
    const user = await tx.user.findFirst({
      where: { id, isActive: true, deletedAt: null },
      include: { role: true },
    });
    if (!user)
      throw new AppError("NOT_FOUND", 404, "Active account not found.");
    if (user.role.key === "SUPER_ADMIN" && actorRole !== "SUPER_ADMIN")
      throw new AppError(
        "FORBIDDEN",
        403,
        "Only a Super Admin can reset this account.",
      );
    await tx.passwordResetToken.updateMany({
      where: { userId: id, usedAt: null },
      data: { usedAt: new Date() },
    });
    await tx.passwordResetToken.create({
      data: {
        id: newId(),
        userId: id,
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + 30 * 60000),
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "identity.password_reset_issued",
        entityType: "User",
        entityId: id,
      },
    });
  });
  return { resetToken: token };
}
export async function resetPassword(
  token: string,
  password: string,
  code?: string,
) {
  const passwordHash = await hashPassword(password);
  await database().$transaction(async (tx) => {
    const record = await tx.passwordResetToken.findUnique({
      where: { tokenHash: hashToken(token) },
      include: { user: true },
    });
    if (
      !record ||
      record.usedAt ||
      record.expiresAt <= new Date() ||
      !record.user.isActive ||
      record.user.deletedAt
    )
      throw new AppError(
        "UNAUTHENTICATED",
        401,
        "This reset link has expired or was already used.",
      );
    const user = record.user;
    if (user.mfaEnabled) {
      if (!code || !user.mfaSecretEnc)
        throw new AppError(
          "UNAUTHENTICATED",
          401,
          "An authenticator or unused backup code is required.",
        );
      const result = await verify({
        secret: decryptSecret(user.mfaSecretEnc),
        token: code,
      }).catch(() => ({ valid: false }));
      if (result.valid) {
        const step = Math.floor(Date.now() / 30000);
        const claim = await tx.user.updateMany({
          where: {
            id: user.id,
            OR: [{ lastMfaStep: null }, { lastMfaStep: { lt: step } }],
          },
          data: { lastMfaStep: step },
        });
        if (!claim.count)
          throw new AppError(
            "UNAUTHENTICATED",
            401,
            "Wait for a new authenticator code.",
          );
      } else if (
        !(
          await tx.mfaBackupCode.updateMany({
            where: { userId: user.id, codeHash: hashToken(code), usedAt: null },
            data: { usedAt: new Date() },
          })
        ).count
      )
        throw new AppError(
          "UNAUTHENTICATED",
          401,
          "Check your authenticator or backup code.",
        );
    }
    const claim = await tx.passwordResetToken.updateMany({
      where: { id: record.id, usedAt: null, expiresAt: { gt: new Date() } },
      data: { usedAt: new Date() },
    });
    if (!claim.count)
      throw new AppError("CONFLICT", 409, "This reset link was already used.");
    await tx.user.update({
      where: { id: user.id },
      data: { passwordHash, failedLogins: 0, lockedUntil: null },
    });
    await tx.passwordResetToken.updateMany({
      where: { userId: user.id, usedAt: null },
      data: { usedAt: new Date() },
    });
    await tx.session.deleteMany({ where: { userId: user.id } });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId: user.id,
        action: "identity.password_reset_completed",
        entityType: "User",
        entityId: user.id,
      },
    });
  });
  return { reset: true };
}

export async function changeOwnPassword(
  id: string,
  currentPassword: string,
  nextPassword: string,
  code?: string,
) {
  const user = await database().user.findUniqueOrThrow({
    where: { id },
    include: { role: true },
  });
  if (
    !(await verifyPassword(user.passwordHash, currentPassword).catch(
      () => false,
    ))
  )
    throw new AppError("UNAUTHENTICATED", 401, "Check your current password.");
  const token = await issuePasswordReset(id, id, user.role.key);
  return resetPassword(token.resetToken, nextPassword, code);
}
