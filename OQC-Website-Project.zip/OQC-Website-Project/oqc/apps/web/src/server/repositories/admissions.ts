import { database } from "@/lib/db";
import { AppError } from "@/lib/platform/errors";
import { newId } from "@/lib/platform/ids";
import { privateHash } from "@/lib/auth/crypto";
import { randomBytes } from "node:crypto";
import type { TrialInput, ContactInput } from "@/lib/validation/admissions";
import { canTransition, type TrialState } from "@/lib/admissions/state-machine";
export async function persistTrial(
  input: TrialInput,
  key: string,
  requestHash: string,
  ipHash: string,
) {
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${key},0))`;
    const replay = await tx.idempotencyRecord.findUnique({ where: { key } });
    if (replay) {
      if (replay.requestHash !== requestHash)
        throw new AppError(
          "CONFLICT",
          409,
          "This submission key was already used with different details.",
        );
      return replay.response;
    }
    const course = await tx.course.findFirst({
      where: { id: input.courseId, status: "PUBLISHED", deletedAt: null },
    });
    if (!course)
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Please select a published course.",
      );
    const duplicate = await tx.trialApplication.findFirst({
      where: {
        courseId: input.courseId,
        createdAt: { gte: new Date(Date.now() - 30 * 86400000) },
        OR: [{ email: input.email }, { phoneE164: input.phoneE164 }],
      },
      orderBy: { createdAt: "desc" },
      select: { id: true },
    });
    const { website, startedAt, botToken, ...data } = input;
    void website;
    void startedAt;
    void botToken;
    const date = new Date(),
      reference = `OQC-T-${date.getUTCFullYear().toString().slice(2)}${String(date.getUTCMonth() + 1).padStart(2, "0")}-${randomBytes(5).toString("hex").toUpperCase()}`;
    const trial = await tx.trialApplication.create({
      data: {
        id: newId(),
        ...data,
        availableSlots: data.availableSlots,
        consentAt: date,
        reference,
        idempotencyKey: key,
        duplicateOfId: duplicate?.id,
        ipHash,
      },
    });
    await tx.trialHistory.create({
      data: { id: newId(), trialId: trial.id, toStatus: "NEW" },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        action: "trial.submitted",
        entityType: "TrialApplication",
        entityId: trial.id,
        ipHash,
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "trial.submitted",
        payload: { trialId: trial.id },
      },
    });
    const response = {
      reference,
      message:
        "Your application has been received. Our team will review your request.",
    };
    await tx.idempotencyRecord.create({
      data: {
        id: newId(),
        key,
        requestHash,
        response,
        expiresAt: new Date(Date.now() + 86400000),
      },
    });
    return response;
  });
}
export async function findTrialReplay(key: string, requestHash: string) {
  const result = await database().idempotencyRecord.findUnique({
    where: { key },
  });
  if (result && result.requestHash !== requestHash)
    throw new AppError(
      "CONFLICT",
      409,
      "This submission key was already used with different details.",
    );
  return result?.response ?? null;
}
export async function persistContact(input: ContactInput, ipHash: string) {
  const { website, startedAt, botToken, consentGiven, ...data } = input;
  void website;
  void startedAt;
  void botToken;
  void consentGiven;
  return database().$transaction(async (tx) => {
    const contact = await tx.contactMessage.create({
      data: { id: newId(), ...data, consentAt: new Date(), ipHash },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        action: "contact.received",
        entityType: "ContactMessage",
        entityId: contact.id,
        ipHash,
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "contact.received",
        payload: { contactId: contact.id },
      },
    });
    return {
      message: "Your message has been received. Our team will review it.",
    };
  });
}
export async function changeTrialStatus(
  id: string,
  toStatus: TrialState,
  actorId: string,
  version: number,
  note?: string,
) {
  return database().$transaction(async (tx) => {
    const trial = await tx.trialApplication.findFirst({
      where: { id, deletedAt: null },
    });
    if (!trial) throw new AppError("NOT_FOUND", 404, "Application not found.");
    if (trial.version !== version || !canTransition(trial.status, toStatus))
      throw new AppError(
        "CONFLICT",
        409,
        "This status change is not available. Refresh the application.",
      );
    if (
      toStatus === "SCHEDULED" &&
      (!trial.assignedTeacherId || !trial.trialSessionAtUtc)
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Assign a teacher and trial time first.",
      );
    if (toStatus === "ENROLLED")
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Use the conversion workflow to enroll this learner.",
      );
    const changed = await tx.trialApplication.updateMany({
      where: { id, version },
      data: { status: toStatus, version: { increment: 1 } },
    });
    if (!changed.count)
      throw new AppError("CONFLICT", 409, "Application changed; refresh it.");
    await tx.trialHistory.create({
      data: {
        id: newId(),
        trialId: id,
        fromStatus: trial.status,
        toStatus,
        actorId,
        note,
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "trial.status_changed",
        entityType: "TrialApplication",
        entityId: id,
        before: { status: trial.status },
        after: { status: toStatus },
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "trial.status_changed",
        payload: { trialId: id, status: toStatus },
      },
    });
    return { id, status: toStatus, version: version + 1 };
  });
}
export const submissionHash = (value: unknown) =>
  privateHash(JSON.stringify(value));
export async function botProtectionDisabledByOwner() {
  const record = await database().setting.findUnique({
    where: { key: "readiness.botProtectionDisabledAccepted" },
    select: { value: true },
  });
  return record?.value === true;
}
