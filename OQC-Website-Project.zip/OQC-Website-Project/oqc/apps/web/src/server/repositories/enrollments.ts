import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { AppError } from "@/lib/platform/errors";
import { enrollmentSchema } from "@/lib/validation/enrollment";
import type { z } from "zod";
export async function enrollmentChoices() {
  const [students, courses, teachers, plans] = await Promise.all([
    database().student.findMany({
      where: { deletedAt: null, status: "ACTIVE" },
      orderBy: { fullName: "asc" },
      take: 200,
      select: { id: true, fullName: true },
    }),
    database().course.findMany({
      where: { deletedAt: null, status: "PUBLISHED" },
      orderBy: { title: "asc" },
      take: 200,
      select: { id: true, title: true },
    }),
    database().teacher.findMany({
      where: { deletedAt: null, isActive: true },
      orderBy: { displayName: "asc" },
      take: 200,
      select: {
        id: true,
        displayName: true,
        teacherCourse_teacherId: { select: { courseId: true } },
      },
    }),
    database().pricingPlan.findMany({
      where: { deletedAt: null, status: "PUBLISHED" },
      orderBy: { name: "asc" },
      take: 200,
      select: { id: true, name: true, courseId: true },
    }),
  ]);
  return {
    students,
    courses,
    teachers: teachers.map(({ teacherCourse_teacherId, ...teacher }) => ({
      ...teacher,
      courseIds: teacherCourse_teacherId.map((link) => link.courseId),
    })),
    plans,
  };
}
export async function createEnrollment(
  input: z.infer<typeof enrollmentSchema>,
  actorId: string,
) {
  const data = enrollmentSchema.parse(input);
  return database().$transaction(async (tx) => {
    for (const lockId of [
      data.teacherId,
      data.studentId + ":" + data.courseId,
    ].sort())
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${lockId},0))`;
    const [student, course, teacher, duplicate] = await Promise.all([
      tx.student.findFirst({
        where: { id: data.studentId, deletedAt: null, status: "ACTIVE" },
        include: {
          studentGuardian_studentId: {
            where: { guardian: { deletedAt: null } },
            select: { id: true },
          },
        },
      }),
      tx.course.findFirst({
        where: { id: data.courseId, deletedAt: null, status: "PUBLISHED" },
      }),
      tx.teacherCourse.findFirst({
        where: {
          teacherId: data.teacherId,
          courseId: data.courseId,
          teacher: { deletedAt: null, isActive: true },
        },
      }),
      tx.enrollment.findFirst({
        where: {
          studentId: data.studentId,
          courseId: data.courseId,
          status: { in: ["ACTIVE", "PAUSED"] },
          deletedAt: null,
        },
      }),
    ]);
    if (!student || !course || !teacher)
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose an active learner, published course and a teacher assigned to that course.",
      );
    if (
      student.ageBand !== "18_PLUS" &&
      !student.studentGuardian_studentId.length
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Add a guardian before enrolling a learner under 18.",
      );
    if (duplicate)
      throw new AppError(
        "CONFLICT",
        409,
        "This learner is already enrolled in the course.",
      );
    if (
      data.planId &&
      !(await tx.pricingPlan.findFirst({
        where: {
          id: data.planId,
          deletedAt: null,
          status: "PUBLISHED",
          OR: [{ courseId: null }, { courseId: data.courseId }],
        },
      }))
    )
      throw new AppError(
        "VALIDATION_ERROR",
        400,
        "Choose a published pricing plan for this course.",
      );
    const record = await tx.enrollment.create({
      data: {
        id: newId(),
        ...data,
        startDate: new Date(data.startDate + "T00:00:00Z"),
        endDate: data.endDate
          ? new Date(data.endDate + "T00:00:00Z")
          : undefined,
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "enrollment.created",
        entityType: "Enrollment",
        entityId: record.id,
        after: {
          studentId: data.studentId,
          courseId: data.courseId,
          teacherId: data.teacherId,
        },
      },
    });
    await tx.outboxEvent.create({
      data: {
        id: newId(),
        kind: "enrollment.created",
        payload: { id: record.id },
      },
    });
    return { id: record.id };
  });
}
