import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import { hashPassword, hashToken, randomToken } from "@/lib/auth/crypto";
import { canAssignRole, type RoleKey } from "@/lib/rbac/policy";
import { AppError } from "@/lib/platform/errors";
export async function staffUsers() {
  return database().user.findMany({
    where: { deletedAt: null },
    select: {
      id: true,
      name: true,
      email: true,
      isActive: true,
      mfaEnabled: true,
      mustEnrollMfa: true,
      lastLoginAt: true,
      role: { select: { key: true } },
    },
    orderBy: { name: "asc" },
  });
}
export async function inviteUser(
  data: { email: string; name: string; role: RoleKey },
  actorId: string,
  actorRole: string,
) {
  if (!canAssignRole(actorRole, data.role))
    throw new AppError("FORBIDDEN", 403, "You cannot assign this role.");
  const token = randomToken(),
    passwordHash = await hashPassword(randomToken());
  await database().$transaction(async (tx) => {
    const role = await tx.role.findUniqueOrThrow({ where: { key: data.role } });
    if (await tx.user.findUnique({ where: { email: data.email } }))
      throw new AppError("CONFLICT", 409, "This account already exists.");
    const user = await tx.user.create({
      data: {
        id: newId(),
        name: data.name,
        email: data.email,
        roleId: role.id,
        passwordHash,
      },
    });
    await tx.inviteToken.create({
      data: {
        id: newId(),
        userId: user.id,
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + 48 * 3600000),
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "identity.invited",
        entityType: "User",
        entityId: user.id,
        after: { role: data.role },
      },
    });
  });
  return { inviteToken: token };
}
export async function acceptInvitation(token: string, password: string) {
  const passwordHash = await hashPassword(password),
    setupToken = randomToken();
  return database().$transaction(async (tx) => {
    const invite = await tx.inviteToken.findUnique({
      where: { tokenHash: hashToken(token) },
      include: { user: true },
    });
    if (
      !invite ||
      invite.usedAt ||
      invite.expiresAt <= new Date() ||
      invite.user.isActive ||
      invite.user.deletedAt
    )
      throw new AppError(
        "UNAUTHENTICATED",
        401,
        "This invitation has expired or was already used.",
      );
    const claimed = await tx.inviteToken.updateMany({
      where: { id: invite.id, usedAt: null, expiresAt: { gt: new Date() } },
      data: { usedAt: new Date() },
    });
    if (claimed.count !== 1)
      throw new AppError("CONFLICT", 409, "Invitation already used.");
    await tx.user.update({
      where: { id: invite.userId },
      data: { passwordHash, mustEnrollMfa: true, isActive: false },
    });
    await tx.mfaSetupToken.create({
      data: {
        id: newId(),
        userId: invite.userId,
        tokenHash: hashToken(setupToken),
        expiresAt: new Date(Date.now() + 30 * 60000),
      },
    });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId: invite.userId,
        action: "identity.invite_accepted",
        entityType: "User",
        entityId: invite.userId,
      },
    });
    return { setupToken };
  });
}
export async function updateUser(
  id: string,
  data: { role: RoleKey; isActive: boolean },
  actorId: string,
  actorRole: string,
) {
  if (!canAssignRole(actorRole, data.role))
    throw new AppError("FORBIDDEN", 403, "You cannot assign this role.");
  return database().$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(713095)`;
    const target = await tx.user.findFirst({
      where: { id, deletedAt: null },
      include: { role: true },
    });
    if (!target) throw new AppError("NOT_FOUND", 404, "Account not found.");
    if (target.role.key === "SUPER_ADMIN" && actorRole !== "SUPER_ADMIN")
      throw new AppError(
        "FORBIDDEN",
        403,
        "Only a Super Admin can update this account.",
      );
    if (
      target.role.key === "SUPER_ADMIN" &&
      (!data.isActive || data.role !== "SUPER_ADMIN") &&
      (await tx.user.count({
        where: {
          isActive: true,
          deletedAt: null,
          role: { key: "SUPER_ADMIN" },
        },
      })) <= 1
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Retain at least one active Super Admin.",
      );
    if (
      data.isActive &&
      (target.mustEnrollMfa ||
        (["ADMIN", "SUPER_ADMIN"].includes(data.role) && !target.mfaEnabled))
    )
      throw new AppError(
        "CONFLICT",
        409,
        "Complete mandatory MFA before enabling this account.",
      );
    const role = await tx.role.findUniqueOrThrow({ where: { key: data.role } });
    await tx.user.update({
      where: { id },
      data: { roleId: role.id, isActive: data.isActive },
    });
    await tx.session.deleteMany({ where: { userId: id } });
    await tx.auditLog.create({
      data: {
        id: newId(),
        actorId,
        action: "identity.role_or_status_changed",
        entityType: "User",
        entityId: id,
        after: { role: data.role, isActive: data.isActive },
      },
    });
    return { id };
  });
}
