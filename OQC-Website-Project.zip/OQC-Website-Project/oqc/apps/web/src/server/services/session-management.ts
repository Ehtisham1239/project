export {
  ownSessions,
  revokeOwnSessions,
} from "@/server/repositories/session-management";
