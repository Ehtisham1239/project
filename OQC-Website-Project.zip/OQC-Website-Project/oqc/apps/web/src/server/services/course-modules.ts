export {
  courseModules,
  replaceCourseModules,
} from "@/server/repositories/course-modules";
