import { createHash } from "node:crypto";
import { renderInvoicePdf } from "@/lib/finance/invoice-pdf";
import {
  invoiceDocumentData,
  auditInvoicePdf,
} from "@/server/repositories/invoice-documents";
export async function exportInvoicePdf(id: string, actorId: string) {
  const data = await invoiceDocumentData(id),
    bytes = await renderInvoicePdf(data);
  await auditInvoicePdf(
    id,
    actorId,
    createHash("sha256").update(bytes).digest("hex"),
  );
  return {
    bytes,
    filename: data.number.replace(/[^a-zA-Z0-9_-]/g, "_") + ".pdf",
  };
}
