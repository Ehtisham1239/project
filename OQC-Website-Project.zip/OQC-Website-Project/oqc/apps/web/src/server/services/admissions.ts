import { verifyConsentVersion } from "@/server/services/consent";
import type { TrialInput, ContactInput } from "@/lib/validation/admissions";
import { verifyBot } from "@/lib/admissions/antibot";
import { rateLimit } from "@/lib/ratelimit";
import { privateHash } from "@/lib/auth/crypto";
import {
  botProtectionDisabledByOwner,
  findTrialReplay,
  persistTrial,
  persistContact,
  submissionHash,
} from "@/server/repositories/admissions";
export { changeTrialStatus } from "@/server/repositories/admissions";
export async function submitTrial(
  input: TrialInput,
  key: string,
  ipHash: string,
) {
  const requestHash = submissionHash(input);
  const replay = await findTrialReplay(key, requestHash);
  if (replay) return replay;
  await verifyConsentVersion(input.consentTextVersion);
  await verifyBot(
    input,
    process.env.NODE_ENV === "production" && !process.env.TURNSTILE_SECRET_KEY
      ? await botProtectionDisabledByOwner()
      : false,
  );
  await rateLimit("trial-ip:" + ipHash, 5, 3600);
  await rateLimit("trial-email:" + privateHash(input.email), 3, 86400);
  return persistTrial(input, key, requestHash, ipHash);
}
export async function submitContact(input: ContactInput, ipHash: string) {
  await verifyConsentVersion(input.consentTextVersion);
  await verifyBot(
    input,
    process.env.NODE_ENV === "production" && !process.env.TURNSTILE_SECRET_KEY
      ? await botProtectionDisabledByOwner()
      : false,
  );
  await rateLimit("contact-ip:" + ipHash, 5, 3600);
  return persistContact(input, ipHash);
}

export { botProtectionDisabledByOwner } from "@/server/repositories/admissions";
