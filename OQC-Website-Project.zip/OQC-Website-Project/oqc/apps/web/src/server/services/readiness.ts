import Redis from "ioredis";
import { verifyDatabase } from "@/server/repositories/readiness";
import { runtimeEnv } from "@/lib/platform/env";
import { assertProductionBootstrapRemoved } from "@/server/services/identity";
export async function ready() {
  const config = runtimeEnv();
  await assertProductionBootstrapRemoved();
  const db = await verifyDatabase();
  const redis = new Redis(config.REDIS_URL, {
    lazyConnect: true,
    connectTimeout: 1000,
    maxRetriesPerRequest: 0,
    retryStrategy: () => null,
  });
  redis.on("error", () => {});
  try {
    await redis.connect();
    const cache = (await redis.ping()) === "PONG";
    return db && cache;
  } finally {
    redis.disconnect();
  }
}
