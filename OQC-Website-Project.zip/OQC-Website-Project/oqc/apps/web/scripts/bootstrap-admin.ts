import "dotenv/config";
import { bootstrap } from "../src/server/services/identity";
import { bootstrapSchema } from "../src/lib/validation/auth";
import { database } from "../src/lib/db";
async function hiddenPassword() {
  if (!process.stdin.isTTY)
    throw new Error(
      "Run interactively in a terminal; password arguments are not accepted",
    );
  process.stdout.write("Password (12+ characters): ");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  let value = "";
  return new Promise<string>((resolve, reject) => {
    const handler = (chunk: Buffer) => {
      for (const c of chunk.toString()) {
        if (c === "\u0003") {
          cleanup();
          reject(new Error("Cancelled"));
          return;
        }
        if (c === "\r" || c === "\n") {
          cleanup();
          resolve(value);
          return;
        }
        if (c === "\u007f") {
          value = value.slice(0, -1);
          continue;
        }
        value += c;
      }
    };
    function cleanup() {
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdin.off("data", handler);
      process.stdout.write("\n");
    }
    process.stdin.on("data", handler);
  });
}
try {
  const args = process.argv.slice(2);
  const email = args[args.indexOf("--email") + 1];
  if (!args.includes("--email")) throw new Error("Use --email <address>");
  const password = await hiddenPassword();
  const input = bootstrapSchema.parse({ email, password, name: "Super Admin" });
  const result = await bootstrap({
    ...input,
    confirmProduction: args.includes("--confirm-production"),
  });
  console.log("One-time MFA setup link (30 minutes):");
  console.log(
    `${process.env.APP_URL ?? "http://localhost:3000"}/admin/setup#token=${result.setupToken}`,
  );
  console.log("Store backup codes, then remove BOOTSTRAP_TOKEN.");
} catch (error) {
  console.error(error instanceof Error ? error.message : "Bootstrap failed");
  process.exitCode = 1;
} finally {
  await database().$disconnect();
}
