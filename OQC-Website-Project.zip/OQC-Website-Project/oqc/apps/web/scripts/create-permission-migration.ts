import { mkdir, writeFile } from "node:fs/promises";
import {
  permissionKeys,
  permissionMatrix,
  roles,
} from "../src/lib/rbac/policy";
import { v7 } from "uuid";
let sql =
  "-- Add missing explicit catalog submit/publish permissions; no business data.\n";
for (const permission of permissionKeys)
  sql += `INSERT INTO "Permission" (id,key,description,"updatedAt") VALUES ('${v7()}','${permission}','${permission}',CURRENT_TIMESTAMP) ON CONFLICT (key) DO NOTHING;\n`;
for (const role of roles)
  for (const permission of permissionMatrix[role])
    sql += `INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '${v7()}',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='${role}' AND p.key='${permission}' ON CONFLICT ("roleId","permissionId") DO NOTHING;\n`;
await mkdir("prisma/migrations/202610110003_catalog_permissions", {
  recursive: true,
});
await writeFile(
  "prisma/migrations/202610110003_catalog_permissions/migration.sql",
  sql,
);
