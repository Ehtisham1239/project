import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { pathToFileURL } from "node:url";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";
let pool;
const require = createRequire(import.meta.url);
const prismaRequire = createRequire(require.resolve("@prisma/internals"));
const {
  bindMigrationAwareSqlAdapterFactory,
} = require("@prisma/driver-adapter-utils");
export const filters = { externalTables: [], externalEnums: [] };
let Engine;
export async function loadEngine() {
  if (!Engine) {
    const runtimePath = prismaRequire.resolve(
      "@prisma/schema-engine-wasm/schema_engine_bg",
    );
    const runtime = await import(pathToFileURL(runtimePath).href);
    const bytes = await readFile(
      join(dirname(runtimePath), "schema_engine_bg.wasm"),
    );
    const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes), {
      "./schema_engine_bg.js": runtime,
    });
    runtime.__wbg_set_wasm(instance.exports);
    instance.exports.__wbindgen_start();
    Engine = runtime.SchemaEngine;
  }
  const schema = await readFile("prisma/schema.prisma", "utf8");
  pool = new pg.Pool({
    connectionString:
      process.env.DATABASE_URL ?? "postgresql://oqc:oqc@localhost:5432/oqc_dev",
  });
  const factory = new PrismaPg(pool);
  const connect = factory.connect.bind(factory);
  factory.connect = async () => {
    const adapter = await connect();
    adapter.executeScript = async (script) => {
      await pool.query(script);
    };
    return adapter;
  };
  return Engine.new(
    { datamodels: [["prisma/schema.prisma", schema]] },
    () => {},
    bindMigrationAwareSqlAdapterFactory(factory),
  );
}

export async function shutdownEngine(engine) {
  engine.free();
  await pool?.end();
}
