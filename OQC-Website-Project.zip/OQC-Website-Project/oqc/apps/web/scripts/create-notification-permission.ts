import { mkdir, writeFile } from "node:fs/promises";
import { v7 } from "uuid";
const directory = "prisma/migrations/202610110004_notification_permissions";
await mkdir(directory);
let sql =
  "-- Staff can read only their own internal notifications. System constants only.\n";
for (const role of ["CONTENT_EDITOR", "ADMISSIONS", "ACADEMIC_COORDINATOR"])
  sql += `INSERT INTO "RolePermission" (id,"roleId","permissionId","updatedAt") SELECT '${v7()}',r.id,p.id,CURRENT_TIMESTAMP FROM "Role" r CROSS JOIN "Permission" p WHERE r.key='${role}' AND p.key='notifications:read' ON CONFLICT ("roleId","permissionId") DO NOTHING;\n`;
await writeFile(directory + "/migration.sql", sql, { flag: "wx" });
