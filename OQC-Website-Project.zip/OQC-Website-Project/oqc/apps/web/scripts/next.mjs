import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { mkdir, chmod } from "node:fs/promises";
import { resolve } from "node:path";
const cache = resolve(".runtime/swc-cache");
await mkdir(cache, { recursive: true });
await chmod(cache, 0o700);
const require = createRequire(import.meta.url);
const child = spawn(
  process.execPath,
  [require.resolve("next/dist/bin/next"), ...process.argv.slice(2)],
  {
    stdio: "inherit",
    env: {
      ...process.env,
      SWC_NATIVE_BINDING_CACHE: cache,
      ...(process.argv[2] === "dev" && !process.env.NEXT_DIST_DIR
        ? { NEXT_DIST_DIR: ".next-dev" }
        : {}),
    },
  },
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => child.kill(signal));
child.on("exit", (code) => {
  process.exitCode = code ?? 1;
});
