import { readdir, readFile, writeFile } from "node:fs/promises";
import { resolve, relative } from "node:path";
import ts from "typescript";
import { z } from "zod";
import { adminSchemas, statusSchema } from "../src/lib/validation/admin";
import { loginSchema } from "../src/lib/validation/auth";
import { trialSchema, contactSchema } from "../src/lib/validation/admissions";
import {
  timezone,
  email,
  password,
  paginationSchema,
  currencySchema,
} from "../src/lib/validation/common";
import { sectionsSchema } from "../src/lib/validation/content";
import { courseModulesSchema } from "../src/lib/validation/course-modules";
import { pricesSchema } from "../src/lib/validation/prices";
import { enrollmentSchema } from "../src/lib/validation/enrollment";
import { consentSchema } from "../src/lib/validation/consent";
import { contactWorkflowSchema } from "../src/lib/validation/contact-workflow";
import { attendanceSchema } from "../src/lib/validation/attendance";
import { invoiceVoidSchema } from "../src/lib/validation/invoice-void";
import { restoreRevisionSchema } from "../src/lib/validation/revision";
import {
  schedulePublicationSchema,
  cancelPublicationSchema,
} from "../src/lib/validation/publication-schedule";
import {
  rescheduleSchema,
  sessionStatusSchema,
} from "../src/lib/validation/class-session";
import { roles } from "../src/lib/rbac/policy";
import { trialStates } from "../src/lib/admissions/state-machine";

const root = resolve("src/app/api");
const bindings: Record<string, unknown> = {
  z,
  adminSchemas,
  statusSchema,
  loginSchema,
  trialSchema,
  contactSchema,
  timezone,
  email,
  password,
  paginationSchema,
  currencySchema,
  sectionsSchema,
  courseModulesSchema,
  pricesSchema,
  enrollmentSchema,
  consentSchema,
  contactWorkflowSchema,
  attendanceSchema,
  invoiceVoidSchema,
  restoreRevisionSchema,
  schedulePublicationSchema,
  cancelPublicationSchema,
  rescheduleSchema,
  sessionStatusSchema,
  roles,
  trialStates,
};
const methods = new Set([
  "string",
  "number",
  "boolean",
  "object",
  "array",
  "enum",
  "literal",
  "union",
  "unknown",
  "uuid",
  "email",
  "url",
  "datetime",
  "date",
  "min",
  "max",
  "length",
  "int",
  "positive",
  "nonnegative",
  "regex",
  "trim",
  "toLowerCase",
  "strict",
  "optional",
  "nullable",
  "default",
  "partial",
  "extend",
  "omit",
]);
const omittedRefinements = new Set(["refine", "superRefine", "transform"]);
function decode(
  node: ts.Expression,
  locals: Map<string, ts.Expression>,
  stack = new Set<string>(),
): unknown {
  if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node))
    return node.text;
  if (ts.isNumericLiteral(node)) return Number(node.text);
  if (node.kind === ts.SyntaxKind.TrueKeyword) return true;
  if (node.kind === ts.SyntaxKind.FalseKeyword) return false;
  if (node.kind === ts.SyntaxKind.NullKeyword) return null;
  if (ts.isRegularExpressionLiteral(node)) {
    const end = node.text.lastIndexOf("/");
    return new RegExp(node.text.slice(1, end), node.text.slice(end + 1));
  }
  if (ts.isAsExpression(node) || ts.isParenthesizedExpression(node))
    return decode(node.expression, locals, stack);
  if (ts.isIdentifier(node)) {
    if (node.text === "undefined") return undefined;
    if (Object.hasOwn(bindings, node.text)) return bindings[node.text];
    if (stack.has(node.text))
      throw new Error("Cyclic schema binding: " + node.text);
    const initializer = locals.get(node.text);
    if (!initializer) throw new Error("Unknown schema binding: " + node.text);
    return decode(initializer, locals, new Set([...stack, node.text]));
  }
  if (ts.isArrayLiteralExpression(node))
    return node.elements.map((item) =>
      decode(item as ts.Expression, locals, stack),
    );
  if (ts.isObjectLiteralExpression(node)) {
    const result: Record<string, unknown> = {};
    for (const item of node.properties) {
      if (ts.isShorthandPropertyAssignment(item)) {
        result[item.name.text] = decode(item.name, locals, stack);
        continue;
      }
      if (!ts.isPropertyAssignment(item))
        throw new Error("Unsupported schema object member: " + item.getText());
      result[item.name.getText().replace(/^['"]|['"]$/g, "")] = decode(
        item.initializer,
        locals,
        stack,
      );
    }
    return result;
  }
  if (ts.isPropertyAccessExpression(node)) {
    const name = node.name.text;
    if (["constructor", "prototype", "__proto__"].includes(name))
      throw new Error("Forbidden schema property");
    const owner = decode(node.expression, locals, stack) as Record<
      string,
      unknown
    >;
    return owner[name];
  }
  if (
    ts.isCallExpression(node) &&
    ts.isPropertyAccessExpression(node.expression)
  ) {
    const call = node.expression,
      name = call.name.text;
    const owner = decode(call.expression, locals, stack) as Record<
      string,
      unknown
    >;
    if (omittedRefinements.has(name)) return owner;
    if (!methods.has(name))
      throw new Error("Unsupported schema method: " + name);
    const method = owner[name];
    if (typeof method !== "function")
      throw new Error("Missing schema constructor: " + name);
    return Reflect.apply(
      method,
      owner,
      node.arguments.map((argument) => decode(argument, locals, stack)),
    );
  }
  throw new Error(
    "Unsupported declarative schema expression: " +
      node.getText().slice(0, 100),
  );
}
async function files(directory: string): Promise<string[]> {
  const result: string[] = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) result.push(...(await files(path)));
    else if (entry.name === "route.ts") result.push(path);
  }
  return result.sort();
}
type Json = Record<string, unknown>;
const schemas: Record<string, Json> = {};
function embed(schema: z.ZodType, name: string) {
  const json = z.toJSONSchema(schema, { io: "input" }) as Json;
  delete json.$schema;
  function rewrite(value: unknown) {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach(rewrite);
      return;
    }
    const item = value as Json;
    if (typeof item.$ref === "string" && item.$ref.startsWith("#"))
      item.$ref = "#/components/schemas/" + name + item.$ref.slice(1);
    Object.values(item).forEach(rewrite);
  }
  rewrite(json);
  schemas[name] = json;
  return { $ref: "#/components/schemas/" + name };
}
const errorRef = embed(
  z.object({
    error: z.object({
      code: z.string(),
      message: z.string(),
      requestId: z.string(),
      details: z.unknown().optional(),
    }),
  }),
  "Error",
);
const headers = {
  "X-Request-Id": {
    schema: { type: "string" },
    description:
      "Support correlation identifier; generated API errors include it.",
  },
};
const paths: Record<string, Json> = {};
const inventory: string[] = [];
let operationCount = 0;
for (const file of await files(root)) {
  const source = await readFile(file, "utf8");
  const tree = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
  const locals = new Map<string, ts.Expression>();
  function collect(node: ts.Node) {
    if (
      ts.isVariableDeclaration(node) &&
      ts.isIdentifier(node.name) &&
      node.initializer
    )
      locals.set(node.name.text, node.initializer);
    ts.forEachChild(node, collect);
  }
  collect(tree);
  const path =
    "/api/" +
    relative(root, file)
      .replace(/\/route\.ts$/, "")
      .replace(/\[([^\]]+)\]/g, "{$1}");
  const item: Json = {};
  for (const handler of tree.statements.filter(ts.isFunctionDeclaration)) {
    const verb = handler.name?.text ?? "";
    if (
      !["GET", "POST", "PUT", "PATCH", "DELETE"].includes(verb) ||
      !handler.modifiers?.some(
        (modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword,
      )
    )
      continue;
    operationCount++;
    const text = handler.getText(tree),
      operation: Json = {};
    const guarded =
      /requirePermission\(|requireMutation\(|requireSessionMutation\(|currentSession\(/.test(
        text,
      );
    const mutationGuard = /requireMutation\(|requireSessionMutation\(/.test(
      text,
    );
    const recent = /requireRecentAuth\(/.test(text);
    operation.summary = verb + " " + path;
    operation.operationId =
      verb.toLowerCase() + path.replace(/[^a-zA-Z0-9]+/g, "_");
    operation.tags = [
      path.includes("/admin/")
        ? "Staff"
        : path.includes("/auth/")
          ? "Identity"
          : path.includes("/public/")
            ? "Public"
            : "Platform",
    ];
    operation.security = guarded
      ? [mutationGuard ? { session: [], csrf: [] } : { session: [] }]
      : [];
    operation.description =
      "Generated from " +
      relative(resolve("../.."), file) +
      ". " +
      (recent
        ? "Recent password/MFA verification is required (five minutes). "
        : "") +
      "Database eligibility, state transitions, role restrictions, bot verification and refinements are enforced by the application; JSON Schema alone cannot express these checks.";
    const permissions = [
      ...text.matchAll(
        /require(?:Permission|Mutation)\([^;]*?["']([a-z-]+:[a-z-]+)["']/g,
      ),
    ].map((match) => match[1]);
    if (permissions.length)
      operation["x-permissions-observed"] = [...new Set(permissions)];
    const parameters: Json[] = [...path.matchAll(/\{([^}]+)\}/g)].map(
      (match) => ({
        name: match[1],
        in: "path",
        required: true,
        schema:
          match[1] === "id"
            ? { type: "string", format: "uuid" }
            : { type: "string" },
      }),
    );
    if (/requireOrigin\(/.test(text) || mutationGuard)
      parameters.push({
        name: "Origin",
        in: "header",
        required: true,
        schema: { type: "string", format: "uri" },
        description: "Must exactly match the configured APP_URL origin.",
      });
    if (path.endsWith("/trial-applications"))
      parameters.push({
        name: "Idempotency-Key",
        in: "header",
        required: true,
        schema: {
          type: "string",
          minLength: 16,
          maxLength: 100,
          pattern: "^[-a-zA-Z0-9_]{16,100}$",
        },
      });
    if (parameters.length) operation.parameters = parameters;
    const bodies: z.ZodType[] = [];
    function findBodies(node: ts.Node) {
      if (
        ts.isCallExpression(node) &&
        ts.isIdentifier(node.expression) &&
        node.expression.text === "parseBody"
      ) {
        if (!node.arguments[1])
          throw new Error("Missing parseBody schema: " + path);
        if (path === "/api/v1/admin/{resource}" && verb === "POST")
          bodies.push(z.union(Object.values(adminSchemas)));
        else if (path === "/api/v1/admin/{resource}/{id}" && verb === "PATCH")
          bodies.push(
            z.union(
              Object.values(adminSchemas).map((schema) =>
                schema
                  .partial()
                  .extend({ version: z.number().int().positive().optional() }),
              ),
            ),
          );
        else bodies.push(decode(node.arguments[1], locals) as z.ZodType);
      }
      ts.forEachChild(node, findBodies);
    }
    findBodies(handler);
    if (bodies.length) {
      const schema = bodies.length === 1 ? bodies[0] : z.union(bodies);
      const name = String(operation.operationId) + "Request";
      operation.requestBody = {
        required: true,
        content: { "application/json": { schema: embed(schema, name) } },
      };
    } else if (path === "/api/v1/admin/media" && verb === "POST") {
      operation.requestBody = {
        required: true,
        content: {
          "multipart/form-data": {
            schema: {
              type: "object",
              required: ["file", "altText"],
              properties: {
                file: {
                  type: "string",
                  format: "binary",
                  description:
                    "JPEG/PNG/WebP; maximum 4 MiB and 16 million pixels. Reencoded to strip metadata.",
                },
                altText: { type: "string", minLength: 2, maxLength: 300 },
              },
            },
          },
        },
      };
    }
    const success = /status:\s*201/.test(text) ? "201" : "200";
    const contentType = path.endsWith("/pdf")
      ? "application/pdf"
      : path.includes("/exports/")
        ? "text/csv"
        : path.includes("/media/{id}/file")
          ? "image/webp"
          : "application/json";
    const responseSchema =
      contentType === "application/json"
        ? {
            type: "object",
            description:
              "Response DTO formalization is pending; consult the route/service and executed integration/browser tests.",
          }
        : {
            type: "string",
            ...(["image/webp", "application/pdf"].includes(contentType)
              ? { format: "binary" }
              : {}),
          };
    operation.responses = {
      [success]: {
        description:
          "Successful response; endpoint-specific business results remain documented by implementation and tests.",
        headers,
        content: { [contentType]: { schema: responseSchema } },
      },
      ...Object.fromEntries(
        ["400", "401", "403", "404", "409", "413", "429", "500", "503"].map(
          (status) => [
            status,
            {
              description:
                "May be returned by validation, authentication, authorization, state/availability checks or unavailable dependencies.",
              headers,
              content: { "application/json": { schema: errorRef } },
            },
          ],
        ),
      ),
    };
    operation["x-contract-status"] =
      "request-structure-documented; response-DTO-review-pending";
    item[verb.toLowerCase()] = operation;
    inventory.push(
      `| ${verb} | \`${path}\` | ${guarded ? (mutationGuard ? "Session + CSRF + Origin" : "Session") : "Public / token exchange"}${recent ? "; recent reauthentication" : ""} | ${bodies.length ? "Generated JSON Schema" : operation.requestBody ? "Multipart image" : "No parsed request body"} |`,
    );
  }
  paths[path] = item;
}
const document = {
  openapi: "3.1.0",
  info: {
    title: "OQC API implementation inventory",
    version: "0.1.0",
    description:
      "Generated route inventory and structural request contracts. Full response DTOs and contract tests remain release work. Rich-text preprocessing, semantic refinements, current consent versions and database/RBAC rules require runtime validation.",
  },
  servers: [{ url: "/" }],
  paths,
  components: {
    securitySchemes: {
      session: {
        type: "apiKey",
        in: "cookie",
        name: "__Host-oqc-session",
        description:
          "Production cookie; local development uses oqc-session. Secure, HttpOnly and SameSite=Lax; idle 30 minutes, absolute 12 hours.",
      },
      csrf: {
        type: "apiKey",
        in: "header",
        name: "X-CSRF-Token",
        description:
          "Restore the token using authenticated GET /api/v1/auth/session. Mutation Origin must match APP_URL.",
      },
    },
    schemas,
  },
};
function verifyReferences(value: unknown) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach(verifyReferences);
    return;
  }
  const object = value as Json;
  if (typeof object.$ref === "string") {
    let target: unknown = document;
    for (const part of object.$ref.slice(2).split("/"))
      target = (target as Json)?.[part.replace(/~1/g, "/").replace(/~0/g, "~")];
    if (target === undefined)
      throw new Error("Unresolved JSON Schema reference: " + object.$ref);
  }
  Object.values(object).forEach(verifyReferences);
}
verifyReferences(document);
await writeFile(
  resolve("../../docs/openapi.json"),
  JSON.stringify(document, null, 2) + "\n",
);
await writeFile(
  resolve("../../docs/API_REFERENCE.md"),
  "# API implementation inventory\n\nGenerated with `pnpm docs:api` from actual route handlers and Zod constructors. Every local schema reference is checked. No application source is evaluated to extract schemas. Custom refinements/transforms are runtime rules, and response DTO formalization remains pending. This inventory does not certify complete v6 API coverage.\n\n| Method | Path | Authentication | Body |\n|---|---|---|---|\n" +
    inventory.join("\n") +
    "\n\nPublic mutations validate the configured Origin. Staff mutations require Origin, session and CSRF; sensitive operations also require recent password/MFA verification. The public assistant remains disabled. Media streams require staff authorization; CSV exports enforce role and date scopes and never activate outbound delivery. Production consent notices must be owner approved.\n",
);
console.log(
  `Generated ${Object.keys(paths).length} route paths, ${operationCount} operations and ${Object.keys(schemas).length} request/error schemas; all local references resolved.`,
);
