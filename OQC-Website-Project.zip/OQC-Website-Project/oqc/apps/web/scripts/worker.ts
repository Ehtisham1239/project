import "dotenv/config";
import { PgBoss } from "pg-boss";
import { drainOutbox } from "../src/server/repositories/outbox";
import { database } from "../src/lib/db";
import { runtimeEnv } from "../src/lib/platform/env";
import { publishDueContent } from "../src/server/services/publication-schedules";
const config = runtimeEnv();
const boss = new PgBoss({
  connectionString: config.DATABASE_URL,
  schema: "pgboss",
});
boss.on("error", () =>
  console.error("Worker queue error; consult restricted operator diagnostics."),
);
await boss.start();
await boss.createQueue("outbox-drain", {
  retryLimit: 5,
  retryDelay: 10,
  retryBackoff: true,
});
await boss.work("outbox-drain", async () => {
  await publishDueContent();
  await drainOutbox();
});
await boss.schedule("outbox-drain", "* * * * *");
await boss.send(
  "outbox-drain",
  {},
  { singletonKey: "periodic-drain", singletonSeconds: 60 },
);
console.log(
  "Internal notification worker running. Outbound delivery disabled.",
);
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  await boss.stop({ graceful: true, timeout: 15000 });
  await database().$disconnect();
  process.exit(0);
}
process.once("SIGINT", () => void stop());
process.once("SIGTERM", () => void stop());
