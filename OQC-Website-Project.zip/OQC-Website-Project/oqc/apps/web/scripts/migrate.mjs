import "dotenv/config";
import { loadEngine, filters, shutdownEngine } from "./schema-engine.mjs";
import { readdir, readFile } from "node:fs/promises";
import { resolve } from "node:path";
const baseDir = resolve("prisma/migrations");
const directories = (await readdir(baseDir, { withFileTypes: true }))
  .filter((x) => x.isDirectory())
  .sort((a, b) => a.name.localeCompare(b.name));
const migrationsList = {
  baseDir,
  lockfile: {
    path: "migration_lock.toml",
    content: await readFile(baseDir + "/migration_lock.toml", "utf8"),
  },
  shadowDbInitScript: "",
  migrationDirectories: await Promise.all(
    directories.map(async (entry) => ({
      path: entry.name,
      migrationFile: {
        path: "migration.sql",
        content: {
          tag: "ok",
          value: await readFile(
            `${baseDir}/${entry.name}/migration.sql`,
            "utf8",
          ),
        },
      },
    })),
  ),
};
const engine = await loadEngine();
try {
  const diagnosis = await engine.diagnoseMigrationHistory({
    migrationsList,
    optInToShadowDatabase: false,
    filters,
  });
  if (
    diagnosis.editedMigrationNames.length ||
    diagnosis.failedMigrationNames.length
  )
    throw new Error("Migration integrity or failed migration requires review");
  if (diagnosis.history && diagnosis.history.diagnostic !== "databaseIsBehind")
    throw new Error("Migration history diverges from repository");
  const result = await engine.applyMigrations({ migrationsList, filters });
  console.log(
    "Applied migrations:",
    result.appliedMigrationNames.length
      ? result.appliedMigrationNames.join(", ")
      : "none; database current",
  );
} finally {
  await shutdownEngine(engine);
}

process.exit(0);
