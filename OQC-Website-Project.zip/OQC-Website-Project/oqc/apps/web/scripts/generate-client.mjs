import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { getGenerators } = require("@prisma/internals");
const { defaultRegistry } = require("@prisma/client-generator-registry");
const generators = await getGenerators({
  schemaPath: "prisma/schema.prisma",
  registry: defaultRegistry.toInternal(),
  skipDownload: true,
  cliCommand: "oqc:generate",
});
try {
  for (const generator of generators) await generator.generate();
  console.log("Prisma client generated using verified npm/WASM toolchain");
} finally {
  for (const generator of generators) generator.stop();
}
