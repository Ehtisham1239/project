import type { NextConfig } from "next";
import { resolve } from "node:path";
const config: NextConfig = {
  distDir: process.env.NEXT_DIST_DIR ?? ".next",
  output: process.env.NEXT_DIST_DIR === ".next-e2e" ? undefined : "standalone",
  poweredByHeader: false,
  serverExternalPackages: ["pdfkit"],
  devIndicators: false,
  experimental: { cpus: 2, authInterrupts: true },
  turbopack: { resolveAlias: { "next-intl/config": "./src/i18n/request.ts" } },
  webpack(config) {
    config.resolve.alias["next-intl/config"] = resolve("src/i18n/request.ts");
    return config;
  },
};
export default config;
