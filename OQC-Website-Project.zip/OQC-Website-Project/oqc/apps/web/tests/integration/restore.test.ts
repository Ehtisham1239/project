import { newId } from "@/lib/platform/ids";
import { it, expect } from "vitest";
import { execFileSync } from "node:child_process";
import { randomBytes, createCipheriv, createDecipheriv } from "node:crypto";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve, join } from "node:path";
import pg from "pg";
it("encrypted PostgreSQL backup restores its schema, constraints and system grants", async () => {
  const suffix = randomBytes(8).toString("hex"),
    source = "oqc_backup_test_" + suffix,
    target = "oqc_restore_test_" + suffix;
  const pool = new pg.Pool({
    connectionString: "postgresql://oqc:oqc@localhost:5432/postgres",
  });
  const directory = await mkdtemp(join(tmpdir(), "oqc-backup-"));
  try {
    await pool.query(`CREATE DATABASE "${source}"`);
    await pool.query(`CREATE DATABASE "${target}"`);
    execFileSync(process.execPath, ["scripts/migrate.mjs"], {
      env: {
        ...process.env,
        DATABASE_URL: `postgresql://oqc:oqc@localhost:5432/${source}`,
      },
      stdio: "pipe",
      timeout: 20000,
    });
    const sourceDb = new pg.Pool({
      connectionString: `postgresql://oqc:oqc@localhost:5432/${source}`,
    });
    try {
      await sourceDb.query(
        'INSERT INTO "Course" (id,slug,title,summary,"ageGroup",level,"updatedAt") VALUES ($1,$2,$3,$4,$5,$6,CURRENT_TIMESTAMP)',
        [
          newId(),
          "synthetic-restore-course",
          "Synthetic restore course",
          "Ephemeral backup verification only",
          "ADULT",
          "BEGINNER",
        ],
      );
    } finally {
      await sourceDb.end();
    }
    const container =
      process.env.PG_CONTAINER_ID ??
      execFileSync("docker", ["compose", "ps", "-q", "postgres"], {
        cwd: resolve("../.."),
        encoding: "utf8",
      }).trim();
    if (!container)
      throw new Error("PostgreSQL container is required for the restore drill");
    const dump = execFileSync(
      "docker",
      [
        "exec",
        container,
        "pg_dump",
        "-U",
        "oqc",
        "-d",
        source,
        "--format=custom",
        "--no-owner",
      ],
      { maxBuffer: 16 * 1024 * 1024 },
    );
    const key = randomBytes(32),
      iv = randomBytes(12),
      cipher = createCipheriv("aes-256-gcm", key, iv),
      encrypted = Buffer.concat([cipher.update(dump), cipher.final()]),
      tag = cipher.getAuthTag();
    const path = join(directory, "backup.aesgcm");
    await writeFile(path, Buffer.concat([iv, tag, encrypted]), {
      mode: 0o600,
      flag: "wx",
    });
    const stored = await readFile(path);
    const decipher = createDecipheriv(
      "aes-256-gcm",
      key,
      stored.subarray(0, 12),
    );
    decipher.setAuthTag(stored.subarray(12, 28));
    const decrypted = Buffer.concat([
      decipher.update(stored.subarray(28)),
      decipher.final(),
    ]);
    expect(decrypted.equals(dump)).toBe(true);
    execFileSync(
      "docker",
      [
        "exec",
        "-i",
        container,
        "pg_restore",
        "-U",
        "oqc",
        "-d",
        target,
        "--no-owner",
        "--exit-on-error",
      ],
      { input: decrypted, maxBuffer: 1024 * 1024, timeout: 20000 },
    );
    const restored = new pg.Pool({
      connectionString: `postgresql://oqc:oqc@localhost:5432/${target}`,
    });
    try {
      expect((await restored.query('SELECT title FROM "Course"')).rows).toEqual(
        [{ title: "Synthetic restore course" }],
      );
      expect(
        Number(
          (await restored.query('SELECT COUNT(*) FROM "Role"')).rows[0].count,
        ),
      ).toBe(5);
      expect(
        Number(
          (
            await restored.query(
              "SELECT COUNT(*) FROM _prisma_migrations WHERE finished_at IS NOT NULL",
            )
          ).rows[0].count,
        ),
      ).toBe(4);
      expect(
        Number(
          (await restored.query('SELECT COUNT(*) FROM "User"')).rows[0].count,
        ),
      ).toBe(0);
      expect(
        (
          await restored.query(
            "SELECT conname FROM pg_constraint WHERE contype='x'",
          )
        ).rows.length,
      ).toBeGreaterThanOrEqual(2);
      expect(
        Number(
          (await restored.query('SELECT COUNT(*) FROM "RolePermission"'))
            .rows[0].count,
        ),
      ).toBeGreaterThan(100);
    } finally {
      await restored.end();
    }
    const tampered = createDecipheriv("aes-256-gcm", key, iv);
    tampered.setAuthTag(Buffer.alloc(16));
    expect(() => {
      tampered.update(encrypted);
      tampered.final();
    }).toThrow();
  } finally {
    await pool.query(`DROP DATABASE IF EXISTS "${source}" WITH (FORCE)`);
    await pool.query(`DROP DATABASE IF EXISTS "${target}" WITH (FORCE)`);
    await pool.end();
    await rm(directory, { recursive: true, force: true });
  }
}, 60000);
