import { drainOutbox } from "@/server/repositories/outbox";
import { classCalendar } from "@/server/services/calendar";
import {
  rescheduleSession,
  changeSessionStatus,
} from "@/server/services/class-sessions";
import { beforeAll, afterAll, it, expect, vi } from "vitest";
import pg from "pg";
import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { database } from "@/lib/db";
import { newId } from "@/lib/platform/ids";
import {
  bootstrap,
  beginMfaEnrollment,
  completeMfaEnrollment,
  login,
} from "@/server/services/identity";
import {
  createRecord,
  publishRecord,
  updateRecord,
} from "@/server/services/admin";
import {
  persistTrial,
  persistContact,
  changeTrialStatus,
  submissionHash,
} from "@/server/repositories/admissions";
import {
  assignTrial,
  convertTrial,
  createSchedule,
  markAttendance,
} from "@/server/services/academics";
import { issueInvoice, recordPayment } from "@/server/services/finance";
import { launchReadiness, replaceSections } from "@/server/services/content";
import { permissionMatrix, type RoleKey } from "@/lib/rbac/policy";
import { publishedCourses } from "@/server/services/public";
import { generate } from "otplib";
import { hashPassword, hashToken, sessionCsrf } from "@/lib/auth/crypto";
import { sessionByToken, validateCsrf } from "@/server/repositories/identity";
import { trialSchema, contactSchema } from "@/lib/validation/admissions";
const dbName = "oqc_test_" + randomBytes(8).toString("hex");
const control = new pg.Pool({
  connectionString: "postgresql://oqc:oqc@localhost:5432/postgres",
});
let ownerId = "",
  courseId = "",
  teacherId = "",
  setupToken = "";
const userEmail = () =>
  `synthetic-${randomBytes(5).toString("hex")}@test.invalid`;
const password = "Synthetic test passphrase only";
beforeAll(async () => {
  await control.query(`CREATE DATABASE "${dbName}"`);
  process.env.DATABASE_URL = `postgresql://oqc:oqc@localhost:5432/${dbName}`;
  process.env.AUTH_SECRET = randomBytes(48).toString("base64url");
  process.env.BOOTSTRAP_TOKEN = randomBytes(48).toString("base64url");
  execFileSync(process.execPath, ["scripts/migrate.mjs"], {
    env: process.env,
    stdio: "pipe",
    timeout: 20000,
  });
}, 30000);
afterAll(async () => {
  await database().$disconnect();
  await control.query(`DROP DATABASE "${dbName}" WITH (FORCE)`);
  await control.end();
});
it("starts with only system constants and no business rows", async () => {
  expect(await database().role.count()).toBe(5);
  expect(await database().permission.count()).toBeGreaterThan(50);
  for (const count of await Promise.all([
    database().user.count(),
    database().course.count(),
    database().trialApplication.count(),
    database().teacher.count(),
  ]))
    expect(count).toBe(0);
});
it("bootstrap creates an inactive admin and refuses repeats", async () => {
  const email = userEmail();
  setupToken = (
    await bootstrap({ email, name: "Synthetic Operator", password })
  ).setupToken;
  const user = await database().user.findUniqueOrThrow({ where: { email } });
  ownerId = user.id;
  expect(user.isActive).toBe(false);
  expect(user.mustEnrollMfa).toBe(true);
  await expect(
    bootstrap({ email: userEmail(), name: "Synthetic Operator 2", password }),
  ).rejects.toMatchObject({ code: "BOOTSTRAP_COMPLETE" });
  expect(
    await database().auditLog.count({ where: { action: "system.bootstrap" } }),
  ).toBe(1);
});
it("MFA enrollment encrypts secrets, hashes backup codes, and refuses reuse", async () => {
  const setup = await beginMfaEnrollment(setupToken);
  expect(
    (await database().user.findUniqueOrThrow({ where: { id: ownerId } }))
      .mfaSecretEnc,
  ).not.toBe(setup.secret);
  const code = await generate({ secret: setup.secret });
  expect(
    (await completeMfaEnrollment(setupToken, code)).backupCodes,
  ).toHaveLength(10);
  expect(
    await database().mfaBackupCode.count({ where: { userId: ownerId } }),
  ).toBe(10);
  await expect(completeMfaEnrollment(setupToken, code)).rejects.toMatchObject({
    status: 401,
  });
  expect(
    (await database().user.findUniqueOrThrow({ where: { id: ownerId } }))
      .isActive,
  ).toBe(true);
});
it("password-only privileged login fails", async () => {
  const user = await database().user.findUniqueOrThrow({
    where: { id: ownerId },
  });
  await expect(login(user.email, password)).rejects.toMatchObject({
    status: 401,
  });
});
it("sessions store hashes and expire on inactivity", async () => {
  const role = await database().role.findUniqueOrThrow({
    where: { key: "CONTENT_EDITOR" },
  });
  const user = await database().user.create({
    data: {
      id: newId(),
      email: userEmail(),
      name: "Synthetic Editor",
      passwordHash: await hashPassword(password),
      roleId: role.id,
      isActive: true,
      mustEnrollMfa: false,
    },
  });
  const session = await login(user.email, password);
  expect((await sessionByToken(session.token))?.userId).toBe(user.id);
  const stored = await database().session.findUniqueOrThrow({
    where: { tokenHash: hashToken(session.token) },
  });
  expect(stored.tokenHash).not.toBe(session.token);
  expect(sessionCsrf(session.token)).toBe(session.csrf);
  await expect(
    validateCsrf(session.token, session.csrf),
  ).resolves.toBeUndefined();
  await expect(validateCsrf(session.token, "wrong")).rejects.toMatchObject({
    status: 403,
  });
  await database().session.update({
    where: { id: stored.id },
    data: { lastSeenAt: new Date(Date.now() - 31 * 60000) },
  });
  expect(await sessionByToken(session.token)).toBeNull();
});
it("publication is audited and exposes only approved courses", async () => {
  courseId = (
    await createRecord(
      "courses",
      {
        slug: "synthetic-test-course",
        title: "Synthetic Test Course",
        summary: "Only in an ephemeral test database",
        ageGroup: "ADULT",
        level: "BEGINNER",
      },
      ownerId,
    )
  ).id;
  expect(await publishedCourses()).toHaveLength(0);
  await publishRecord("courses", courseId, "SUBMITTED", 1, ownerId);
  await publishRecord("courses", courseId, "APPROVED", 2, ownerId);
  await publishRecord("courses", courseId, "PUBLISHED", 3, ownerId);
  expect(await publishedCourses()).toHaveLength(1);
  expect(
    await database().contentRevision.count({ where: { entityId: courseId } }),
  ).toBe(3);
});
it("stale edits fail and slug changes create redirects", async () => {
  await expect(
    updateRecord("courses", courseId, { title: "Stale" }, ownerId, 1),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  await updateRecord(
    "courses",
    courseId,
    { slug: "synthetic-updated" },
    ownerId,
    4,
  );
  expect(await publishedCourses()).toHaveLength(0);
  expect(
    (await database().course.findUniqueOrThrow({ where: { id: courseId } }))
      .status,
  ).toBe("DRAFT");
  await publishRecord("courses", courseId, "SUBMITTED", 5, ownerId);
  await publishRecord("courses", courseId, "APPROVED", 6, ownerId);
  await publishRecord("courses", courseId, "PUBLISHED", 7, ownerId);
  expect(
    await database().redirect.findUnique({
      where: { fromPath: "/courses/synthetic-test-course" },
    }),
  ).toMatchObject({ toPath: "/courses/synthetic-updated" });
});
function input() {
  return trialSchema.parse({
    learnerName: "Synthetic Learner",
    email: userEmail(),
    phoneE164: "+441234567890",
    country: "GB",
    timezone: "Europe/London",
    ageBand: "18_PLUS",
    courseId,
    level: "BEGINNER",
    teacherGenderPref: "ANY",
    teachingLanguage: "ENGLISH",
    availableSlots: [{ weekday: 1, startMinute: 600, endMinute: 660 }],
    consentGiven: true,
    consentTextVersion: "v1-draft",
    website: "",
    startedAt: Date.now() - 5000,
    botToken: "development-bypass",
  });
}
it("concurrent idempotent submissions create one application/history/audit/outbox", async () => {
  const data = input(),
    key = newId(),
    hash = submissionHash(data);
  const results = await Promise.all([
    persistTrial(data, key, hash, "synthetic-ip"),
    persistTrial(data, key, hash, "synthetic-ip"),
  ]);
  expect(results[0]).toEqual(results[1]);
  expect(await database().trialApplication.count()).toBe(1);
  expect(await database().trialHistory.count()).toBe(1);
  expect(
    await database().auditLog.count({ where: { action: "trial.submitted" } }),
  ).toBe(1);
  expect(
    await database().outboxEvent.count({ where: { kind: "trial.submitted" } }),
  ).toBe(1);
  await expect(
    persistTrial(
      { ...data, learnerName: "Changed" },
      key,
      "other-hash",
      "synthetic-ip",
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
});
it("duplicates receive the same confirmation shape with an internal link", async () => {
  const data = input(),
    key = newId();
  const result = await persistTrial(
    data,
    key,
    submissionHash(data),
    "synthetic-ip",
  );
  expect(result).not.toHaveProperty("duplicateOfId");
  expect(
    (
      await database().trialApplication.findUniqueOrThrow({
        where: { idempotencyKey: key },
      })
    ).duplicateOfId,
  ).not.toBeNull();
});
it("trial transitions enforce scheduling preconditions", async () => {
  const trial = await database().trialApplication.findFirstOrThrow();
  await expect(
    changeTrialStatus(trial.id, "ENROLLED", ownerId, trial.version),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  await changeTrialStatus(trial.id, "REVIEWED", ownerId, trial.version);
  await expect(
    changeTrialStatus(trial.id, "SCHEDULED", ownerId, trial.version + 1),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
});
it("contacts are durable, audited, and placed in the outbox", async () => {
  const data = contactSchema.parse({
    name: "Synthetic Contact",
    email: userEmail(),
    subject: "Synthetic question",
    message: "Synthetic test message only",
    consentGiven: true,
    consentTextVersion: "v1-draft",
    website: "",
    startedAt: Date.now() - 5000,
    botToken: "development-bypass",
  });
  await persistContact(data, "synthetic-ip");
  expect(await database().contactMessage.count()).toBe(1);
  expect(
    await database().auditLog.count({ where: { action: "contact.received" } }),
  ).toBe(1);
});
it("database rejects testimonial publication without consent", async () => {
  await expect(
    database().testimonial.create({
      data: {
        id: newId(),
        name: "Synthetic Statement",
        role: "Synthetic",
        country: "GB",
        quote: "Synthetic test quote only",
        status: "PUBLISHED",
      },
    }),
  ).rejects.toThrow();
});
it("database rejects overlapping teacher sessions and permits adjacency", async () => {
  teacherId = (
    await createRecord(
      "teachers",
      {
        slug: "synthetic-teacher",
        displayName: "Synthetic Test Teacher",
        gender: "FEMALE",
        bio: "Synthetic biography in this disposable database",
        languages: ["English"],
      },
      ownerId,
    )
  ).id;
  const trial = await database().trialApplication.findFirstOrThrow();
  const session = {
    id: newId(),
    teacherId,
    trialId: trial.id,
    kind: "TRIAL",
    startsAtUtc: new Date("2030-01-01T10:00:00Z"),
    endsAtUtc: new Date("2030-01-01T10:30:00Z"),
  };
  await database().classSession.create({ data: session });
  await expect(
    database().classSession.create({
      data: {
        ...session,
        id: newId(),
        startsAtUtc: new Date("2030-01-01T10:15:00Z"),
      },
    }),
  ).rejects.toThrow();
  await database().classSession.create({
    data: {
      ...session,
      id: newId(),
      startsAtUtc: new Date("2030-01-01T10:30:00Z"),
      endsAtUtc: new Date("2030-01-01T11:00:00Z"),
    },
  });
});
it("future sessions block teacher deactivation", async () => {
  await expect(
    updateRecord("teachers", teacherId, { isActive: false }, ownerId, 1),
  ).rejects.toMatchObject({ code: "CONFLICT" });
});
it("audit is append-only", async () => {
  const record = await database().auditLog.findFirstOrThrow();
  await expect(
    database().auditLog.update({
      where: { id: record.id },
      data: { action: "tampered" },
    }),
  ).rejects.toThrow();
  await expect(
    database().auditLog.delete({ where: { id: record.id } }),
  ).rejects.toThrow();
});
it("negative pricing amounts fail database validation", async () => {
  const plan = await createRecord(
    "pricing-plans",
    {
      name: "Synthetic Plan",
      billingPeriod: "MONTHLY",
      classesPerWeek: 1,
      durationMin: 30,
    },
    ownerId,
  );
  await expect(
    database().pricingPlanPrice.create({
      data: { id: newId(), planId: plan.id, currency: "GBP", amountMinor: -1 },
    }),
  ).rejects.toThrow();
});

let enrollmentId = "",
  studentId = "",
  regularSessionId = "",
  invoiceId = "";
it("database role grants match the complete code policy", async () => {
  const roles = await database().role.findMany({
    include: { rolePermission_roleId: { include: { permission: true } } },
  });
  for (const role of roles)
    expect(
      role.rolePermission_roleId.map((x) => x.permission.key).sort(),
    ).toEqual([...permissionMatrix[role.key as RoleKey]].sort());
});
it("assignment and human-confirmed conversion persist the learner and enrollment atomically", async () => {
  const trial = await database().trialApplication.findFirstOrThrow({
    where: { status: "REVIEWED" },
  });
  await database().teacherCourse.create({
    data: { id: newId(), teacherId, courseId },
  });
  await database().teacherAvailability.createMany({
    data: Array.from({ length: 7 }, (_, day) => ({
      id: newId(),
      teacherId,
      weekday: day + 1,
      startMinute: 540,
      endMinute: 1020,
      timezone: "UTC",
    })),
  });
  await assignTrial({
    id: trial.id,
    teacherId,
    startsAtUtc: new Date("2031-02-03T10:00:00Z"),
    durationMin: 30,
    version: trial.version,
    actorId: ownerId,
  });
  await changeTrialStatus(trial.id, "SCHEDULED", ownerId, trial.version + 1);
  await changeTrialStatus(trial.id, "COMPLETED", ownerId, trial.version + 2);
  const result = await convertTrial(trial.id, trial.version + 3, ownerId);
  enrollmentId = result.enrollmentId;
  studentId = result.studentId;
  expect(
    (
      await database().trialApplication.findUniqueOrThrow({
        where: { id: trial.id },
      })
    ).status,
  ).toBe("ENROLLED");
  await expect(
    convertTrial(trial.id, trial.version + 3, ownerId),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  expect(
    await database().student.count({ where: { createdFromTrialId: trial.id } }),
  ).toBe(1);
});
it("recurring schedules persist UTC sessions and reject overlaps without partial rows", async () => {
  const data = {
    enrollmentId,
    weekday: 1,
    startMinute: 660,
    durationMin: 30,
    timezone: "Europe/London",
    from: "2031-02-03",
    to: "2031-02-10",
  };
  const result = await createSchedule(data, ownerId);
  expect(result.sessionCount).toBe(2);
  const sessions = await database().classSession.findMany({
    where: { scheduleId: result.id },
    orderBy: { startsAtUtc: "asc" },
  });
  regularSessionId = sessions[0].id;
  expect(sessions[0].startsAtUtc.toISOString()).toBe(
    "2031-02-03T11:00:00.000Z",
  );
  await expect(createSchedule(data, ownerId)).rejects.toMatchObject({
    code: "SCHEDULE_OVERLAP",
  });
  expect(await database().classSchedule.count()).toBe(1);
});
it("attendance validates the learner assignment and writes audit", async () => {
  await markAttendance(
    { sessionId: regularSessionId, enrollmentId, status: "PRESENT" },
    ownerId,
  );
  expect(await database().attendance.count()).toBe(1);
  await expect(
    markAttendance(
      { sessionId: regularSessionId, enrollmentId: newId(), status: "PRESENT" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
  expect(
    await database().auditLog.count({ where: { action: "attendance.marked" } }),
  ).toBe(1);
});
it("attendance rejects another course enrollment and stale concurrent edits", async () => {
  const db = database();
  const anotherCourse = await db.course.create({
    data: {
      id: newId(),
      title: "Synthetic attendance isolation",
      slug: "synthetic-attendance-isolation",
      summary: "Synthetic isolation case",
      ageGroup: "ALL",
      level: "ALL",
    },
  });
  const other = await db.enrollment.create({
    data: {
      id: newId(),
      studentId,
      teacherId,
      courseId: anotherCourse.id,
      startDate: new Date("2031-02-01"),
    },
  });
  await expect(
    markAttendance(
      { sessionId: regularSessionId, enrollmentId: other.id, status: "ABSENT" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
  const current = await db.attendance.findUniqueOrThrow({
    where: {
      sessionId_enrollmentId: { sessionId: regularSessionId, enrollmentId },
    },
  });
  const session = await db.classSession.findUniqueOrThrow({
    where: { id: regularSessionId },
  });
  const results = await Promise.allSettled(
    ["LATE", "EXCUSED"].map((status) =>
      markAttendance(
        {
          sessionId: regularSessionId,
          enrollmentId,
          status: status as "LATE" | "EXCUSED",
          sessionVersion: session.version,
          expectedUpdatedAt: current.updatedAt.toISOString(),
          note: "Synthetic private note",
        },
        ownerId,
      ),
    ),
  );
  expect(
    results.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(1);
  expect(results.find((result) => result.status === "rejected")).toMatchObject({
    reason: { code: "CONFLICT" },
  });
  const audits = await db.auditLog.findMany({
    where: { action: "attendance.marked", entityId: current.id },
  });
  expect(audits).toHaveLength(2);
  expect(JSON.stringify(audits)).not.toContain("Synthetic private note");
  await db.enrollment.delete({ where: { id: other.id } });
  await db.course.delete({ where: { id: anotherCourse.id } });
});
it("rescheduling enforces availability, overlaps, versions, approved meeting hosts and terminal outcomes", async () => {
  const db = database();
  const original = await db.classSession.findUniqueOrThrow({
    where: { id: regularSessionId },
  });
  const extra = await db.classSession.create({
    data: {
      id: newId(),
      scheduleId: original.scheduleId,
      studentId,
      teacherId,
      startsAtUtc: new Date("2031-02-17T11:00:00Z"),
      endsAtUtc: new Date("2031-02-17T11:30:00Z"),
    },
  });
  const input = {
    version: extra.version,
    startsAtUtc: "2031-02-17T12:00:00Z",
    durationMin: 30,
  };
  await expect(
    rescheduleSession(
      extra.id,
      { ...input, startsAtUtc: "2031-02-17T08:00:00Z" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "TEACHER_UNAVAILABLE" });
  await expect(
    rescheduleSession(
      extra.id,
      { ...input, startsAtUtc: original.startsAtUtc.toISOString() },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "SCHEDULE_OVERLAP" });
  await expect(
    rescheduleSession(
      extra.id,
      { ...input, meetingUrl: "https://meet.synthetic.invalid/class" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "MEETING_HOST_UNAPPROVED" });
  await db.setting.upsert({
    where: { key: "scheduling.meetingDomains" },
    create: {
      id: newId(),
      key: "scheduling.meetingDomains",
      value: ["meet.synthetic.invalid"],
    },
    update: { value: ["meet.synthetic.invalid"] },
  });
  const saved = await rescheduleSession(
    extra.id,
    {
      ...input,
      meetingUrl: "https://meet.synthetic.invalid/class?private=synthetic",
    },
    ownerId,
  );
  expect(saved.version).toBe(extra.version + 1);
  await expect(
    rescheduleSession(extra.id, input, ownerId),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  expect(
    JSON.stringify(
      await db.auditLog.findMany({
        where: { action: "session.rescheduled", entityId: extra.id },
      }),
    ),
  ).not.toContain("private=synthetic");
  expect(
    await db.outboxEvent.count({ where: { kind: "session.rescheduled" } }),
  ).toBe(1);
  await expect(
    changeSessionStatus(
      extra.id,
      { version: saved.version, status: "HELD" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
  const cancelled = await changeSessionStatus(
    extra.id,
    { version: saved.version, status: "CANCELLED" },
    ownerId,
  );
  await expect(
    markAttendance(
      { sessionId: extra.id, enrollmentId, status: "PRESENT" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
  await expect(
    rescheduleSession(
      extra.id,
      { ...input, version: cancelled.version },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  await expect(
    rescheduleSession(
      regularSessionId,
      { ...input, version: original.version },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
});
it("calendar returns chronological bounded windows with names and exact teacher filtering", async () => {
  const db = database();
  const range = { from: "2031-02-03", timezone: "UTC", days: "1", teacherId };
  const calendar = await classCalendar(range);
  expect(
    calendar.sessions.some((session) => session.id === regularSessionId),
  ).toBe(true);
  expect(
    calendar.sessions.every((session) => session.teacher.name.length > 0),
  ).toBe(true);
  expect(calendar.sessions.map((session) => session.startsAtUtc)).toEqual(
    calendar.sessions.map((session) => session.startsAtUtc).sort(),
  );
  const learner = await db.student.findUniqueOrThrow({
    where: { id: studentId },
  });
  expect(
    calendar.sessions.find((session) => session.id === regularSessionId)
      ?.learner?.name,
  ).toBe(learner.fullName);
  expect(JSON.stringify(calendar)).not.toContain("ipHash");
  expect(
    (await classCalendar({ ...range, teacherId: newId() })).sessions,
  ).toHaveLength(0);
  expect(
    (await classCalendar({ ...range, from: "2031-03-01" })).sessions,
  ).toHaveLength(0);
  await expect(classCalendar({ ...range, days: "30" })).rejects.toMatchObject({
    code: "VALIDATION_ERROR",
  });
});
it("active enrollment and student session constraints hold in PostgreSQL", async () => {
  await expect(
    database().enrollment.create({
      data: {
        id: newId(),
        studentId,
        courseId,
        teacherId,
        startDate: new Date(),
      },
    }),
  ).rejects.toThrow();
  const existing = await database().classSession.findUniqueOrThrow({
    where: { id: regularSessionId },
  });
  const teacher = await createRecord(
    "teachers",
    {
      slug: "synthetic-second-teacher",
      displayName: "Synthetic Second Teacher",
      gender: "MALE",
      bio: "Synthetic teacher for database overlap testing",
      languages: ["English"],
    },
    ownerId,
  );
  await expect(
    database().classSession.create({
      data: {
        id: newId(),
        teacherId: teacher.id,
        studentId,
        scheduleId: existing.scheduleId,
        startsAtUtc: new Date(existing.startsAtUtc.getTime() + 60000),
        endsAtUtc: existing.endsAtUtc,
      },
    }),
  ).rejects.toThrow();
});
it("invoice numbering is concurrency safe and payment records cannot overpay", async () => {
  const data = {
    enrollmentId,
    currency: "GBP",
    totalMinor: 1000,
    dueAt: new Date("2031-02-28T00:00:00Z"),
  };
  const invoices = await Promise.all([
    issueInvoice(data, ownerId),
    issueInvoice(data, ownerId),
  ]);
  expect(invoices[0].number).not.toBe(invoices[1].number);
  invoiceId = invoices[0].id;
  await expect(
    recordPayment(
      { invoiceId, amountMinor: 1001, method: "BANK", receivedAt: new Date() },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  await recordPayment(
    { invoiceId, amountMinor: 600, method: "BANK", receivedAt: new Date() },
    ownerId,
  );
  expect(
    (await database().invoice.findUniqueOrThrow({ where: { id: invoiceId } }))
      .status,
  ).toBe("ISSUED");
  await recordPayment(
    { invoiceId, amountMinor: 400, method: "BANK", receivedAt: new Date() },
    ownerId,
  );
  expect(
    (await database().invoice.findUniqueOrThrow({ where: { id: invoiceId } }))
      .status,
  ).toBe("PAID");
});
it("page-section edits create revisions and enforce versions", async () => {
  const page = await createRecord(
    "pages",
    { title: "Synthetic Page", slug: "synthetic-page" },
    ownerId,
  );
  await replaceSections(
    page.id,
    {
      version: 1,
      sections: [
        {
          section: {
            type: "RICH_TEXT",
            data: { text: "Synthetic CMS text only" },
          },
          isVisible: true,
        },
      ],
    },
    ownerId,
  );
  expect(
    await database().pageSection.count({ where: { pageId: page.id } }),
  ).toBe(1);
  await expect(
    replaceSections(page.id, { version: 1, sections: [] }, ownerId),
  ).rejects.toMatchObject({ code: "CONFLICT" });
});
it("launch checklist reflects approved data and leaves human signoff pending", async () => {
  const checks = await launchReadiness();
  expect(checks.find((x) => x.key === "courses")?.passed).toBe(true);
  expect(checks.find((x) => x.key === "policies")?.passed).toBe(false);
  expect(checks.find((x) => x.key === "signoff")?.passed).toBe(false);
});

it("concurrent outbox workers deliver internal notifications once and quarantine unsupported events", async () => {
  const db = database();
  await db.outboxEvent.updateMany({
    where: { processedAt: null },
    data: { processedAt: new Date() },
  });
  const event = await db.outboxEvent.create({
    data: {
      id: newId(),
      kind: "trial.submitted",
      payload: { trialId: newId() },
    },
  });
  await Promise.all([drainOutbox(), drainOutbox()]);
  expect(
    (await db.outboxEvent.findUniqueOrThrow({ where: { id: event.id } }))
      .processedAt,
  ).not.toBeNull();
  const eligible = await db.user.count({
    where: {
      isActive: true,
      deletedAt: null,
      mustEnrollMfa: false,
      role: {
        key: {
          in: ["SUPER_ADMIN", "ADMIN", "ADMISSIONS", "ACADEMIC_COORDINATOR"],
        },
      },
    },
  });
  expect(
    await db.notification.count({
      where: { entityId: (event.payload as { trialId: string }).trialId },
    }),
  ).toBe(eligible);
  await drainOutbox();
  expect(
    await db.notification.count({
      where: { entityId: (event.payload as { trialId: string }).trialId },
    }),
  ).toBe(eligible);
  const poison = await db.outboxEvent.create({
    data: { id: newId(), kind: "synthetic.unsupported", payload: {} },
  });
  await drainOutbox();
  expect(
    await db.outboxEvent.findUniqueOrThrow({ where: { id: poison.id } }),
  ).toMatchObject({
    processedAt: null,
    attempts: 5,
    errorCode: "UNSUPPORTED_EVENT",
  });
});
it("staff invitation keeps credentials private, requires MFA and is single use", async () => {
  const { inviteUser, acceptInvitation, updateUser } =
    await import("@/server/services/users");
  await expect(
    inviteUser(
      { email: userEmail(), name: "Synthetic Invite", role: "SUPER_ADMIN" },
      ownerId,
      "ADMIN",
    ),
  ).rejects.toMatchObject({ status: 403 });
  const email = userEmail();
  const result = await inviteUser(
    { email, name: "Synthetic Invite", role: "ADMISSIONS" },
    ownerId,
    "SUPER_ADMIN",
  );
  const user = await database().user.findUniqueOrThrow({ where: { email } });
  expect(user.isActive).toBe(false);
  expect(user.mustEnrollMfa).toBe(true);
  const stored = await database().inviteToken.findUniqueOrThrow({
    where: { tokenHash: hashToken(result.inviteToken) },
  });
  expect(stored.tokenHash).not.toBe(result.inviteToken);
  expect(stored.expiresAt.getTime() - Date.now()).toBeGreaterThan(47 * 3600000);
  expect(stored.expiresAt.getTime() - Date.now()).toBeLessThanOrEqual(
    48 * 3600000,
  );
  const accepted = await acceptInvitation(result.inviteToken, password);
  expect(accepted.setupToken).toHaveLength(43);
  await expect(
    acceptInvitation(result.inviteToken, password),
  ).rejects.toMatchObject({ status: 401 });
  await expect(
    updateUser(
      user.id,
      { role: "ADMIN", isActive: true },
      ownerId,
      "SUPER_ADMIN",
    ),
  ).rejects.toMatchObject({ status: 409 });
});
it("changing staff access revokes sessions and protects the last Super Admin", async () => {
  const { updateUser } = await import("@/server/services/users");
  await expect(
    updateUser(
      ownerId,
      { role: "SUPER_ADMIN", isActive: false },
      ownerId,
      "SUPER_ADMIN",
    ),
  ).rejects.toMatchObject({ status: 409 });
  await expect(
    updateUser(ownerId, { role: "ADMIN", isActive: true }, ownerId, "ADMIN"),
  ).rejects.toMatchObject({ status: 403 });
  const user = await database().user.findFirstOrThrow({
    where: { role: { key: "CONTENT_EDITOR" }, isActive: true },
  });
  const session = await login(user.email, password);
  await updateUser(
    user.id,
    { role: "ADMISSIONS", isActive: true },
    ownerId,
    "SUPER_ADMIN",
  );
  expect(await sessionByToken(session.token)).toBeNull();
});
it("teacher course assignment and internal trial notes are audited and protect existing learners", async () => {
  const { replaceTeacherCourses, addTrialNote } =
    await import("@/server/services/academics");
  const teacher = await database().teacher.findUniqueOrThrow({
    where: { id: teacherId },
  });
  await expect(
    replaceTeacherCourses(teacherId, [], teacher.version, ownerId),
  ).rejects.toMatchObject({ status: 409 });
  await expect(
    replaceTeacherCourses(teacherId, [newId()], teacher.version, ownerId),
  ).rejects.toMatchObject({ status: 400 });
  const trial = await database().trialApplication.findFirstOrThrow();
  const note = await addTrialNote(
    trial.id,
    "Synthetic internal note only",
    ownerId,
  );
  expect(
    await database().trialNote.findUnique({ where: { id: note.id } }),
  ).toMatchObject({ body: "Synthetic internal note only", trialId: trial.id });
  expect(
    await database().auditLog.count({
      where: { action: "trial.note_added", entityId: note.id },
    }),
  ).toBe(1);
});

it("reports and exports use real role-scoped records and audit the download without contact data", async () => {
  const { reportingSummary, exportRecords } =
    await import("@/server/services/reports");
  const admissions = await reportingSummary("ADMISSIONS");
  expect(admissions).toHaveProperty("admissions");
  expect(admissions).not.toHaveProperty("finance");
  expect(admissions).not.toHaveProperty("academic");
  const academic = await reportingSummary("ACADEMIC_COORDINATOR");
  expect(academic).toHaveProperty("academic");
  expect(academic).not.toHaveProperty("admissions");
  const exported = await exportRecords("trials", {}, ownerId);
  expect(exported.count).toBeGreaterThan(0);
  expect(exported.csv).toContain('"learnerName"');
  const audit = await database().auditLog.findFirstOrThrow({
    where: { action: "export.downloaded" },
  });
  expect(audit.after).toEqual({ recordCount: exported.count });
  expect(
    await exportRecords("trials", { from: "2099-01-01" }, ownerId),
  ).toMatchObject({ count: 0 });
  await expect(reportingSummary("unknown")).rejects.toMatchObject({
    status: 403,
  });
});

it("password reset is one time, retains mandatory MFA and rejects role escalation", async () => {
  const { issuePasswordReset, resetPassword } =
    await import("@/server/services/users");
  await expect(
    issuePasswordReset(ownerId, ownerId, "ADMIN"),
  ).rejects.toMatchObject({ status: 403 });
  const result = await issuePasswordReset(ownerId, ownerId, "SUPER_ADMIN");
  await expect(
    resetPassword(result.resetToken, "Synthetic changed passphrase"),
  ).rejects.toMatchObject({ status: 401 });
  const code = "synthetic-reset-backup";
  await database().mfaBackupCode.create({
    data: { id: newId(), userId: ownerId, codeHash: hashToken(code) },
  });
  await resetPassword(result.resetToken, "Synthetic changed passphrase", code);
  expect(
    (await database().user.findUniqueOrThrow({ where: { id: ownerId } }))
      .mfaEnabled,
  ).toBe(true);
  expect(await database().session.count({ where: { userId: ownerId } })).toBe(
    0,
  );
  await expect(
    resetPassword(result.resetToken, password, code),
  ).rejects.toMatchObject({ status: 401 });
});

it("public catalog searches and paginates only approved records without private teacher notes", async () => {
  const { publicCatalog } = await import("@/server/services/public");
  const found = await publicCatalog("courses", {
    page: 1,
    pageSize: 1,
    q: "Synthetic",
  });
  expect(found.meta.total).toBe(1);
  expect(found.data).toHaveLength(1);
  expect(
    await publicCatalog("courses", { page: 2, pageSize: 1, q: "Synthetic" }),
  ).toMatchObject({ data: [], meta: { total: 1 } });
  expect(
    await publicCatalog("courses", {
      page: 1,
      pageSize: 20,
      q: "does-not-exist",
    }),
  ).toMatchObject({ data: [], meta: { total: 0 } });
  const teacher = await database().teacher.findUniqueOrThrow({
    where: { id: teacherId },
  });
  await updateRecord(
    "teachers",
    teacherId,
    { isPublic: true, verificationNote: "Synthetic owner credential check" },
    ownerId,
    teacher.version,
  );
  const current = await database().teacher.findUniqueOrThrow({
    where: { id: teacherId },
  });
  await expect(
    updateRecord(
      "teachers",
      teacherId,
      { verificationNote: "" },
      ownerId,
      current.version,
    ),
  ).rejects.toMatchObject({ status: 400 });
  const catalog = await publicCatalog("teachers", {
    page: 1,
    pageSize: 20,
    q: "",
  });
  expect(catalog.data[0]).not.toHaveProperty("verificationNote");
});

it("notification read updates cannot modify another staff member’s inbox", async () => {
  const { markNotificationRead } =
    await import("@/server/services/notifications");
  const user = await database().user.findFirstOrThrow({
    where: { id: { not: ownerId } },
  });
  const notice = await database().notification.create({
    data: { id: newId(), userId: user.id, kind: "synthetic.notification" },
  });
  await markNotificationRead(notice.id, ownerId);
  expect(
    (
      await database().notification.findUniqueOrThrow({
        where: { id: notice.id },
      })
    ).readAt,
  ).toBeNull();
  await markNotificationRead(notice.id, user.id);
  expect(
    (
      await database().notification.findUniqueOrThrow({
        where: { id: notice.id },
      })
    ).readAt,
  ).not.toBeNull();
});

it("teacher availability rejects overlap and stale edits", async () => {
  const { replaceTeacherAvailability } =
    await import("@/server/services/academics");
  const teacher = await database().teacher.findUniqueOrThrow({
    where: { id: teacherId },
  });
  const slot = {
    weekday: 1,
    startMinute: 540,
    endMinute: 600,
    timezone: "UTC",
  };
  await expect(
    replaceTeacherAvailability(
      teacherId,
      [slot, { ...slot, startMinute: 570, endMinute: 660 }],
      teacher.version,
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 400 });
  await replaceTeacherAvailability(
    teacherId,
    [slot, { ...slot, startMinute: 600, endMinute: 660 }],
    teacher.version,
    ownerId,
  );
  expect(
    await database().teacherAvailability.count({ where: { teacherId } }),
  ).toBe(2);
  await expect(
    replaceTeacherAvailability(teacherId, [], teacher.version, ownerId),
  ).rejects.toMatchObject({ status: 409 });
});

it("manual minor creation requires a guardian in the same transaction", async () => {
  await expect(
    createRecord(
      "students",
      {
        fullName: "Synthetic Minor",
        ageBand: "9_12",
        country: "GB",
        timezone: "Europe/London",
      },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 400 });
  const guardian = await createRecord(
    "guardians",
    {
      fullName: "Synthetic Guardian",
      email: userEmail(),
      phone: "+12025550123",
      relationship: "GUARDIAN",
      country: "US",
    },
    ownerId,
  );
  const minor = await createRecord(
    "students",
    {
      fullName: "Synthetic Minor",
      ageBand: "9_12",
      country: "GB",
      timezone: "Europe/London",
      guardianId: guardian.id,
    },
    ownerId,
  );
  expect(
    await database().studentGuardian.count({
      where: { studentId: minor.id, guardianId: guardian.id, isPrimary: true },
    }),
  ).toBe(1);
});

it("competing trial assignments cannot create two booked classes", async () => {
  const db = database();
  const trialKey = newId(),
    data = input();
  await persistTrial(
    data,
    trialKey,
    submissionHash(data),
    "synthetic-assignment-ip",
  );
  const trial = await db.trialApplication.findUniqueOrThrow({
    where: { idempotencyKey: trialKey },
  });
  const alternate = await createRecord(
    "teachers",
    {
      displayName: "Synthetic Alternate Teacher",
      slug: "synthetic-alternate-teacher",
      gender: "FEMALE",
      bio: "Synthetic ephemeral teacher record only.",
      languages: ["English"],
    },
    ownerId,
  );
  await db.teacherCourse.create({
    data: { id: newId(), teacherId: alternate.id, courseId },
  });
  await db.teacherAvailability.create({
    data: {
      id: newId(),
      teacherId: alternate.id,
      weekday: 1,
      startMinute: 540,
      endMinute: 660,
      timezone: "UTC",
    },
  });
  const base = {
    id: trial.id,
    startsAtUtc: new Date("2050-06-06T10:00:00Z"),
    durationMin: 30,
    version: trial.version,
    actorId: ownerId,
  };
  const results = await Promise.allSettled([
    assignTrial({ ...base, teacherId }),
    assignTrial({ ...base, teacherId: alternate.id }),
  ]);
  expect(
    results.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(1);
  expect(results.filter((result) => result.status === "rejected")).toHaveLength(
    1,
  );
  expect(results.find((result) => result.status === "rejected")).toMatchObject({
    status: "rejected",
    reason: { code: "CONFLICT" },
  });
  expect(await db.classSession.count({ where: { trialId: trial.id } })).toBe(1);
});

it("syllabus saves are versioned and audited; published courses and stale editors are protected", async () => {
  const { replaceCourseModules, courseModules } =
    await import("@/server/services/course-modules");
  const course = await createRecord(
    "courses",
    {
      slug: "synthetic-syllabus",
      title: "Synthetic syllabus",
      summary: "Disposable test course",
      ageGroup: "ADULT",
      level: "BEGINNER",
    },
    ownerId,
  );
  await replaceCourseModules(
    course.id,
    {
      version: 1,
      modules: [
        { title: "Second topic", objectives: "Practice the second skill" },
        { title: "First topic", objectives: "Practice the first skill" },
      ],
    },
    ownerId,
  );
  expect((await courseModules(course.id)).map((item) => item.title)).toEqual([
    "Second topic",
    "First topic",
  ]);
  await expect(
    replaceCourseModules(course.id, { version: 1, modules: [] }, ownerId),
  ).rejects.toMatchObject({ status: 409 });
  expect(
    await database().courseModule.count({ where: { courseId: course.id } }),
  ).toBe(2);
  await database().course.update({
    where: { id: course.id },
    data: { status: "PUBLISHED" },
  });
  await expect(
    replaceCourseModules(course.id, { version: 2, modules: [] }, ownerId),
  ).rejects.toMatchObject({ status: 409 });
  expect(
    await database().auditLog.count({
      where: { entityId: course.id, action: "course.modules_updated" },
    }),
  ).toBe(1);
  expect(
    await database().contentRevision.count({
      where: { entityId: course.id, entityType: "course-modules" },
    }),
  ).toBe(1);
});

it("session management exposes only own metadata and rejects foreign session revocation", async () => {
  const { ownSessions, revokeOwnSessions } =
    await import("@/server/services/session-management");
  const role = await database().role.findUniqueOrThrow({
    where: { key: "ADMISSIONS" },
  });
  const other = await database().user.create({
    data: {
      id: newId(),
      name: "Synthetic session owner",
      email: userEmail(),
      passwordHash: await hashPassword(password),
      roleId: role.id,
    },
  });
  async function session(userId: string, expired = false) {
    const token = randomBytes(32).toString("base64url");
    return database().session.create({
      data: {
        id: newId(),
        userId,
        tokenHash: hashToken(token),
        csrfHash: hashToken(sessionCsrf(token)),
        lastSeenAt: new Date(),
        expiresAt: new Date(Date.now() + (expired ? -60000 : 3600000)),
      },
    });
  }
  const current = await session(ownerId),
    foreign = await session(other.id),
    expired = await session(ownerId, true);
  const rows = await ownSessions(ownerId, current.id);
  expect(rows.find((row) => row.id === current.id)?.isCurrent).toBe(true);
  expect(rows.some((row) => [foreign.id, expired.id].includes(row.id))).toBe(
    false,
  );
  expect(
    rows.every(
      (row) =>
        !("tokenHash" in row) && !("csrfHash" in row) && !("ipHash" in row),
    ),
  ).toBe(true);
  await expect(revokeOwnSessions(ownerId, foreign.id)).rejects.toMatchObject({
    status: 404,
  });
  expect(await database().session.count({ where: { id: foreign.id } })).toBe(1);
  await revokeOwnSessions(ownerId, current.id);
  expect(await database().session.count({ where: { id: current.id } })).toBe(0);
  await revokeOwnSessions(ownerId, "all");
  expect(await database().session.count({ where: { userId: ownerId } })).toBe(
    0,
  );
  expect(await database().session.count({ where: { id: foreign.id } })).toBe(1);
  expect(
    await database().auditLog.count({
      where: { actorId: ownerId, action: "identity.all_sessions_revoked" },
    }),
  ).toBe(1);
});

it("plan prices remain private until approved publication and stale saves cannot overwrite fees", async () => {
  const { replacePlanPrices, planPrices } =
    await import("@/server/services/prices");
  const { publicCatalog } = await import("@/server/repositories/public");
  const plan = await createRecord(
    "pricing-plans",
    {
      name: "Synthetic pricing plan",
      billingPeriod: "MONTHLY",
      classesPerWeek: 2,
      durationMin: 30,
      isPublic: true,
    },
    ownerId,
  );
  await replacePlanPrices(
    plan.id,
    {
      version: 1,
      prices: [
        { currency: "GBP", amountMinor: 12345, isPublic: true },
        { currency: "USD", amountMinor: 0, isPublic: false },
      ],
    },
    ownerId,
  );
  expect(
    (
      await publicCatalog("pricing", {
        page: 1,
        pageSize: 20,
        q: "Synthetic pricing plan",
      })
    ).data,
  ).toHaveLength(0);
  await expect(
    replacePlanPrices(plan.id, { version: 1, prices: [] }, ownerId),
  ).rejects.toMatchObject({ status: 409 });
  expect(await planPrices(plan.id)).toHaveLength(2);
  await expect(
    replacePlanPrices(
      plan.id,
      {
        version: 2,
        prices: [
          { currency: "GBP", amountMinor: 1, isPublic: true },
          { currency: "GBP", amountMinor: 2, isPublic: true },
        ],
      },
      ownerId,
    ),
  ).rejects.toThrow();
  await publishRecord("pricing-plans", plan.id, "SUBMITTED", 2, ownerId);
  await publishRecord("pricing-plans", plan.id, "APPROVED", 3, ownerId);
  await publishRecord("pricing-plans", plan.id, "PUBLISHED", 4, ownerId);
  const catalog = await publicCatalog("pricing", {
    page: 1,
    pageSize: 20,
    q: "Synthetic pricing plan",
  });
  expect(catalog.data).toHaveLength(1);
  expect(
    (
      catalog.data[0] as {
        pricingPlanPrice_planId: { currency: string; amountMinor: number }[];
      }
    ).pricingPlanPrice_planId,
  ).toEqual([expect.objectContaining({ currency: "GBP", amountMinor: 12345 })]);
  await expect(
    replacePlanPrices(plan.id, { version: 5, prices: [] }, ownerId),
  ).rejects.toMatchObject({ status: 409 });
});

it("manual enrollment validates eligibility and serializes duplicate requests", async () => {
  const { createEnrollment } = await import("@/server/services/enrollments");
  const course = await createRecord(
    "courses",
    {
      slug: "synthetic-manual",
      title: "Synthetic manual course",
      summary: "Disposable enrollment test",
      ageGroup: "ADULT",
      level: "BEGINNER",
    },
    ownerId,
  );
  await database().course.update({
    where: { id: course.id },
    data: { status: "PUBLISHED" },
  });
  const teacher = await createRecord(
    "teachers",
    {
      slug: "synthetic-manual-teacher",
      displayName: "Synthetic manual teacher",
      gender: "FEMALE",
      bio: "Synthetic teacher for disposable test",
      languages: ["English"],
    },
    ownerId,
  );
  await database().teacherCourse.create({
    data: { id: newId(), teacherId: teacher.id, courseId: course.id },
  });
  const minor = await database().student.create({
    data: {
      id: newId(),
      fullName: "Synthetic unlinked minor",
      ageBand: "13_17",
      country: "GB",
      timezone: "UTC",
    },
  });
  const base = {
    studentId: minor.id,
    teacherId: teacher.id,
    courseId: course.id,
    startDate: "2030-01-01",
  };
  await expect(createEnrollment(base, ownerId)).rejects.toMatchObject({
    status: 400,
  });
  const adult = await createRecord(
    "students",
    {
      fullName: "Synthetic manual adult",
      ageBand: "18_PLUS",
      country: "GB",
      timezone: "UTC",
    },
    ownerId,
  );
  await expect(
    createEnrollment(
      { ...base, studentId: adult.id, teacherId: newId() },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 400 });
  await expect(
    createEnrollment(
      { ...base, studentId: adult.id, planId: newId() },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 400 });
  const outcomes = await Promise.allSettled([
    createEnrollment({ ...base, studentId: adult.id }, ownerId),
    createEnrollment({ ...base, studentId: adult.id }, ownerId),
  ]);
  expect(
    outcomes.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(1);
  const failed = outcomes.find((result) => result.status === "rejected");
  expect(failed?.status === "rejected" && failed.reason).toMatchObject({
    status: 409,
  });
  expect(
    await database().enrollment.count({
      where: { studentId: adult.id, courseId: course.id },
    }),
  ).toBe(1);
  await expect(
    updateRecord("teachers", teacher.id, { isActive: false }, ownerId, 1),
  ).rejects.toMatchObject({ status: 409 });
  const enrollment = await database().enrollment.findFirstOrThrow({
    where: { studentId: adult.id },
  });
  expect(
    await database().auditLog.count({
      where: { action: "enrollment.created", entityId: enrollment.id },
    }),
  ).toBe(1);
  expect(
    await database().outboxEvent.count({
      where: { kind: "enrollment.created" },
    }),
  ).toBe(1);
});

it("consent versions require explicit approval, retain old wording and reject stale form notices", async () => {
  const { publishConsent, activeConsent, verifyConsentVersion } =
    await import("@/server/services/consent");
  try {
    vi.stubEnv("NODE_ENV", "production");
    await expect(verifyConsentVersion("v1-draft")).rejects.toMatchObject({
      status: 409,
    });
  } finally {
    vi.unstubAllEnvs();
  }
  const first = {
    version: "synthetic-consent-v1",
    trialText: "Synthetic consent text for disposable trial testing.",
    contactText: "Synthetic consent text for disposable contact testing.",
    ownerApproved: true as const,
  };
  await publishConsent(first, ownerId);
  await verifyConsentVersion(first.version);
  await expect(
    publishConsent(
      {
        ...first,
        trialText: "Changed synthetic text must use another version.",
      },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 409 });
  await expect(
    publishConsent(
      {
        ...first,
        version: "synthetic-unapproved",
        ownerApproved: false,
      } as unknown as typeof first,
      ownerId,
    ),
  ).rejects.toThrow();
  const second = {
    ...first,
    version: "synthetic-consent-v2",
    contactText:
      "Revised synthetic consent text for disposable contact testing.",
  };
  await publishConsent(second, ownerId);
  expect((await activeConsent())?.version).toBe(second.version);
  await expect(verifyConsentVersion(first.version)).rejects.toMatchObject({
    status: 409,
  });
  await verifyConsentVersion(second.version);
  const retained = await database().setting.findUniqueOrThrow({
    where: { key: "consent.version." + first.version },
  });
  expect(retained.value).toMatchObject({ trialText: first.trialText });
  expect(
    await database().auditLog.count({ where: { action: "consent.approved" } }),
  ).toBe(2);
});

it("contact workflow prevents stale edits, validates assignees and records confirmed replies without copying message text into audit", async () => {
  const { updateContactWorkflow } =
    await import("@/server/services/contact-workflow");
  const email = userEmail();
  await persistContact(
    contactSchema.parse({
      name: "Synthetic private contact",
      email,
      subject: "Synthetic private subject",
      message: "Synthetic private message body for this disposable test.",
      consentGiven: true,
      consentTextVersion: "synthetic-consent-v2",
      website: "",
      startedAt: Date.now() - 4000,
      botToken: "development-bypass",
    }),
    "synthetic-contact-ip",
  );
  let row = await database().contactMessage.findFirstOrThrow({
    where: { email },
  });
  const input = {
    updatedAt: row.updatedAt.toISOString(),
    status: "READ" as const,
    assignedToUserId: ownerId,
    replyConfirmed: false,
  };
  await expect(
    updateContactWorkflow(
      row.id,
      { ...input, status: "REPLIED", replyConfirmed: true },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 409 });
  await expect(
    updateContactWorkflow(
      row.id,
      { ...input, assignedToUserId: newId() },
      ownerId,
    ),
  ).rejects.toMatchObject({ status: 400 });
  await updateContactWorkflow(row.id, input, ownerId);
  await expect(
    updateContactWorkflow(row.id, input, ownerId),
  ).rejects.toMatchObject({ status: 409 });
  row = await database().contactMessage.findUniqueOrThrow({
    where: { id: row.id },
  });
  await expect(
    updateContactWorkflow(
      row.id,
      { ...input, updatedAt: row.updatedAt.toISOString(), status: "REPLIED" },
      ownerId,
    ),
  ).rejects.toThrow();
  await updateContactWorkflow(
    row.id,
    {
      ...input,
      updatedAt: row.updatedAt.toISOString(),
      status: "REPLIED",
      replyConfirmed: true,
    },
    ownerId,
  );
  row = await database().contactMessage.findUniqueOrThrow({
    where: { id: row.id },
  });
  expect(row.repliedById).toBe(ownerId);
  expect(row.repliedAt).toBeInstanceOf(Date);
  await updateContactWorkflow(
    row.id,
    {
      ...input,
      updatedAt: row.updatedAt.toISOString(),
      status: "ARCHIVED",
      assignedToUserId: null,
    },
    ownerId,
  );
  const audits = await database().auditLog.findMany({
    where: { entityId: row.id, action: "contact.workflow_updated" },
  });
  expect(audits).toHaveLength(3);
  expect(JSON.stringify(audits)).not.toContain("Synthetic private");
});

it("public catalog filters preserve publication boundaries and exclude private filter choices", async () => {
  const { publicCatalog, catalogFilterOptions, publicRouteExists } =
    await import("@/server/services/public");
  const db = database();
  const published = await db.course.create({
    data: {
      id: newId(),
      slug: "synthetic-public-filter",
      title: "PublicFilterProbe",
      summary: "Synthetic approved filter fixture",
      ageGroup: "ADULTS",
      level: "FILTER_LEVEL",
      status: "PUBLISHED",
    },
  });
  const hidden = await db.course.create({
    data: {
      id: newId(),
      slug: "synthetic-hidden-filter",
      title: "PublicFilterProbe hidden",
      summary: "Synthetic private fixture",
      ageGroup: "PRIVATE_FILTER",
      level: "PRIVATE_FILTER",
      status: "DRAFT",
    },
  });
  const base = { page: 1, pageSize: 12, q: "PublicFilterProbe" };
  expect(await publicRouteExists("/courses/" + published.slug)).toBe(true);
  expect(await publicRouteExists("/courses/" + hidden.slug)).toBe(false);
  expect(await publicRouteExists("/missing-synthetic-route")).toBe(false);
  expect(
    (
      await publicCatalog("courses", {
        ...base,
        ageGroup: "ADULTS",
        level: "FILTER_LEVEL",
      })
    ).data,
  ).toHaveLength(1);
  expect(
    (await publicCatalog("courses", { ...base, level: "PRIVATE_FILTER" })).data,
  ).toHaveLength(0);
  expect(JSON.stringify(await catalogFilterOptions("courses"))).not.toContain(
    "PRIVATE_FILTER",
  );
  await expect(
    publicCatalog("courses", { ...base, gender: "FEMALE" }),
  ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
  const teacher = await db.teacher.create({
    data: {
      id: newId(),
      slug: "synthetic-filter-teacher",
      displayName: "PublicFilterProbe teacher",
      bio: "Synthetic reviewed teacher",
      gender: "FEMALE",
      languages: ["SyntheticLanguage"],
      isPublic: true,
      verificationNote: "Private credential note must not leak",
    },
  });
  await db.teacherCourse.createMany({
    data: [published.id, hidden.id].map((courseId) => ({
      id: newId(),
      teacherId: teacher.id,
      courseId,
    })),
  });
  const match = await publicCatalog("teachers", {
    ...base,
    gender: "FEMALE",
    language: "SyntheticLanguage",
    courseId: published.id,
  });
  expect(match.data).toHaveLength(1);
  expect(JSON.stringify(match)).not.toContain("Private credential note");
  expect(
    (await publicCatalog("teachers", { ...base, courseId: hidden.id })).data,
  ).toHaveLength(0);
  expect(
    (await publicCatalog("teachers", { ...base, language: "MissingLanguage" }))
      .data,
  ).toHaveLength(0);
});
it("invoice voiding and payment recording serialize without hiding financial history", async () => {
  const { voidInvoice, overdueInvoices } =
    await import("@/server/services/finance");
  const data = {
    enrollmentId,
    currency: "GBP",
    totalMinor: 100,
    dueAt: new Date("2010-01-01"),
  };
  const overdue = await issueInvoice(data, ownerId);
  await recordPayment(
    {
      invoiceId: overdue.id,
      amountMinor: 40,
      method: "BANK",
      receivedAt: new Date(),
    },
    ownerId,
  );
  const changed = await database().invoice.findUniqueOrThrow({
    where: { id: overdue.id },
  });
  expect(changed.version).toBe(overdue.version + 1);
  expect(
    (await overdueInvoices()).data.find((item) => item.id === overdue.id)
      ?.balanceMinor,
  ).toBe(60);
  await expect(
    voidInvoice(
      overdue.id,
      { version: changed.version, reason: "DUPLICATE" },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  const clear = await issueInvoice(data, ownerId);
  await voidInvoice(
    clear.id,
    { version: clear.version, reason: "INCORRECT_DETAILS" },
    ownerId,
  );
  expect(
    (await overdueInvoices()).data.some((item) => item.id === clear.id),
  ).toBe(false);
  const race = await issueInvoice(data, ownerId);
  const outcomes = await Promise.allSettled([
    voidInvoice(
      race.id,
      { version: race.version, reason: "DUPLICATE" },
      ownerId,
    ),
    recordPayment(
      {
        invoiceId: race.id,
        amountMinor: 20,
        method: "BANK",
        receivedAt: new Date(),
      },
      ownerId,
    ),
  ]);
  expect(
    outcomes.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(1);
  const final = await database().invoice.findUniqueOrThrow({
    where: { id: race.id },
  });
  expect(
    await database().paymentRecord.count({ where: { invoiceId: race.id } }),
  ).toBe(final.status === "VOID" ? 0 : 1);
});
it("revision restoration scopes IDs, preserves restricted fields and rejects concurrent stale changes", async () => {
  const { contentRevisions, restoreRevision } =
    await import("@/server/services/revisions");
  const course = await createRecord(
    "courses",
    {
      title: "Synthetic original revision",
      slug: "synthetic-revision",
      summary: "Original synthetic summary",
      ageGroup: "ADULT",
      level: "BEGINNER",
    },
    ownerId,
  );
  await updateRecord(
    "courses",
    course.id,
    { title: "Synthetic edited revision", ageGroup: "ADULT_CHANGED" },
    ownerId,
    course.version,
  );
  const history = await contentRevisions("courses", course.id);
  expect(history).toHaveLength(1);
  const edited = await database().course.findUniqueOrThrow({
    where: { id: course.id },
  });
  const restored = await restoreRevision(
    "courses",
    course.id,
    { revisionId: history[0].id, version: edited.version },
    ownerId,
    false,
  );
  const actual = await database().course.findUniqueOrThrow({
    where: { id: course.id },
  });
  expect(actual.title).toBe("Synthetic original revision");
  expect(actual.ageGroup).toBe("ADULT_CHANGED");
  expect(actual.status).toBe("DRAFT");
  const another = await createRecord(
    "courses",
    {
      title: "Synthetic foreign revision",
      slug: "synthetic-foreign-revision",
      summary: "Synthetic unrelated content",
      ageGroup: "ADULT",
      level: "BEGINNER",
    },
    ownerId,
  );
  await expect(
    restoreRevision(
      "courses",
      another.id,
      { revisionId: history[0].id, version: another.version! },
      ownerId,
      true,
    ),
  ).rejects.toMatchObject({ code: "NOT_FOUND" });
  const outcomes = await Promise.allSettled(
    [1, 2].map(() =>
      restoreRevision(
        "courses",
        course.id,
        { revisionId: history[0].id, version: restored.version },
        ownerId,
        true,
      ),
    ),
  );
  expect(
    outcomes.filter((result) => result.status === "fulfilled"),
  ).toHaveLength(1);
  expect(outcomes.find((result) => result.status === "rejected")).toMatchObject(
    { reason: { code: "CONFLICT" } },
  );
  expect(
    await database().auditLog.count({
      where: { action: "content.revision_restored", entityId: course.id },
    }),
  ).toBe(2);
});
it("scheduled publication requires approved versions and publishes once under concurrent workers", async () => {
  const { schedulePublication, publishDueContent, cancelPublication } =
    await import("@/server/services/publication-schedules");
  const record = await createRecord(
    "pages",
    {
      title: "Synthetic scheduled page",
      slug: "synthetic-scheduled-page",
      template: "STANDARD",
    },
    ownerId,
  );
  const when = new Date(Date.now() + 3600000),
    after = new Date(when.getTime() + 1000);
  await expect(
    schedulePublication(
      "pages",
      record.id,
      { version: record.version!, publishAt: when.toISOString() },
      ownerId,
    ),
  ).rejects.toMatchObject({ code: "CONFLICT" });
  await publishRecord(
    "pages",
    record.id,
    "SUBMITTED",
    record.version!,
    ownerId,
  );
  await publishRecord(
    "pages",
    record.id,
    "APPROVED",
    record.version! + 1,
    ownerId,
  );
  const scheduled = await schedulePublication(
    "pages",
    record.id,
    { version: record.version! + 2, publishAt: when.toISOString() },
    ownerId,
  );
  expect(await publishDueContent()).toEqual({ published: 0, cancelled: 0 });
  const results = await Promise.all([
    publishDueContent(20, after),
    publishDueContent(20, after),
  ]);
  expect(results.reduce((sum, result) => sum + result.published, 0)).toBe(1);
  expect(
    (await database().cMSPage.findUniqueOrThrow({ where: { id: record.id } }))
      .status,
  ).toBe("PUBLISHED");
  expect(
    await database().auditLog.count({
      where: {
        action: "pages.status_changed",
        entityId: record.id,
        after: { path: ["status"], equals: "PUBLISHED" },
      },
    }),
  ).toBe(1);
  expect(
    await database().setting.count({
      where: { key: "publication.schedule.pages." + record.id },
    }),
  ).toBe(0);
  await expect(
    cancelPublication("pages", record.id, scheduled.version, ownerId),
  ).rejects.toMatchObject({ code: "CONFLICT" });
});
it("scheduled publication cancels stale approvals and rejects a publisher whose permission was revoked", async () => {
  const { schedulePublication, publishDueContent } =
    await import("@/server/services/publication-schedules");
  const role = await database().role.findUniqueOrThrow({
    where: { key: "ADMIN" },
  });
  const actor = await database().user.create({
    data: {
      id: newId(),
      email: userEmail(),
      name: "Synthetic schedule operator",
      passwordHash: await hashPassword(password),
      roleId: role.id,
      isActive: true,
      mustEnrollMfa: false,
      mfaEnabled: true,
    },
  });
  const when = new Date(Date.now() + 3600000),
    after = new Date(when.getTime() + 1000);
  async function approved(slug: string) {
    const record = await createRecord(
      "pages",
      { title: "Synthetic scheduled approval", slug, template: "STANDARD" },
      ownerId,
    );
    await publishRecord(
      "pages",
      record.id,
      "SUBMITTED",
      record.version!,
      ownerId,
    );
    await publishRecord(
      "pages",
      record.id,
      "APPROVED",
      record.version! + 1,
      ownerId,
    );
    return record;
  }
  const stale = await approved("synthetic-stale-schedule");
  const planned = await schedulePublication(
    "pages",
    stale.id,
    { version: stale.version! + 2, publishAt: when.toISOString() },
    actor.id,
  );
  await updateRecord(
    "pages",
    stale.id,
    { title: "Synthetic changed after approval" },
    ownerId,
    planned.version,
  );
  expect(
    await database().setting.count({
      where: { key: "publication.schedule.pages." + stale.id },
    }),
  ).toBe(0);
  const revoked = await approved("synthetic-revoked-schedule");
  await schedulePublication(
    "pages",
    revoked.id,
    { version: revoked.version! + 2, publishAt: when.toISOString() },
    actor.id,
  );
  await database().user.update({
    where: { id: actor.id },
    data: { isActive: false },
  });
  expect(await publishDueContent(20, after)).toEqual({
    published: 0,
    cancelled: 1,
  });
  expect(
    (await database().cMSPage.findUniqueOrThrow({ where: { id: revoked.id } }))
      .status,
  ).toBe("APPROVED");
  const audit = await database().auditLog.findFirstOrThrow({
    where: {
      action: "content.publication_schedule_rejected",
      entityId: revoked.id,
    },
  });
  expect(audit.after).toEqual({ reason: "ACTOR_UNAVAILABLE" });
});
it("invoice export produces a tagged readable PDF from actual totals and audits the export without copying private data", async () => {
  const { exportInvoicePdf } =
    await import("@/server/services/invoice-documents");
  const { invoiceDocumentData } =
    await import("@/server/repositories/invoice-documents");
  const { formatMinor } = await import("@/lib/platform/money");
  const invoice = await database().invoice.findFirstOrThrow({
    where: { status: { in: ["ISSUED", "PAID"] } },
  });
  const data = await invoiceDocumentData(invoice.id),
    result = await exportInvoicePdf(invoice.id, ownerId);
  expect(result.bytes.subarray(0, 5).toString()).toBe("%PDF-");
  const text = execFileSync("pdftotext", ["-", "-"], {
    input: result.bytes,
    encoding: "utf8",
  });
  expect(text).toContain(invoice.number);
  expect(text).toContain(data.learnerName);
  expect(text).toContain(formatMinor(data.totalMinor, data.currency));
  expect(text).toContain(
    formatMinor(data.totalMinor - data.paidMinor, data.currency),
  );
  const info = execFileSync("pdfinfo", ["-"], {
    input: result.bytes,
    encoding: "utf8",
  });
  expect(info).toMatch(/Tagged:\s+yes/);
  expect(result.bytes.toString("latin1")).toContain("/StructTreeRoot");
  const audit = await database().auditLog.findFirstOrThrow({
    where: { action: "invoice.pdf_exported", entityId: invoice.id },
  });
  expect(JSON.stringify(audit.after)).not.toContain(data.learnerName);
  await expect(exportInvoicePdf(newId(), ownerId)).rejects.toMatchObject({
    status: 404,
  });
});

it("website recommendations exclude drafts, deleted courses and unverified teachers", async () => {
  const { courseRecommendations, relatedPosts } =
    await import("@/server/services/public");
  const db = database(),
    marker = newId();
  const current = await db.course.create({
    data: {
      id: newId(),
      slug: `current-${marker}`,
      title: "Synthetic current",
      summary: "Ephemeral only",
      ageGroup: marker,
      level: marker,
      status: "PUBLISHED",
    },
  });
  const related = await db.course.create({
    data: {
      id: newId(),
      slug: `related-${marker}`,
      title: "Synthetic related",
      summary: "Ephemeral only",
      ageGroup: marker,
      level: marker,
      status: "PUBLISHED",
    },
  });
  await db.course.create({
    data: {
      id: newId(),
      slug: `draft-${marker}`,
      title: "Synthetic hidden",
      summary: "Ephemeral only",
      ageGroup: marker,
      level: marker,
    },
  });
  await db.course.create({
    data: {
      id: newId(),
      slug: `deleted-${marker}`,
      title: "Synthetic deleted",
      summary: "Ephemeral only",
      ageGroup: marker,
      level: marker,
      status: "PUBLISHED",
      deletedAt: new Date(),
    },
  });
  const verified = await db.teacher.create({
    data: {
      id: newId(),
      slug: `verified-${marker}`,
      displayName: "Synthetic verified",
      gender: "FEMALE",
      bio: "Public biography",
      languages: ["ENGLISH"],
      isPublic: true,
      verificationNote: "Private verification proof",
    },
  });
  const hidden = await db.teacher.create({
    data: {
      id: newId(),
      slug: `unverified-${marker}`,
      displayName: "Synthetic unverified",
      gender: "MALE",
      bio: "Not approved",
      languages: [],
      isPublic: true,
    },
  });
  await db.teacherCourse.createMany({
    data: [verified, hidden].map((teacher) => ({
      id: newId(),
      teacherId: teacher.id,
      courseId: current.id,
    })),
  });
  const results = await courseRecommendations(current);
  expect(results.courses.map((course) => course.id)).toEqual([related.id]);
  expect(results.teachers.map((teacher) => teacher.id)).toEqual([verified.id]);
  expect(JSON.stringify(results)).not.toContain("Private verification proof");
  for (const status of ["PUBLISHED", "DRAFT"] as const)
    await db.blogPost.create({
      data: {
        id: newId(),
        slug: `${status.toLowerCase()}-${marker}`,
        title: `Synthetic ${status}`,
        excerpt: "Ephemeral only",
        body: {},
        renderedHtml: "<p>Ephemeral</p>",
        authorId: ownerId,
        tags: [marker],
        status,
        publishedAt: status === "PUBLISHED" ? new Date() : null,
      },
    });
  const posts = await relatedPosts(`current-${marker}`, [marker]);
  expect(posts.map((post) => post.slug)).toEqual([`published-${marker}`]);
  expect(await relatedPosts(`published-${marker}`, [marker])).toEqual([]);
  expect(await relatedPosts(`current-${marker}`, [])).toEqual([]);
});
