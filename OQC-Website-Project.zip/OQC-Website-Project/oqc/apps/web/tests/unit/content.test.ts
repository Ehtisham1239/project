import { it, expect } from "vitest";
import { richDocumentSchema, renderRichHtml } from "@/lib/validation/richtext";
import { internationalPhone } from "@/lib/validation/common";
import { settingSchemas } from "@/lib/validation/content";
it("public social links reject executable protocols, credentials and malformed URLs without throwing", () => {
  const schema = settingSchemas["social.links"];
  expect(
    schema.safeParse([
      {
        label: "Approved profile",
        url: "https://profile.synthetic.invalid/channel",
      },
    ]).success,
  ).toBe(true);
  for (const url of [
    "javascript:alert(1)",
    "http://profile.synthetic.invalid/channel",
    "https://user:password@profile.synthetic.invalid/channel",
    "not a URL",
  ])
    expect(
      schema.safeParse([{ label: "Synthetic profile", url }]).success,
    ).toBe(false);
});
it("escapes executable HTML and renders only approved markup", () => {
  expect(
    renderRichHtml({
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [
            {
              type: "text",
              text: "<script>alert(1)</script>&",
              marks: [{ type: "bold" }],
            },
          ],
        },
      ],
    }),
  ).toBe("<p><strong>&lt;script&gt;alert(1)&lt;/script&gt;&amp;</strong></p>");
});
it("rejects executable attributes, unknown marks and arbitrary nodes", () => {
  for (const content of [
    { type: "image", attrs: { src: "javascript:alert(1)" } },
    { type: "paragraph", attrs: { onclick: "alert(1)" } },
    {
      type: "text",
      text: "click",
      marks: [{ type: "link", attrs: { href: "javascript:alert(1)" } }],
    },
  ])
    expect(
      richDocumentSchema.safeParse({ type: "doc", content: [content] }).success,
    ).toBe(false);
});
it("rejects nested documents before recursive validation can overflow", () => {
  let value: unknown = { type: "text", text: "x" };
  for (let i = 0; i < 1000; i++)
    value = { type: "paragraph", content: [value] };
  expect(
    richDocumentSchema.safeParse({ type: "doc", content: [value] }).success,
  ).toBe(false);
});
it("accepts editor list and code defaults without rendering attributes", () => {
  expect(
    renderRichHtml({
      type: "doc",
      content: [
        {
          type: "orderedList",
          attrs: { start: 1, type: null },
          content: [
            {
              type: "listItem",
              content: [
                {
                  type: "paragraph",
                  content: [{ type: "text", text: "First" }],
                },
              ],
            },
          ],
        },
        {
          type: "codeBlock",
          attrs: { language: null },
          content: [{ type: "text", text: "<code>" }],
        },
      ],
    }),
  ).toBe("<ol><li><p>First</p></li></ol><pre>&lt;code&gt;</pre>");
});
it("requires a possible and valid international phone number", () => {
  expect(internationalPhone.safeParse("+12025550123").success).toBe(true);
  for (const value of ["+10000000000", "5551234", "+999123456789"])
    expect(internationalPhone.safeParse(value).success).toBe(false);
});

it("CSV quoting prevents spreadsheet formula injection and preserves quotation marks", async () => {
  const { csvCell, encodeCsv } = await import("@/lib/reports/csv");
  expect(csvCell('=HYPERLINK("https://test.invalid")')).toBe(
    '"\'=HYPERLINK(""https://test.invalid"")"',
  );
  for (const value of ["+123", "-cmd", "@SUM(A1)", "  =cmd", "\tcmd"])
    expect(csvCell(value)).toMatch(/^"'/);
  expect(encodeCsv(["name"], [{ name: 'A "quote"' }])).toContain(
    '"A ""quote"""',
  );
});
