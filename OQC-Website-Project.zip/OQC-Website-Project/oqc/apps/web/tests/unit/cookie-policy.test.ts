import { it, expect } from "vitest";
import { authCookiePolicy } from "@/lib/platform/env";
import { NextResponse } from "next/server";
import { clearSessionCookie } from "@/lib/auth/cookies";
const base = {
  AUTH_SECRET: "synthetic-cookie-policy-key-with-sufficient-length",
  DATABASE_URL:
    "postgresql://synthetic@localhost/synthetic?sslmode=verify-full",
};
it("clearing a production session preserves required __Host cookie attributes", () => {
  const response = NextResponse.json({});
  clearSessionCookie(response, {
    ...base,
    NODE_ENV: "production",
    APP_URL: "https://synthetic.invalid",
  });
  const cookie = response.headers.get("set-cookie");
  expect(cookie).toContain("__Host-oqc-session=");
  expect(cookie).toContain("Path=/");
  expect(cookie).toContain("Secure");
  expect(cookie).toContain("Max-Age=0");
});
it("cookie security follows runtime environment and HTTPS without allowing HTTP production", () => {
  expect(
    authCookiePolicy({
      ...base,
      NODE_ENV: "test",
      APP_URL: "http://localhost:3100",
    }),
  ).toEqual({ name: "oqc-session", secure: false });
  expect(
    authCookiePolicy({
      ...base,
      NODE_ENV: "test",
      APP_URL: "https://synthetic.invalid",
    }),
  ).toEqual({ name: "__Host-oqc-session", secure: true });
  expect(
    authCookiePolicy({
      ...base,
      NODE_ENV: "production",
      APP_URL: "https://synthetic.invalid",
    }),
  ).toEqual({ name: "__Host-oqc-session", secure: true });
  expect(() =>
    authCookiePolicy({
      ...base,
      NODE_ENV: "production",
      APP_URL: "http://synthetic.invalid",
    }),
  ).toThrow("Production requires HTTPS");
});
