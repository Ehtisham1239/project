import { afterEach, beforeEach, expect, it, vi } from "vitest";
const readiness = vi.hoisted(() => vi.fn());
vi.mock("@/server/services/content", () => ({ launchReadiness: readiness }));
import { publicIndexingAllowed } from "@/lib/platform/indexing";
beforeEach(() => {
  readiness.mockReset();
  vi.stubEnv("INDEXING_ENABLED", "false");
  vi.stubEnv("DEPLOYMENT_ENVIRONMENT", "staging");
});
afterEach(() => vi.unstubAllEnvs());
it("does not index staging even when enabled", async () => {
  vi.stubEnv("INDEXING_ENABLED", "true");
  expect(await publicIndexingAllowed()).toBe(false);
  expect(readiness).not.toHaveBeenCalled();
});
it("does not index production unless explicitly enabled", async () => {
  vi.stubEnv("DEPLOYMENT_ENVIRONMENT", "production");
  expect(await publicIndexingAllowed()).toBe(false);
});
it("requires all owner launch checks before indexing production", async () => {
  vi.stubEnv("INDEXING_ENABLED", "true");
  vi.stubEnv("DEPLOYMENT_ENVIRONMENT", "production");
  readiness.mockResolvedValue([{ passed: true }, { passed: false }]);
  expect(await publicIndexingAllowed()).toBe(false);
  readiness.mockResolvedValue([{ passed: true }, { passed: true }]);
  expect(await publicIndexingAllowed()).toBe(true);
});
