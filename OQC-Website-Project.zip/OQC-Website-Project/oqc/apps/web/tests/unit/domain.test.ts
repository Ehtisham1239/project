import { it, expect } from "vitest";
import fc from "fast-check";
import { canTransition, trialStates } from "@/lib/admissions/state-machine";
import { expandWeekly, overlaps } from "@/lib/platform/time";
import { sumByCurrency } from "@/lib/platform/money";
import { redact, verifiedNumbers } from "@/lib/ai/guardrails";
it("validates every trial state pair against the workflow", () => {
  const allowed = new Set([
    "NEW:REVIEWED",
    "NEW:CANCELLED",
    "REVIEWED:SCHEDULED",
    "REVIEWED:CANCELLED",
    "SCHEDULED:COMPLETED",
    "SCHEDULED:NO_SHOW",
    "SCHEDULED:CANCELLED",
    "COMPLETED:ENROLLED",
    "COMPLETED:CANCELLED",
    "ENROLLED:CANCELLED",
    "NO_SHOW:CANCELLED",
  ]);
  for (const from of trialStates)
    for (const to of trialStates)
      expect(canTransition(from, to)).toBe(allowed.has(`${from}:${to}`));
});
it("preserves local time across DST", () => {
  const sessions = expandWeekly({
    weekday: 1,
    startMinute: 600,
    durationMin: 30,
    timezone: "America/New_York",
    from: "2026-03-02",
    to: "2026-03-09",
  });
  expect(sessions.map((x) => x.startsAtUtc.toISOString())).toEqual([
    "2026-03-02T15:00:00.000Z",
    "2026-03-09T14:00:00.000Z",
  ]);
});
it("rejects DST gaps and ambiguous times instead of silently moving sessions", () => {
  expect(() =>
    expandWeekly({
      weekday: 7,
      startMinute: 150,
      durationMin: 30,
      timezone: "America/New_York",
      from: "2026-03-08",
      to: "2026-03-08",
    }),
  ).toThrow(/gap/);
  expect(() =>
    expandWeekly({
      weekday: 7,
      startMinute: 90,
      durationMin: 30,
      timezone: "America/New_York",
      from: "2026-11-01",
      to: "2026-11-01",
    }),
  ).toThrow(/ambiguous/);
});
it("overlap is symmetric and adjacent sessions do not conflict", () => {
  fc.assert(
    fc.property(
      fc.integer({ min: 0, max: 1000 }),
      fc.integer({ min: 1, max: 100 }),
      fc.integer({ min: 0, max: 1000 }),
      fc.integer({ min: 1, max: 100 }),
      (a, al, b, bl) => {
        const x = { start: new Date(a), end: new Date(a + al) },
          y = { start: new Date(b), end: new Date(b + bl) };
        expect(overlaps(x, y)).toBe(overlaps(y, x));
      },
    ),
  );
  expect(
    overlaps(
      { start: new Date(0), end: new Date(10) },
      { start: new Date(10), end: new Date(20) },
    ),
  ).toBe(false);
});
it("never combines currencies and refuses floats", () => {
  expect(
    sumByCurrency([
      { currency: "USD", amountMinor: 100 },
      { currency: "GBP", amountMinor: 200 },
      { currency: "USD", amountMinor: 50 },
    ]),
  ).toEqual({ USD: 150, GBP: 200 });
  expect(() =>
    sumByCurrency([{ currency: "USD", amountMinor: 1.5 }]),
  ).toThrow();
});
it("redacts contact tokens and rejects fabricated numeric claims", () => {
  expect(
    redact("synthetic@test.invalid +441234567890 https://test.invalid"),
  ).toBe("[email] [phone-or-id] [url]");
  expect(verifiedNumbers("The fee is 99", ["The fee is 9"])).toBe(false);
  expect(verifiedNumbers("30 minutes", ["A class lasts 30 minutes"])).toBe(
    true,
  );
});

it("money input uses exact minor units and currency precision", async () => {
  const { majorToMinor, formatMinor } = await import("@/lib/platform/money");
  expect(majorToMinor("12.34", "GBP")).toBe(1234);
  expect(majorToMinor("0.00", "GBP", true)).toBe(0);
  expect(() => majorToMinor("0.001", "GBP", true)).toThrow();
  expect(() => majorToMinor("0", "GBP")).toThrow();
  expect(majorToMinor("12", "JPY")).toBe(12);
  expect(() => majorToMinor("12.345", "GBP")).toThrow();
  expect(() => majorToMinor("12.1", "JPY")).toThrow();
  expect(() => majorToMinor("-1", "GBP")).toThrow();
  expect(formatMinor(1234, "GBP")).toBe("£12.34");
});

it("availability includes timezone, midnight boundaries and the whole class duration", async () => {
  const { withinAvailability } = await import("@/lib/platform/time");
  const slot = {
    weekday: 1,
    startMinute: 540,
    endMinute: 600,
    timezone: "Europe/London",
  };
  expect(
    withinAvailability(
      new Date("2030-06-03T08:00:00Z"),
      new Date("2030-06-03T09:00:00Z"),
      [slot],
    ),
  ).toBe(true);
  expect(
    withinAvailability(
      new Date("2030-06-03T08:59:30Z"),
      new Date("2030-06-03T09:00:30Z"),
      [slot],
    ),
  ).toBe(false);
  expect(
    withinAvailability(
      new Date("2030-06-03T08:00:00Z"),
      new Date("2030-06-03T08:30:00Z"),
      [],
    ),
  ).toBe(false);
});
