import { describe, it, expect, vi } from "vitest";
import {
  hashPassword,
  verifyPassword,
  hashToken,
  randomToken,
  encryptSecret,
  decryptSecret,
  safeEqual,
} from "@/lib/auth/crypto";
import { can, canAssignRole, roles } from "@/lib/rbac/policy";
import { validateEnv } from "@/lib/platform/env";
describe("identity primitives", () => {
  it("uses Argon2id and rejects a wrong password", async () => {
    const stored = await hashPassword("synthetic passphrase for testing");
    expect(stored).toMatch(/^\$argon2id\$/);
    expect(
      await verifyPassword(stored, "synthetic passphrase for testing"),
    ).toBe(true);
    expect(await verifyPassword(stored, "incorrect password")).toBe(false);
  });
  it("tokens are opaque random 256-bit values stored as hashes", () => {
    const a = randomToken(),
      b = randomToken();
    expect(a).not.toBe(b);
    expect(Buffer.from(a, "base64url").length).toBe(32);
    expect(hashToken(a)).toHaveLength(64);
    expect(safeEqual(a, b)).toBe(false);
  });
  it("encryption rejects tampering and uses independent IVs", () => {
    process.env.AUTH_SECRET = "a".repeat(40);
    const a = encryptSecret("SYNTHETICMFASECRET"),
      b = encryptSecret("SYNTHETICMFASECRET");
    expect(a).not.toBe(b);
    expect(decryptSecret(a)).toBe("SYNTHETICMFASECRET");
    expect(() => decryptSecret(a.slice(0, -4) + "abcd")).toThrow();
  });
});
describe("authorization", () => {
  it("denies unknown roles and permissions", () => {
    expect(can("unknown", "courses:read")).toBe(false);
    for (const role of roles) expect(can(role, "unknown:read")).toBe(false);
  });
  it("content editor cannot publish or see learner records", () => {
    expect(can("CONTENT_EDITOR", "pages:update")).toBe(true);
    expect(can("CONTENT_EDITOR", "pages:publish")).toBe(false);
    expect(can("CONTENT_EDITOR", "students:read")).toBe(false);
  });
  it("admissions cannot change finance and academic staff cannot read contacts", () => {
    expect(can("ADMISSIONS", "payments:create")).toBe(false);
    expect(can("ACADEMIC_COORDINATOR", "contact-messages:read")).toBe(false);
  });
  it("admin cannot grant super admin", () => {
    expect(canAssignRole("ADMIN", "SUPER_ADMIN")).toBe(false);
    expect(canAssignRole("SUPER_ADMIN", "ADMIN")).toBe(true);
  });
});
it("rejects insecure production configuration", () => {
  expect(() =>
    validateEnv({
      NODE_ENV: "production",
      DATABASE_URL: "postgresql://localhost/test",
      AUTH_SECRET: "change-me-".repeat(5),
      APP_URL: "https://oqc.example",
    }),
  ).toThrow();
  expect(() =>
    validateEnv({
      NODE_ENV: "production",
      DATABASE_URL: "postgresql://localhost/test",
      AUTH_SECRET: "a".repeat(40),
      APP_URL: "http://oqc.example",
    }),
  ).toThrow();
});
it("production bot verification does not accept the development bypass", async () => {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  vi.stubEnv("NODE_ENV", "production");
  delete process.env.TURNSTILE_SECRET_KEY;
  try {
    const { verifyBot } = await import("@/lib/admissions/antibot");
    const input = {
      website: "",
      startedAt: Date.now() - 5000,
      botToken: "development-bypass",
    };
    await expect(verifyBot(input)).rejects.toMatchObject({
      code: "BOT_CHECK_UNAVAILABLE",
    });
    await expect(verifyBot(input, true)).resolves.toBeUndefined();
    await expect(
      verifyBot({ ...input, website: "spam" }, true),
    ).rejects.toMatchObject({ code: "BOT_CHECK_FAILED" });
  } finally {
    vi.unstubAllEnvs();
    if (secret === undefined) delete process.env.TURNSTILE_SECRET_KEY;
    else process.env.TURNSTILE_SECRET_KEY = secret;
  }
});
it("client addresses ignore untrusted forwarded headers", async () => {
  const vercel = process.env.VERCEL,
    proxy = process.env.TRUSTED_PROXY_HEADER;
  delete process.env.VERCEL;
  delete process.env.TRUSTED_PROXY_HEADER;
  try {
    const { clientAddress } = await import("@/lib/platform/client-ip");
    const request = new Request("https://test.invalid", {
      headers: { "x-forwarded-for": "192.0.2.10" },
    });
    expect(clientAddress(request)).toBe("unknown");
    process.env.VERCEL = "1";
    expect(clientAddress(request)).toBe("192.0.2.10");
    expect(
      clientAddress(
        new Request("https://test.invalid", {
          headers: { "x-forwarded-for": "invalid" },
        }),
      ),
    ).toBe("unknown");
  } finally {
    if (vercel === undefined) delete process.env.VERCEL;
    else process.env.VERCEL = vercel;
    if (proxy === undefined) delete process.env.TRUSTED_PROXY_HEADER;
    else process.env.TRUSTED_PROXY_HEADER = proxy;
  }
});

it("production database configuration requires verified TLS", async () => {
  const { validateDatabaseUrl } = await import("@/lib/platform/env");
  expect(
    validateDatabaseUrl(
      "postgresql://synthetic:synthetic@db.test.invalid/example?sslmode=verify-full",
      true,
    ),
  ).toContain("verify-full");
  for (const mode of ["disable", "require", "verify-ca"])
    expect(() =>
      validateDatabaseUrl(
        "postgresql://synthetic:synthetic@db.test.invalid/example?sslmode=" +
          mode,
        true,
      ),
    ).toThrow();
  expect(() =>
    validateDatabaseUrl("mysql://db.test.invalid/example", false),
  ).toThrow();
});
