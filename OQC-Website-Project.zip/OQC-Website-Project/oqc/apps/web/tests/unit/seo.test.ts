import { it, expect } from "vitest";
import { jsonLd } from "@/lib/platform/seo";
it("structured data cannot close its script element through approved content", () => {
  const content = {
    name: "</script><script>alert(1)</script>\u2028text\u2029",
  };
  const encoded = jsonLd(content);
  expect(encoded).not.toContain("<");
  expect(encoded).not.toContain("\u2028");
  expect(encoded).not.toContain("\u2029");
  expect(JSON.parse(encoded)).toEqual(content);
});
