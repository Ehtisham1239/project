# Server authorization matrix

| Module | Super Admin | Admin | Content Editor | Admissions | Academic Coord. |
|---|---|---|---|---|---|
| Users/roles/permissions | CRUD | Read, create non-super | - | - | - |
| Settings, backups, retention | CRUD | Read/update (non-security) | - | - | - |
| Audit logs | Read | Read | - | - | - |
| CMS pages/blog/FAQ/testimonials/media | CRUD + publish | CRUD + publish | CRUD, submit for publish | - | Read |
| Courses | CRUD | CRUD | Update content fields | Read | CRUD |
| Teachers | CRUD | CRUD | Update bio/photo | Read | CRUD |
| Trials | CRUD | CRUD | - | CRUD | Read, assign teacher |
| Contact inbox | CRUD | CRUD | - | CRUD | - |
| Students/guardians/enrollments | CRUD | CRUD | - | Create/read | CRUD |
| Schedules/sessions/attendance/progress | CRUD | CRUD | - | Read | CRUD |
| Pricing/invoices/payment records | CRUD | CRUD | Read pricing | Read | Read |
| Reports/exports | All | All | Content only | Admissions only | Academic only |
| AI dashboard/config | CRUD | Read, toggle approved flags | Use CMS copilot | - | Read insights |


Default deny; no permission inferred from a hidden or visible menu. Content field-only updates require a distinct permission; publishing and security changes never implied by CRUD.
