# Design system

| Token | Value | Use |
|---|---|---|
| `--color-primary` | #138A17 | Buttons, links, key accents |
| `--color-primary-dark` | #075C13 | Hover, headings on light, footer |
| `--color-accent` | #26A81B | Highlights, success states |
| `--color-bg` | #F8FBF7 | Page background (ivory) |
| `--color-surface` | #FFFFFF | Cards |
| `--color-text` | #1C2A20 | Body text (charcoal) |
| `--color-muted` | #5B6B60 | Secondary text (verify AA contrast) |
| `--color-border` | #D7E5D8 | Borders |
| `--color-warning` | #B45309 | Warnings |
| `--color-danger` | #B42318 | Errors |
| `--color-gold` | #B8923A | Optional ornamental accent (sparingly) |

All text/background pairs must meet WCAG 2.2 AA (4.5:1 body, 3:1 large). White text on #26A81B fails AA for small text; use #138A17 or darker for button backgrounds with white text and verify.


Logo source was located in the PDF; samples are recorded below. Use original geometric arch decoration without implying it is the logo. All white-on-green body text uses dark green #075C13 until contrast checks verify alternatives. Latin body Inter; headings Outfit, self-hosted. English only; Urdu/Arabic remain disabled.


## Verified logo source

The original 1254×1254 JPEG was embedded as image 0 on page 1 of the uploaded v6 PDF and extracted without re-encoding using `pdfimages -j`. `design/source/logo_.jpg` and `apps/web/public/brand/logo.jpg` contain identical bytes.

SHA-256: `16fcf3d2856cc6be504db81fa4bd3767ab6c7255a13152294978956d26ea57df`

Read-only Pillow colour samples:

| Region | Pixel (x,y) | sRGB |
|---|---|---|
| arch_highlight | (627, 150) | #40AF0A |
| arch_body | (370, 380) | #187E10 |
| book_base | (627, 888) | #085F0E |
| wordmark | (380, 974) | #1A880F |

The original is displayed on a white plate, without redraw, recolouring or distortion. Initial tokens remain; white button text uses #075C13 for contrast. Exact derivative assets and owner brand signoff remain outstanding.
