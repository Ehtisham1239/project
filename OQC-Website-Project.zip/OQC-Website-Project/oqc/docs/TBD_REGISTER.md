# Owner decisions

Defaults below permit local development. They are not approvals for public launch.

| # | Decision needed | Default Codex uses meanwhile |
|---|---|---|
| 1 | Official domain and exact reference URL | `oqc.example` placeholder; reference limited to tarteelequran.com as supplied |
| 2 | Approved course catalog and levels | No courses exist until staff create them; public pages show honest empty states |
| 3 | Verified pricing and currencies | No public prices; show Contact for fees |
| 4 | Teacher bios, photos, qualifications | No teachers exist until staff create them; teacher pages show empty state |
| 5 | Legal entity details, address, phone, email | Placeholders flagged TBD |
| 6 | Policy wording (privacy, terms, refund, safeguarding) | Drafts for legal review |
| 7 | Languages to launch | English only |
| 8 | AI provider, hosting region, data policy | AI off; stub provider for tests |
| 9 | Approved religious sources and named reviewers | Quran/religious text disabled in AI |
| 10 | Guardian-consent and data-retention rules | No automated purge until retention is approved; draft consent only in development, production forms closed until Super Admin records owner-approved wording |
| 11 | Vercel project/team, managed PostgreSQL provider/region, budget, launch date | User selected Vercel + managed PostgreSQL; credentials and deployment binding pending |
| 12 | Which optional AI features to enable | All disabled |
| 13 | Trial slot rules, class durations, free-trial length | 30 minutes, TBD |
| 14 | Transactional email provider | Console driver |


| 15 | Logo derivatives / owner brand review | Original located in PDF; displayed unchanged; derivatives and signoff pending |
| 16 | Reference-site network access | Unverified: proxy returned HTTP 403 on 2026-10-11 |
| 17 | Safeguarding lead and countries served | Restricted staff records; legal review before launch |
