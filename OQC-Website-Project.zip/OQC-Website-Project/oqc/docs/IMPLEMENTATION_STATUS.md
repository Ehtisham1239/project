# Implementation status

This is an active implementation of v6, not a completed release. A working local workflow does not close the release epics or replace owner approval.

The user has restricted the active task to the website and its CMS. See WEBSITE_HANDOVER.md for owner content and launch prerequisites.

Implemented with local evidence:

- Exact dependency pins, strict TypeScript, Next.js App Router, self-hosted fonts and pnpm monorepo.
- 53 Prisma models on PostgreSQL 16 with pgvector; four additive migrations; system-only roles/grants; immutable audit; teacher/student exclusion constraints and active-enrollment uniqueness.
- Argon2id, hashed sessions, CSRF restoration across tabs, idle/absolute expiry, TOTP and one-time backup codes, interactive bootstrap, 48-hour staff invitations, password resets, account password changes, active-session listing/revocation and sign-out-everywhere, recent reauthentication, role/status updates with session revocation and last-Super-Admin protection.
- Honest public empty states; original owner logo extracted unchanged from the attached PDF; approved catalog, teacher/blog detail, public search/pagination API, form persistence, idempotency, duplicate flags, owner-approved append-only consent versions, stale-notice rejection and audit/outbox writes.
- Public course/teacher/FAQ/blog filters, pagination, approved currency selection, RSS, structured metadata, branded 404 responses, owner-managed navigation/social/benefits and mobile trial steps with preference-only draft restoration.
- Authenticated session-bound signed previews, readable revision diffs and optimistic restore-to-draft, typed page section editing and permission/version-checked scheduled publication.
- Staff create/detail/edit forms, approval/publication actions, Tiptap course/blog content, typed CMS section rendering and rich-text section editing/reordering, setting controls and owner-attested launch checks.
- Course syllabus add/edit/reorder/remove with revision capture, optimistic concurrency and publication protection; trial assignment, status changes, internal notes and confirmed conversion and manual enrollment with guardian/teacher/duplicate checks; teacher-course links and weekly availability; recurring schedules, attendance and progress services; pricing fees per currency with draft/approval protection, invoice numbering, payment records and permission/recent-auth-protected tagged invoice PDF export; contact assignment/read/confirmed-reply/archive controls and selected operational forms.
- Role-scoped aggregate reports and audited CSV exports with formula-injection protection; personal notifications, atomic outbox draining and a running pg-boss worker. No outbound delivery activated.
- Private S3 upload/download implementation with bounded image parsing, magic-byte validation, pixel limits, EXIF removal and alt text. Image-processing unit checks pass; S3 storage-backed verification remains blocked by MinIO image-registry denial.
- Production TLS configuration enforcement, CSP nonces, origin/CSRF checks, trusted-proxy handling and dependency remediation. Latest dependency audit reported zero advisories.
- Repeatable cloud setup script executed successfully; installation/startup/worker instructions and staging requirements saved as an unpublished environment draft.
- Vercel + managed PostgreSQL staging runbook and configuration; pinned GitHub Actions workflow prepared but not executed remotely.
- Local encrypted PostgreSQL backup/restore drill verifies synthetic data, schema, migrations, grants and exclusion constraints, then destroys its databases and temporary files.

Latest completed checks: 42 unit tests and 52 integration tests. Updated type/build/browser checks are tracked in QA_EVIDENCE.md; earlier failures are not counted as passes.

Still required for the complete v6 release:

- Complete enrollment/session workflows, invoice void/correction and overdue administration, contact notes, bulk operations, storage-backed media verification and publication snapshots.
- Consent-version history UI and full DSAR export/anonymization, retention jobs, approved RoPA/DPIA and policy matrix.
- AI provider/configuration/retrieval/evaluation features and the required adversarial/provider suites; the public assistant currently returns a safe unavailable response.
- Generated inventory covers 53 route paths, 70 operations and 40 request/error schemas; full response DTO/contract formalization and complete RTM coverage remain; manual accessibility; performance/load/security/chaos/mutation coverage; production containers/IaC, operational alerts, rollback and production recovery drills, UAT and handover.
- Logo derivatives and owner legal/brand/content approvals. Real courses, teachers, fees, testimonials, addresses and policies remain owner supplied; none have been seeded.
- Vercel project/team access, a verified managed PostgreSQL staging binding, Redis/private storage and secure deployment credentials. No remote deployment has occurred.

The developer database has no real operator or business content. Test factories use disposable databases. No production deployment, external messaging, payment gateway or live AI provider is activated.
