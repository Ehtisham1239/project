# Website verification artifacts

These artifacts were generated on 2026-10-12 from compiled production output running with local test configuration and the empty developer database. They show the actual content-awaiting state. They do not demonstrate populated content performance, external providers, production HTTPS or remote deployment.

- `responsive-review.json`: 22 public pages at 320, 768 and 1440px; no browser errors or horizontal overflow; missing-route HTTP 404 checked at each width.
- `accessibility-review.json`: 22 public pages at 375 and 1440px; all axe violations recorded. Human screen-reader review remains pending.
- `website-home-320.png`, `website-home-1440.png`, `website-trial-320.png`: actual empty-state responsive captures with decoded fonts/images.

Browser suites separately use disposable databases with synthetic content to verify publication, real trial submission, three time ranges, private drafts, related article links, verified teachers and CMS changes. Those fixtures never enter the developer database.

`lighthouse-mobile.json` is the final serial Lighthouse 13.5.0 mobile lab report after local font preload: performance 98, accessibility 100, best practices 100, SEO 69, LCP 2.3s, CLS 0.001 and TBT 50ms. The SEO reduction is the intentional prelaunch indexing block. This is one empty-homepage lab measurement, not INP, field data, a populated-content speed test or remote hosting validation. An earlier measurement of LCP 2.7s prompted the font preload correction.
