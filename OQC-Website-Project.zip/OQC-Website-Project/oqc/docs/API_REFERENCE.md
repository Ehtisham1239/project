# API implementation inventory

Generated with `pnpm docs:api` from actual route handlers and Zod constructors. Every local schema reference is checked. No application source is evaluated to extract schemas. Custom refinements/transforms are runtime rules, and response DTO formalization remains pending. This inventory does not certify complete v6 API coverage.

| Method | Path | Authentication | Body |
|---|---|---|---|
| GET | `/api/health` | Public / token exchange | No parsed request body |
| GET | `/api/ready` | Public / token exchange | No parsed request body |
| POST | `/api/v1/admin/{resource}/{id}/preview-link` | Session + CSRF + Origin | No parsed request body |
| GET | `/api/v1/admin/{resource}/{id}/revisions` | Session | No parsed request body |
| POST | `/api/v1/admin/{resource}/{id}/revisions` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/{resource}/{id}` | Session | No parsed request body |
| PATCH | `/api/v1/admin/{resource}/{id}` | Session + CSRF + Origin | Generated JSON Schema |
| DELETE | `/api/v1/admin/{resource}/{id}` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/{resource}/{id}/schedule-publication` | Session | No parsed request body |
| POST | `/api/v1/admin/{resource}/{id}/schedule-publication` | Session + CSRF + Origin | Generated JSON Schema |
| DELETE | `/api/v1/admin/{resource}/{id}/schedule-publication` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/{resource}/{id}/status` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/{resource}` | Session | No parsed request body |
| POST | `/api/v1/admin/{resource}` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/attendance` | Session | No parsed request body |
| POST | `/api/v1/admin/attendance` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/calendar` | Session | No parsed request body |
| GET | `/api/v1/admin/consent` | Session | No parsed request body |
| POST | `/api/v1/admin/consent` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| PUT | `/api/v1/admin/contact-messages/{id}/workflow` | Session + CSRF + Origin | Generated JSON Schema |
| PUT | `/api/v1/admin/courses/{id}/modules` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/enrollments` | Session | No parsed request body |
| POST | `/api/v1/admin/enrollments` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/exports/{resource}` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| POST | `/api/v1/admin/invoices/{id}/pdf` | Session + CSRF + Origin; recent reauthentication | No parsed request body |
| POST | `/api/v1/admin/invoices/{id}/void` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| GET | `/api/v1/admin/invoices/overdue` | Session | No parsed request body |
| GET | `/api/v1/admin/invoices` | Session | No parsed request body |
| POST | `/api/v1/admin/invoices` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/launch-readiness` | Session | No parsed request body |
| GET | `/api/v1/admin/media/{id}/file` | Session | No parsed request body |
| GET | `/api/v1/admin/media` | Session | No parsed request body |
| POST | `/api/v1/admin/media` | Session + CSRF + Origin | Multipart image |
| POST | `/api/v1/admin/notifications/{id}/read` | Session + CSRF + Origin | No parsed request body |
| PUT | `/api/v1/admin/pages/{id}/sections` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/payments` | Session | No parsed request body |
| POST | `/api/v1/admin/payments` | Session + CSRF + Origin | Generated JSON Schema |
| PUT | `/api/v1/admin/pricing-plans/{id}/prices` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/progress` | Session | No parsed request body |
| POST | `/api/v1/admin/progress` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/reports` | Session | No parsed request body |
| GET | `/api/v1/admin/schedules` | Session | No parsed request body |
| POST | `/api/v1/admin/schedules` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/sessions/{id}/reschedule` | Session + CSRF + Origin | Generated JSON Schema |
| PUT | `/api/v1/admin/sessions/{id}/status` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/admin/settings` | Session | No parsed request body |
| PUT | `/api/v1/admin/settings` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| PUT | `/api/v1/admin/teachers/{id}/availability` | Session + CSRF + Origin | Generated JSON Schema |
| PUT | `/api/v1/admin/teachers/{id}/courses` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/trials/{id}/assign` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/trials/{id}/convert` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/trials/{id}/notes` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/admin/users/{id}/reset` | Session + CSRF + Origin; recent reauthentication | No parsed request body |
| PATCH | `/api/v1/admin/users/{id}` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| GET | `/api/v1/admin/users` | Session | No parsed request body |
| POST | `/api/v1/admin/users` | Session + CSRF + Origin; recent reauthentication | Generated JSON Schema |
| POST | `/api/v1/ai/assistant` | Public / token exchange | No parsed request body |
| POST | `/api/v1/auth/invite` | Public / token exchange | Generated JSON Schema |
| POST | `/api/v1/auth/login` | Public / token exchange | Generated JSON Schema |
| POST | `/api/v1/auth/logout` | Session | No parsed request body |
| POST | `/api/v1/auth/mfa` | Public / token exchange | Generated JSON Schema |
| POST | `/api/v1/auth/password` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/auth/reauthenticate` | Session + CSRF + Origin | Generated JSON Schema |
| POST | `/api/v1/auth/reset` | Public / token exchange | Generated JSON Schema |
| GET | `/api/v1/auth/session` | Session | No parsed request body |
| GET | `/api/v1/auth/sessions` | Session | No parsed request body |
| POST | `/api/v1/auth/sessions` | Session + CSRF + Origin | Generated JSON Schema |
| GET | `/api/v1/public/{resource}` | Public / token exchange | No parsed request body |
| POST | `/api/v1/public/contact-messages` | Public / token exchange | Generated JSON Schema |
| POST | `/api/v1/public/trial-applications` | Public / token exchange | Generated JSON Schema |

Public mutations validate the configured Origin. Staff mutations require Origin, session and CSRF; sensitive operations also require recent password/MFA verification. The public assistant remains disabled. Media streams require staff authorization; CSV exports enforce role and date scopes and never activate outbound delivery. Production consent notices must be owner approved.
