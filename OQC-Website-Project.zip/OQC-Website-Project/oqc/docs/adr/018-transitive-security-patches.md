# ADR 018: patched Prisma tooling dependencies

The production dependency audit on 2026-10-11 reported high advisories in deepmerge-ts and mysql2, and a moderate mysql2 advisory, pulled through Prisma 7.10.0. pnpm overrides pin @prisma/config's deepmerge-ts to 8.0.0 and Prisma's mysql2 to 3.23.1. The deepmerge API used by @prisma/config is retained. Client generation, migrations, integration tests and production compilation were rechecked. The application uses PostgreSQL; no MySQL service was enabled.

A subsequent audit reports zero advisories. Remove these overrides when an upstream stable Prisma release includes patched dependencies and compatibility has been validated. Checksums and TLS verification remain enabled.
