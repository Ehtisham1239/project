# ADR-016: Verified npm-distributed Prisma WASM tools

Status: Accepted for local tooling; version pinned to Prisma 7.10.0.

The native Prisma CLI eagerly downloads its schema engine from binaries.prisma.sh, which the current egress policy denies with HTTP 403. We preserve checksum and TLS checks. No ignore-checksum flag is used.

Client generation invokes Prisma's pinned generator registry and internals using the WASM datamodel path. Migration generation and application invoke the corresponding npm-distributed schema-engine WASM and PostgreSQL adapter. pnpm lockfile integrity covers these artifacts. The normal Rust-free Prisma client uses @prisma/adapter-pg.

The PostgreSQL migration adapter's executeScript implementation splits on every semicolon, including semicolons in PL/pgSQL function bodies. The local adapter wrapper sends the complete trusted migration script to pg without splitting, which preserves PostgreSQL syntax and transaction semantics. Application inputs do not reach this adapter wrapper.

This uses internal Prisma APIs, so upgrades must rerun clean-database migrations, checksum-history checks, repeat migrations and integration tests. No dependency files are patched. scripts/migrate.mjs rejects edited or failed migration histories. Native CLI remains available once the domain allowlist is applied.

Evidence: initial and system-constraint migrations applied to oqc_dev; repeated run reports no migrations; 16 integration tests pass in a newly created database that is removed afterwards. An earlier local database oqc contains a failed development migration; it is retained for diagnosis and is not the configured development database.
