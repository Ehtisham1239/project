# ADR 020: remove the vulnerable development glob chain

The 2026-10-11 full dependency audit reported GHSA-vfj7-8cjw-p6xm in braces, with no patched release available. Prisma client generation and the Next ESLint plugin pulled this package through fast-glob and micromatch. Both consumers use a small, fixed glob API surface.

Scoped pnpm overrides substitute pinned tinyglobby 0.2.17 for these two fast-glob dependencies. The replacement exposes the consumers' named glob and globSync APIs. Before replacement, normalized results were compared for Prisma's generated-file cleanup patterns and Next's directory discovery patterns. The durable check:glob script checks these scopes, excludes unrelated files and prevents traversal of a symlink into an outside directory. Generation was repeated and the frozen setup, typecheck, lint, integration, production build and browser checks passed with the replacement.

The full audit now reports zero advisories. This is a narrow compatibility workaround, not an upstream patch. Retain the compatibility check in setup and CI; remove the overrides when upstream tooling removes the vulnerable chain and equivalent checks pass. Package integrity and TLS verification remain enabled.
