# Architecture

Next.js modular monolith. Server components call services, routes validate and authorize before services, repositories own database access. Mutations write audit and outbox events transactionally. The worker delivers idempotently. PostgreSQL owns durable state; Redis owns rate counters; S3-compatible private storage owns media.

```mermaid
flowchart LR
 Visitor --> Web[Public web]
 Staff --> Admin[Staff admin]
 Web --> Services
 Admin --> Auth[Session + MFA + RBAC]
 Auth --> Services
 Services --> Repository
 Repository --> PG[(PostgreSQL)]
 PG --> Worker
 Worker --> Storage[S3-compatible storage]
 Services --> Redis[(Redis)]
```

AI can only read approved public content or permission-filtered aggregates, never private learner records. All providers, messaging and payments remain inactive.
