# Dependency-ordered execution

P0 discovery: repository and both uploads inspected; original logo extracted unchanged from the supplied PDF; unavailable live reference recorded. Owner requested autonomous implementation; local defaults documented. No deployment approval implied.
P1: architecture, ERD, tokens, wireframes, RBAC, threats, ADRs, RTM and API draft reviewed against the supplied requirements. Asset verification and owner legal/brand signoff deferred to release.

E1 foundation → E2 database → E3 identity → E4 design → E5 public/E8 catalog → E6 admissions → E7 CMS → E9 academics → E10 finance → E11 reporting → E12 privacy → E13 AI platform → E14 gated AI features → E15 quality → E16 operations. Story gates from Section 38 apply; do not mark phases complete on scaffolding alone.
