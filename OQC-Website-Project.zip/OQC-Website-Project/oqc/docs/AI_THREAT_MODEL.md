# AI threat model

Provider calls disabled by default. No religious text generation or rulings; hand off to qualified staff. Public retrieval filters approved/published/public sources. No learner, guardian, payment or progress embeddings. User text and retrieved text are untrusted data. Validate citations, identifiers and all numeric claims. Reject provider output when validation fails. No model tools or write access.

Threats: injection, private data extraction, fabricated pricing/credentials, cost exhaustion, religious-source fabrication, poisoned knowledge. Controls: approval workflow, ACL filters, PII redaction, deterministic output checks, budgets, rate limits, timeouts, kill switch and adversarial evaluation. Enabling a live provider requires owner approval and region/contract review.
