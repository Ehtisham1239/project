# Website handover

The active scope is the public website and its publishing CMS. The wider v6 operations, AI and infrastructure release remains incomplete. Attached documents are reference requirements; the user's website-only scope controls the work.

## Owner content

The owner has confirmed that approved content will be supplied. No courses, fees, teacher credentials, reviews, legal notices or contact details have been invented or seeded. Send approved copy and supporting media for the home/about pages; course descriptions and syllabus; teacher profiles and publication consent; fees and currencies; FAQ/blog; contact/social details; and privacy, terms, refund, safeguarding, accessibility and AI disclosure. Benefits and numerical claims require explicit owner approval.

Until those details arrive, public lists use honest empty states. English is enabled. Urdu and Arabic require reviewed translations before activation. The original logo is retained; derivatives need brand approval. Analytics and nonessential tracking are off by default.

## Publishing

Create the first real administrator interactively using the README bootstrap instructions and enroll MFA. Setup never creates an operator account. Use the CMS to create drafts, edit syllabus or page sections, submit for approval, approve, then publish. A public visitor sees only eligible published records. Editing or restoring published content returns it to draft and withdraws it until it is approved and published again.

The preview button opens a private, authenticated preview. Its signed link expires after ten minutes and is bound to the issuing staff session and record version. It is not an anonymous sharing link. Revision comparison shows readable changes; restoring a revision creates a new draft and checks for concurrent edits.

Approved courses, articles and pages can be scheduled with a date and time zone. The PostgreSQL worker checks due publications every minute, checks the initiating user's current permission and record version, and publishes atomically. Editing cancels the pending job; revoked permissions prevent publication. Keep a persistent worker running outside Vercel's request functions. Notifications remain internal; no email or WhatsApp delivery is activated.

Website navigation links, social profiles and owner-approved benefits are managed in the CMS. Contact details and consent wording come from settings. Privacy consent is versioned; publishing new wording rejects submissions that still refer to the old notice. Configure Turnstile or the explicit owner-approved alternative before accepting real applications.

## Launch prerequisites

Vercel plus managed PostgreSQL remains the chosen staging target. Follow VERCEL_STAGING.md and configure credentials securely in Environment Settings. A remote project, managed database, Redis and private storage bindings are not available; no deployment has occurred. Private image upload/download still needs a storage-backed check. Do not launch on the strength of local tests alone: owner content/legal approval, staging smoke checks, manual accessibility and performance review remain necessary.

Local checks are recorded in QA_EVIDENCE.md. The setup/startup configuration is a saved draft; Review/Save and Publish in Environment Settings activate it. Fresh-task restoration has not been independently verified.

## Browser tooling

Use the pinned pnpm launcher from the README. Chromium uses the installed system browser. On this Debian 13 cloud machine, `bash infra/scripts/setup-webkit-local.sh` prepares WebKit without root access: signed Debian package indexes, SHA-256 checks, extraction without package scripts, and native rendering verification. It adds only missing dependencies to Playwright's browser dependency directories and preserves original browser files.

Run WebKit with `PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright WEBKIT_EXECUTABLE_PATH=/workspace/.cache/ms-playwright/webkit-2370/pw_run.sh` followed by the pinned launcher and `pnpm test:e2e:webkit`. On a normal CI runner, install browser system dependencies using Playwright's documented `install --with-deps webkit`. Run browser builds serially; each runner uses a disposable database.

## Completed website additions

Trial applicants can add, edit and remove up to three preferred day/time ranges. Mobile preferences restore for 30 minutes in the same tab; contact information and consent are never saved in that draft. Course details show approved linked teachers and up to three published related courses matching age group or level. Blog details show up to three other published English articles with shared tags. Drafts, deleted courses and private verification notes are excluded.

Production indexing requires INDEXING_ENABLED=true, DEPLOYMENT_ENVIRONMENT=production and every owner launch-readiness check. Root metadata and robots.txt share that policy; staff pages always remain noindex. Configure indexing only after staging, content/legal approval and owner signoff.

For repeatable responsive verification, start compiled production output in a local test configuration on port 3200, then run `pnpm --filter @oqc/web exec node scripts/review-public.mjs`. This checks 22 public routes at 320/768/1440px, rejects browser errors and horizontal overflow, verifies missing pages return 404, and captures images under docs/evidence. Run `scripts/check-public-accessibility.mjs` from the web directory afterwards for 44 axe scans at 375/1440px. These checks use existing content; they do not seed business data or replace human accessibility review.

The verified local review server command is `NODE_ENV=test APP_URL=http://localhost:3200 node scripts/next.mjs start --hostname localhost --port 3200` from apps/web after `pnpm build`. This exercises compiled output with local test settings; it does not validate production TLS or a deployed standalone container. Keep development on its separate `.next-dev` output. Stop the owned review server before rebuilding its `.next` output.

The mobile lab command is `CHROME_PATH=/usr/bin/chromium npm exec --yes --package=lighthouse@13.5.0 -- lighthouse http://localhost:3200 --chrome-flags='--headless --no-sandbox' --only-categories=performance,accessibility,best-practices,seo --output=json --output-path=../../docs/evidence/lighthouse-mobile.json --quiet` from apps/web. Run it separately from browser suites so competing workloads do not distort the measurement.

Keyboard verification includes Tab to the skip link and Enter transferring focus to the main content region in Chromium and WebKit. Social-profile saving now reports completion after the refreshed settings page is ready; edits clear that confirmation.
