# Domain relationships

```mermaid
erDiagram
 User }o--|| Role : has
 Role ||--o{ RolePermission : grants
 Permission ||--o{ RolePermission : maps
 User ||--o{ Session : authenticates
 Course ||--o{ CourseModule : contains
 Teacher }o--o{ Course : teaches
 TrialApplication }o--|| Course : requests
 TrialApplication ||--o{ TrialHistory : tracks
 Student }o--o{ Guardian : linked
 Student ||--o{ Enrollment : has
 Course ||--o{ Enrollment : chosen
 Teacher ||--o{ Enrollment : assigned
 Enrollment ||--o{ ClassSchedule : schedules
 ClassSchedule ||--o{ ClassSession : expands
 ClassSession ||--o{ Attendance : records
 Enrollment ||--o{ ProgressRecord : tracks
 Enrollment ||--o{ Invoice : billed
 Invoice ||--o{ PaymentRecord : receives
 PricingPlan ||--o{ PricingPlanPrice : prices
 CMSPage ||--o{ PageSection : contains
 CMSPage ||--o{ ContentRevision : versions
 AIKnowledgeDocument ||--o{ AIKnowledgeChunk : indexes
```

Detailed physical schema and constraints follow in the foundation phase.
