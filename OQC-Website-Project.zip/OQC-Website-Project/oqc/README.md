# Online Quran College LTD

Active implementation of the attached v6 specification. This is not a production-ready release. See [implementation status](docs/IMPLEMENTATION_STATUS.md), [test evidence](docs/QA_EVIDENCE.md), and [owner decisions](docs/TBD_REGISTER.md).

Use the existing checkout at `oqc/`; cloud tasks are already isolated. Do not create a worktree unless explicitly requested.

## Local development

Prerequisites: Node 24 LTS, Docker daemon, pnpm 10.34.6. The package manager and dependencies are pinned. No business content is seeded.

```sh
cd oqc
bash infra/scripts/setup-cloud.sh
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm dev
# In a separate managed terminal, run the internal notification worker:
npm_config_cache=/workspace/.npm-cache npm exec --yes --package=pnpm@10.34.6 -- pnpm worker
```

Development output is isolated in `.next-dev`; production uses `.next` and browser tests use `.next-e2e`, preventing build output from corrupting a running dev server.

Runtime configuration is read from `apps/web/.env` and injected environment variables; injected values take precedence. Root `.env` supplies Compose settings. Both files are ignored. Do not overwrite existing configuration blindly. Local-only sample database credentials bind to loopback.

`GET /api/health` verifies the process. `GET /api/ready` checks environment validation, database/migrations and Redis. A healthy process is not owner approval for public launch.

Create the first real operator yourself, interactively:

```sh
cd apps/web
# Set BOOTSTRAP_TOKEN securely in the environment (random, 32+ bytes).
pnpm bootstrap:admin --email <your-staff-address>
```

The password is prompted without echo. Follow the one-time setup link, enroll MFA, securely store the backup codes, then remove BOOTSTRAP_TOKEN. No default account exists. Never put passwords in arguments or chat.

## Checks

```sh
pnpm lint
pnpm typecheck
pnpm test:unit
pnpm test:integration
pnpm test:e2e
pnpm test:e2e:webkit # configure browser dependencies first
pnpm test:a11y
pnpm check:no-seed
pnpm build
```

Integration and browser runners create random disposable PostgreSQL databases and remove them afterwards. Business test data is created in code only, never in the developer/staging database. Browser checks run on system Chromium and native WebKit; see [website handover](docs/WEBSITE_HANDOVER.md) for WebKit setup. Local mobile Lighthouse and public responsive/axe results are saved under [website evidence](docs/evidence/README.md). Manual screen-reader checks, populated-content/remote performance, load/security/mutation scans and complete release coverage remain outstanding. Test output records actual executed results.

AI, outbound email, campaigns and payment gateways are inactive. Courses, teachers, prices, testimonials and reviewed policy content must be entered by authorized staff. Unknown business facts remain absent or clearly pending. Logo derivatives and final legal/brand reviews remain required before launch.

The v6 application is independent of the repository's old Laravel CRM deployment guide.

The setup script preserves existing ignored environment files, generates development-only random credentials only when absent, verifies local service readiness and refuses remote database setup. It has been executed successfully and supports repeat runs. Cloud installation/startup instructions are saved in the environment draft; saving a draft does not publish it.

The staging target is Vercel plus managed PostgreSQL. See [staging runbook](docs/VERCEL_STAGING.md). Deployment access and provider bindings are still required. The source changes are local and have not been pushed; a Git-import deployment requires those changes to be reviewed and made available remotely, or an authorized CLI deployment must use the current local artifact.
